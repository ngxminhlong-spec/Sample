# Flour

A moderation bot for Discord, written in C++17 with [D++ (DPP)](https://dpp.dev) and SQLite.

## Features

**Moderation (slash commands)**

| Command | What it does |
| --- | --- |
| `/ban user [reason] [duration] [delete_days]` | Ban, permanently or for a set time (`7d`, `12h`). Temporary bans lift themselves. |
| `/unban user [reason]` | Lift a ban |
| `/kick user [reason]` | Kick a member |
| `/timeout user duration [reason]` / `/untimeout` | Discord timeouts, up to 28 days (`10m`, `2h`, `1d12h`) |
| `/warn user reason` / `/unwarn case [reason]` | Warnings that count toward automatic escalation |
| `/history user [page]` / `/case number` | Browse the case log |
| `/purge amount [user]` | Bulk delete (skips pinned and 14+ day old messages) |
| `/slowmode seconds [channel]` | Set slowmode |
| `/lock [channel]` / `/unlock [channel]` | Stop or allow `@everyone` from sending |
| `/heat status` / `/heat reset` | Show the anti-raid heat meter, or cool it down and lift restrictions |
| `/config show`, `/config modlog`, `/config set` | Per-server settings (warning ladder, heat, account age) |
| `/automod show`, `rule`, `tune`, `exempt-role`, `exempt-channel`, `exempt-list`, `allow-domain`, `remove-domain`, `domains` | Auto-moderation |
| `/filter add`, `/filter remove`, `/filter list` | Word filter (plain text or regex) |
| `/ticketconfig set`, `panel`, `appeals`, `show` | Set up tickets and ban appeals |
| `/logs set`, `off`, `toggle`, `show` | Log server activity to a channel |
| `/antinuke show`, `enable`, `action`, `limit`, `window`, `trust`, `trusted` | Protect the server from a rogue or compromised admin (owner and Administrators only) |
| `/ticket close`, `add`, `remove` | Work with the ticket you're in |

Every action becomes a numbered **case**, stored per server and posted to the mod log channel. DMs go out to banned, kicked, timed out and warned users (best effort; closed DMs are ignored).
Moderators can't act on the owner, on themselves, or on anyone whose top role is equal to or above theirs.

**Audit trail.** Cases can't be deleted. SQLite triggers reject deletes and edits to anything except the `active` flag, so `/unwarn` marks a warning as removed and logs a new case rather than erasing history.

**Warning ladder.** Defaults: a timeout at 3 active warnings (60 minutes) and a ban at 5. Change both with `/config set`, or set them to 0 to turn them off.

**Auto-mod.** Eight rules, all off until you turn them on. Each rule has its own punishment, set with `/automod rule`:

| Rule | Catches |
| --- | --- |
| `spam` | More than N messages in W seconds (default 6 in 5s). The whole burst is deleted. |
| `duplicates` | The same message (ignoring case and spacing) N times in W seconds, even across channels (default 3 in 30s). Very short messages are ignored. |
| `mentions` | More than N user, role or `@everyone` mentions in one message (default 5) |
| `invites` | Discord invite links |
| `links` | Any link to a site that isn't on your approved list, including bare domains like `free-nitro.xyz` and shorteners. Subdomains of approved sites are fine; lookalikes like `evil-youtube.com` are not. |
| `words` | Anything matching your `/filter` list (plain text or regex) |
| `caps` | At least P% capitals once a message has N letters (default 70% over 12 letters). Mentions, emoji and links don't count. |
| `emoji` | More than N emoji in one message, counting custom emoji, flags and joined emoji sequences as one each (default 10) |

The punishment is one of **off**, **delete** (just remove the message), **warn** (delete and add a warning, so the warning ladder applies) or **timeout** (delete and time the user out, 10 minutes by default). Thresholds are changed with `/automod tune`.

`/automod exempt-role` and `/automod exempt-channel` exempt a role or channel from every rule, and `/automod exempt-list` shows them. Members with Manage Messages or Administrator are always exempt. Approve sites for the `links` rule with `/automod allow-domain youtube.com` (`remove-domain` and `domains` manage the list). The rule engine reads its settings from a per-server cache, so busy servers don't hit the database on every message.

Servers upgraded from an earlier version keep what they had switched on: spam, mention, invite and word rules that were enabled come across as **warn**.

**Heat (anti-raid).** Turn it on with `/config set setting:heat_enabled value:1`. Each server has a heat value that suspicious events push up and that cools over time (`heat_decay` points per minute, default 30).

| Event | Heat added |
| --- | --- |
| A member joins | 4, plus 10 if the account is under a day old, 6 if under a week, 2 if under a month |
| Any auto-mod violation, whatever its punishment | 5 |

The response gets stricter as heat climbs. The three levels are configurable (`heat_warm` 30, `heat_hot` 60, `heat_critical` 90 by default):

- **Warm:** a heads-up in the mod log. Nothing is restricted.
- **Hot:** new joins from accounts under 30 days old are timed out for 10 minutes, and invite links are removed even if the `invites` rule is off.
- **Critical:** lockdown. Every new join is kicked, along with the young accounts that joined in the last 3 minutes.

A level only drops once heat falls below 70% of that level's threshold, so it doesn't flap on and off. Every level change is posted to the mod log. `/heat status` shows the meter and `/heat reset` ends it early. Heat lives in memory, so a restart starts every server at zero.

`min_account_age` is a separate hard gate that kicks accounts younger than N days no matter what the heat is.

**Server logs.** `/logs set channel:#server-logs` starts logging activity there. `/logs toggle` picks which kinds are logged: message edits and deletes, joins and leaves, role changes, nickname changes and voice joins, leaves and moves. Each event shows who did it, what changed (edits show before and after, deletes show the removed text) and a link to the message. Message text is kept in memory for the last 20,000 messages, so an edit or delete of something posted before a restart is logged without its old content. Nickname and role changes are compared against the last state Flour saw, so members Flour hasn't seen since it started are only tracked from their next change. Bot messages are never logged, which also stops the log channel from logging itself.

**Anti-nuke.** Watches for one account doing too much damage in a short time. It counts, per person: bans, kicks, deleted channels, deleted roles, Administrator grants (a new role with Administrator, an existing role given it, or a member given such a role) and webhook creates or deletes. Reaching the limit inside the window gets the person **banned** (the default) or **stripped** of every role Flour is allowed to remove. Defaults: 3 bans, 3 kicks, 3 channel deletes, 3 role deletes, 1 Administrator grant and 3 webhook changes in 20 seconds.

Flour finds out who did each action from the audit log, reading it in one batched request every few seconds rather than once per event. It ignores its own actions and the owner's. The owner is never punished, and anyone added with `/antinuke trust` is exempt.

**Undo.** Everything the restore needs is kept in the bot's SQLite database, so it still works after a restart:

- **Member roles:** each member's roles are tracked, seeded from the cache at startup and updated on every change.
- **Channel permissions:** each channel's permission overwrites are tracked the same way. When a role is deleted, the overwrites that used it are saved, so they can be put back on channels that still exist.
- **Deleted roles and channels:** a full copy of each is saved the moment it's deleted, whether or not anti-nuke is on. Copies are kept for a day.

When someone is punished, Flour recreates what they deleted. Roles come first, with their name, colour, permissions and position. Then channels, categories before the channels inside them, with their permissions, topic and position. Permission overwrites are remapped to the new role IDs. Channels that still exist get the deleted role's overwrites back. Finally, members get back the roles they had, mapped to the recreated roles.

Messages are not restored. Recreated channels are empty.

Discord gives a restored role a new ID, and the API can't choose one. Flour updates its own references to the new ID: the staff role in `/ticketconfig`, auto-mod role exemptions, and member roles. Each change is logged with the old and new ID, and `/antinuke remaps` lists the last 20. Anything outside Flour that uses the old ID, such as other bots, role menus or pings in old messages, still needs changing by hand.

Anything deleted after the punishment is restored once Flour sees it, as long as it's still within the day-long retention.

The owner gets a DM and a mod log entry each time anti-nuke fires. `/antinuke` is restricted to the owner and Administrators, so a compromised moderator account can't turn it off.

**Tickets.** Staff run `/ticketconfig set` (pick a category and a staff role, plus an optional transcript channel), then `/ticketconfig panel` to post an "Open a ticket" button. Members fill in a short form and get a private channel that only they, the staff role and Flour can see. Inside a ticket, the Close and Claim buttons (or `/ticket close`) work, and staff can use `/ticket add` and `/ticket remove` to bring people in or out. Closing saves a text transcript (up to the last 500 messages) to the transcript channel, falling back to the mod log, DMs a copy to the opener, then deletes the channel. Each member can have one open ticket at a time. If a ticket channel is deleted by hand, the ticket is closed in the database so the member can open a new one.

**Ban appeals.** Banned people aren't in the server, so they can't click anything there. Instead, `/ticketconfig appeals channel:#appeals` turns appeals on, and from then on the DM Flour sends when it bans someone carries an **Appeal this ban** button. Pressing it opens a form, Flour checks that the person really is banned, and the appeal lands in the appeals channel with the ban reason, their case count and **Approve** and **Deny** buttons (members with Ban Members). Approving unbans them, logs a case and DMs them. Denying logs a case and DMs them, and they can appeal again after 7 days. Only one appeal per person can be pending at a time. Leave the channel out of `/ticketconfig appeals` to turn appeals off. This works for bans Flour issued after appeals were enabled, because that's when the button is attached to the DM.

## Web dashboard

Flour can serve a settings dashboard. It's built into the bot, so changes take effect straight away. It listens on `127.0.0.1` only, and Tailscale puts it on your tailnet.

1. In the Discord developer portal, open **OAuth2** and add this redirect: `https://<machine>.<tailnet>.ts.net/callback`. Copy the client ID and client secret.
2. Set the `dashboard` block in `config.json`: `"enabled": true`, plus the client ID, client secret and redirect URI from step 1.
3. Start Flour, then publish it on your tailnet:

   ```sh
   sudo tailscale serve --bg --https=443 http://127.0.0.1:8080
   ```

4. Open `https://<machine>.<tailnet>.ts.net` from any device on your tailnet and log in with Discord.

Only people with Manage Server (or the owner) can open a server's settings. Anti-nuke settings need Administrator, the same as `/antinuke`. Every change is logged to the mod log with the name of who made it. Sessions last 12 hours.

The dashboard isn't reachable from the internet. Don't open its port on the VPS firewall, and don't point DuckDNS at it unless you put a reverse proxy with authentication in front.

## Fresh VPS: one-command setup

For a brand-new Ubuntu 22.04 or 24.04 VPS. It installs everything, asks for your token and dashboard details, builds Flour, starts it as a service, and publishes the dashboard on your tailnet.

```sh
sudo apt-get install -y unzip
unzip flour.zip
cd flour
sudo bash setup/setup.sh
```

The script asks you:
- Your Discord bot token (typed hidden, so nothing shows on screen)
- Whether to turn on the dashboard, and if so the OAuth2 client ID and secret. It prints the redirect URL to add in the developer portal first.
- Whether to turn on the firewall. It allows SSH and Tailscale only.

It takes a few minutes, plus 20 to 40 minutes for the first build on a small VPS. Run it again to update Flour. Your config is kept.

After setup, the bot runs as the `flour` service. These commands are useful:

| Command | What it does |
| --- | --- |
| `sudo systemctl status flour` | Check the bot is running |
| `sudo journalctl -u flour -f` | Watch the live log |
| `sudo systemctl restart flour` | Restart after changing the config |
| `sudo nano /opt/flour/config.json` | Edit the token or dashboard settings |

Files live in `/opt/flour`. The database is `/opt/flour/flour.db`, so back that file up to keep your cases, settings and undo data.

## Build

Needs a C++17 compiler, CMake 3.16+, OpenSSL and zlib dev packages, and SQLite3 dev files.

```sh
# Debian/Ubuntu
sudo apt install build-essential cmake libssl-dev zlib1g-dev libsqlite3-dev

cmake -B build
cmake --build build -j
```

If DPP isn't installed system-wide, CMake downloads and builds v10.1.6 for you (the first build takes a while).

## Run

1. Create an application and bot at <https://discord.com/developers/applications>.
2. On the **Bot** page, enable the **Server Members Intent** and **Message Content Intent**.
3. Invite it with the `bot` and `applications.commands` scopes. Flour needs these permissions: Ban Members, Kick Members, Moderate Members, Manage Messages, Manage Channels, View Channels, Send Messages, Embed Links, Attach Files, Read Message History, plus the Server Members and Message Content intents turned on in the developer portal. Voice logs use the Guild Voice States intent, which the bot requests itself. Its role must sit **above** the roles it should be able to moderate.
4. Copy `config.example.json` to `config.json` and fill in the token (or set `FLOUR_TOKEN`).
5. `./build/flour` (or `./build/flour path/to/config.json`)
6. In your server, run `/config modlog` first, then `/config show` to see what's enabled.

While testing, set `dev_guild_id` in the config to your server's ID. Commands then register instantly instead of taking up to an hour to propagate globally.

## Layout

```
src/main.cpp             startup, config, event wiring
src/commands.cpp         moderation slash commands
src/config_commands.cpp  /config and /filter
src/actions.cpp          ban/kick/timeout/warn logic shared by commands and auto-mod
src/automod.cpp          the message rule engine and join handling
src/automod_commands.cpp /automod command
src/textcheck.cpp        caps, emoji, link, invite and duplicate checks (no Discord dependency)
src/heat.cpp             anti-raid heat meter
src/tickets.cpp          tickets, transcripts and ban appeals
src/logging.cpp          server activity logs and the /logs command
src/antinuke.cpp         anti-nuke: audit log scans, Administrator grants, webhooks and undo
src/ratewindow.hpp       sliding-window counter used by anti-nuke
src/dashboard.cpp        web dashboard: Discord login, settings API and page
src/third_party/httplib.h  cpp-httplib 0.64.0 (MIT), the HTTP server
src/archive.cpp          member role tracking for undo, seeded from the cache
src/modlog.cpp           case embeds and mod log posting
src/scheduler.cpp        expires temporary bans
src/database.cpp         SQLite storage (WAL mode, one mutex-guarded connection)
src/util.cpp             duration parsing and formatting
```
