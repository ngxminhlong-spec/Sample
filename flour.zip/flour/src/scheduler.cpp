#include "app.hpp"
#include "util.hpp"

namespace flour {

void start_scheduler(App& app) {
    app.bot.start_timer([&app](dpp::timer) {
        automod_sweep();

        // Deleted channels and roles stay restorable for a day, then their tombstones and messages go.
        app.db.tombstones_purge(static_cast<int64_t>(time(nullptr)) - 24 * 3600);

        const int64_t now = static_cast<int64_t>(time(nullptr));
        for (const TempAction& a : app.db.due_unbans(now)) {
            app.db.delete_temp_action(a.id);
            app.bot.guild_ban_delete(a.guild_id, a.user_id,
                [&app, a](const dpp::confirmation_callback_t& cb) {
                    if (cb.is_error()) {
                        // 10026 = Unknown Ban: someone already lifted it by hand, nothing to do.
                        if (cb.get_error().code == 10026) return;
                        log_event(app, a.guild_id, "Temporary ban expiry failed",
                                  "Could not unban <@" + std::to_string(a.user_id) + ">: " + cb.get_error().message,
                                  color::danger);
                        return;
                    }
                    record_case(app, a.guild_id, a.user_id, app.bot.me.id, "unban", "Temporary ban expired");
                });
        }
    }, 15);
}

}  // namespace flour
