#include <algorithm>
#include <chrono>
#include <deque>
#include <functional>
#include <map>
#include <mutex>
#include <regex>

#include "app.hpp"
#include "textcheck.hpp"
#include "util.hpp"

namespace flour {

namespace {

constexpr double kAutomodHeat = 5.0;
constexpr int64_t kKeepMessagesMs = 120000;  // how long recent messages are remembered per user
constexpr size_t kKeepMessagesMax = 60;

struct RecentMessage {
    int64_t at_ms;
    size_t hash;  // 0 when the message is too short to count as a duplicate
    dpp::snowflake channel_id;
    dpp::snowflake message_id;
};

std::mutex g_mutex;
std::map<std::pair<uint64_t, uint64_t>, std::deque<RecentMessage>> g_recent;

int64_t now_ms() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
               std::chrono::steady_clock::now().time_since_epoch()).count();
}

int64_t now_s() { return static_cast<int64_t>(time(nullptr)); }

// ------------------------------------------------------------------ enforcement

// Short-lived channel notice ("your message was removed").
void notify_temp(App& app, dpp::snowflake channel_id, const std::string& text) {
    app.bot.message_create(dpp::message(channel_id, text),
        [&app](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) return;
            const dpp::message sent = std::get<dpp::message>(cb.value);
            app.bot.start_timer([&app, sent](dpp::timer handle) {
                app.bot.stop_timer(handle);
                app.bot.message_delete(sent.id, sent.channel_id);
            }, 6);
        });
}

void enforce(App& app, const dpp::message& msg, int action, const std::string& reason,
             const GuildConfig& cfg, const std::vector<RecentMessage>& burst = {}) {
    app.bot.message_delete(msg.id, msg.channel_id);
    for (const auto& r : burst) {
        if (r.message_id != msg.id) app.bot.message_delete(r.message_id, r.channel_id);
    }

    const uint64_t guild_id = msg.guild_id;
    const uint64_t user_id = msg.author.id;
    heat_add(app, guild_id, kAutomodHeat, "auto-mod: " + reason);

    std::string note = "<@" + std::to_string(user_id) + "> your message was removed: " + reason + ".";
    if (action == automod_warn) {
        const std::string escalation = action_warn(app, guild_id, user_id, app.bot.me.id, "Automod: " + reason);
        if (!escalation.empty()) note += " " + escalation;
    } else if (action == automod_timeout) {
        const int64_t secs = static_cast<int64_t>(std::clamp(cfg.automod_timeout_mins, 1, 40320)) * 60;
        action_timeout(app, guild_id, user_id, app.bot.me.id, secs, "Automod: " + reason);
        note += " You've been timed out for " + format_duration(secs) + ".";
    }
    notify_temp(app, msg.channel_id, note);
}

bool is_exempt(const AutomodLists& lists, const dpp::message& msg, const dpp::guild_member& member) {
    if (std::find(lists.exempt_channels.begin(), lists.exempt_channels.end(),
                  static_cast<uint64_t>(msg.channel_id)) != lists.exempt_channels.end()) {
        return true;
    }
    for (const dpp::snowflake& role : member.get_roles()) {
        if (std::find(lists.exempt_roles.begin(), lists.exempt_roles.end(),
                      static_cast<uint64_t>(role)) != lists.exempt_roles.end()) {
            return true;
        }
    }
    return false;
}

}  // namespace

void automod_on_message(App& app, const dpp::message_create_t& event) {
    const dpp::message& msg = event.msg;
    if (msg.guild_id == 0 || msg.author.is_bot() || msg.webhook_id != 0) return;

    dpp::guild* guild = dpp::find_guild(msg.guild_id);
    if (!guild) return;

    dpp::guild_member member = msg.member;
    member.user_id = msg.author.id;

    // Moderators are always exempt.
    const dpp::permission perms = guild->base_permissions(member);
    if (perms.can(dpp::p_administrator) || perms.can(dpp::p_manage_messages)) return;

    const auto lists = app.db.get_automod_lists(msg.guild_id);
    if (is_exempt(*lists, msg, member)) return;

    const GuildConfig cfg = app.db.get_config(msg.guild_id);
    const std::string& content = msg.content;

    // Invite links. While the server is running hot they're removed even if the rule is off.
    int invite_action = cfg.invite_action;
    if (invite_action == automod_off && heat_peek(app, msg.guild_id).level >= heat_hot) invite_action = automod_delete;
    if (invite_action != automod_off && contains_invite(content)) {
        enforce(app, msg, invite_action, "invite links are not allowed here", cfg);
        return;
    }

    if (cfg.link_action != automod_off && has_unapproved_link(content, lists->allowed_domains)) {
        enforce(app, msg, cfg.link_action, "links to unapproved sites aren't allowed", cfg);
        return;
    }

    if (cfg.word_action != automod_off && !lists->filters.empty()) {
        const std::string lowered = to_lower(content);
        for (const FilterRow& f : lists->filters) {
            if (matches_filter(content, lowered, f)) {
                enforce(app, msg, cfg.word_action, "message matched the word filter", cfg);
                return;
            }
        }
    }

    if (cfg.mention_action != automod_off && cfg.mention_limit > 0) {
        const size_t mentions = msg.mentions.size() + msg.mention_roles.size() + (msg.mention_everyone ? 1 : 0);
        if (mentions > static_cast<size_t>(cfg.mention_limit)) {
            enforce(app, msg, cfg.mention_action, "too many mentions in one message", cfg);
            return;
        }
    }

    if (cfg.caps_action != automod_off && is_shouting(content, cfg.caps_percent, cfg.caps_min_len)) {
        enforce(app, msg, cfg.caps_action, "too many capital letters", cfg);
        return;
    }

    if (cfg.emoji_action != automod_off && cfg.emoji_limit > 0 && count_emoji(content) > cfg.emoji_limit) {
        enforce(app, msg, cfg.emoji_action, "too many emoji in one message", cfg);
        return;
    }

    // Repeated and rapid-fire messages share one per-user history.
    const bool watch_dup = cfg.dup_action != automod_off && cfg.dup_limit >= 2;
    const bool watch_spam = cfg.spam_action != automod_off && cfg.spam_limit > 0;
    if (!watch_dup && !watch_spam) return;

    std::vector<RecentMessage> burst;
    int action = automod_off;
    std::string reason;
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        auto& q = g_recent[{msg.guild_id, msg.author.id}];
        const int64_t now = now_ms();
        const size_t hash = duplicate_hash(content);
        q.push_back({now, hash, msg.channel_id, msg.id});
        while (!q.empty() && (now - q.front().at_ms > kKeepMessagesMs || q.size() > kKeepMessagesMax)) q.pop_front();

        if (watch_dup && hash != 0) {
            std::vector<RecentMessage> same;
            for (const auto& r : q) {
                if (r.hash == hash && now - r.at_ms <= static_cast<int64_t>(cfg.dup_window) * 1000) same.push_back(r);
            }
            if (same.size() >= static_cast<size_t>(cfg.dup_limit)) {
                burst = std::move(same);
                action = cfg.dup_action;
                reason = "repeating the same message";
            }
        }
        if (action == automod_off && watch_spam) {
            std::vector<RecentMessage> fast;
            for (const auto& r : q) {
                if (now - r.at_ms <= static_cast<int64_t>(cfg.spam_window) * 1000) fast.push_back(r);
            }
            if (fast.size() > static_cast<size_t>(cfg.spam_limit)) {
                burst = std::move(fast);
                action = cfg.spam_action;
                reason = "sending messages too fast";
            }
        }
        if (!burst.empty()) {
            // Forget what was just punished so the same burst isn't counted twice.
            q.erase(std::remove_if(q.begin(), q.end(),
                                   [&burst](const RecentMessage& r) {
                                       return std::any_of(burst.begin(), burst.end(), [&r](const RecentMessage& b) {
                                           return b.message_id == r.message_id;
                                       });
                                   }),
                    q.end());
        }
    }
    if (action != automod_off) enforce(app, msg, action, reason, cfg, burst);
}

void automod_on_member_join(App& app, const dpp::guild_member_add_t& event) {
    const uint64_t guild_id = event.added.guild_id;
    const uint64_t user_id = event.added.user_id;
    const GuildConfig cfg = app.db.get_config(guild_id);

    if (cfg.min_account_age > 0) {
        const double created = dpp::snowflake(user_id).get_creation_time();
        const double age_days = (static_cast<double>(now_s()) - created) / 86400.0;
        if (age_days < cfg.min_account_age) {
            heat_add(app, guild_id, 4.0, "join blocked by the minimum account age", user_id);
            action_kick(app, guild_id, user_id, app.bot.me.id,
                        "Automod: account is younger than " + std::to_string(cfg.min_account_age) + " day(s)");
            return;
        }
    }

    heat_on_member_join(app, event);
}

void automod_sweep() {
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        const int64_t now = now_ms();
        for (auto it = g_recent.begin(); it != g_recent.end();) {
            auto& q = it->second;
            while (!q.empty() && now - q.front().at_ms > kKeepMessagesMs) q.pop_front();
            it = q.empty() ? g_recent.erase(it) : std::next(it);
        }
    }
    heat_sweep();
}

}  // namespace flour
