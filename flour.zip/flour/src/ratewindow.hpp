#pragma once
#include <cstddef>
#include <cstdint>
#include <deque>

namespace flour {

// Counts events that happened within the last `window` seconds.
class RateWindow {
public:
    // Records an event at `now` (unix seconds) and returns how many are inside the window.
    size_t record(int64_t now, int64_t window) {
        events_.push_back(now);
        while (!events_.empty() && now - events_.front() >= window) events_.pop_front();
        return events_.size();
    }
    void clear() { events_.clear(); }

private:
    std::deque<int64_t> events_;
};

}  // namespace flour
