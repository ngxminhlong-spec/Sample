#include <algorithm>
#include <deque>
#include <iterator>
#include <map>
#include <mutex>
#include <optional>
#include <unordered_map>

#include "app.hpp"
#include "util.hpp"

namespace flour {

namespace {

constexpr size_t kMaxCachedMessages = 20000;   // message contents kept in memory for edit/delete logs
constexpr size_t kMaxMemberSnapshots = 300000; // nickname and role state kept for diffing
constexpr size_t kShownContent = 1000;

struct CachedMessage {
    uint64_t guild_id = 0;
    uint64_t channel_id = 0;
    uint64_t author_id = 0;
    std::string author_name;
    std::string content;
};

struct MemberSnapshot {
    std::string nickname;
    std::vector<uint64_t> roles;  // sorted, so diffs are set operations
};

std::mutex g_mutex;
std::unordered_map<uint64_t, CachedMessage> g_messages;
std::deque<uint64_t> g_message_order;
std::map<std::pair<uint64_t, uint64_t>, MemberSnapshot> g_members;
std::map<std::pair<uint64_t, uint64_t>, uint64_t> g_voice;  // (guild, user) -> voice channel

std::string mention(uint64_t id) { return "<@" + std::to_string(id) + ">"; }
std::string channel_ref(uint64_t id) { return "<#" + std::to_string(id) + ">"; }
std::string role_ref(uint64_t id) { return "<@&" + std::to_string(id) + ">"; }

std::string shown(const std::string& s, size_t max = kShownContent) {
    return s.empty() ? "*(empty)*" : truncate(s, max);
}

std::string jump_link(uint64_t guild, uint64_t channel, uint64_t message) {
    return "https://discord.com/channels/" + std::to_string(guild) + "/" + std::to_string(channel) + "/" +
           std::to_string(message);
}

std::vector<uint64_t> sorted_roles(const dpp::guild_member& m) {
    std::vector<uint64_t> out;
    for (const dpp::snowflake& r : m.get_roles()) out.push_back(static_cast<uint64_t>(r));
    std::sort(out.begin(), out.end());
    return out;
}

void remember_message(uint64_t id, CachedMessage msg) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_messages.find(id) == g_messages.end()) g_message_order.push_back(id);
    g_messages[id] = std::move(msg);
    while (g_message_order.size() > kMaxCachedMessages) {
        g_messages.erase(g_message_order.front());
        g_message_order.pop_front();
    }
}

std::optional<CachedMessage> peek_message(uint64_t id) {
    std::lock_guard<std::mutex> lock(g_mutex);
    auto it = g_messages.find(id);
    if (it == g_messages.end()) return std::nullopt;
    return it->second;
}

std::optional<CachedMessage> take_message(uint64_t id) {
    std::lock_guard<std::mutex> lock(g_mutex);
    auto it = g_messages.find(id);
    if (it == g_messages.end()) return std::nullopt;
    CachedMessage m = std::move(it->second);
    g_messages.erase(it);  // its id stays in g_message_order and is skipped when it ages out
    return m;
}

void store_member(std::pair<uint64_t, uint64_t> key, MemberSnapshot snap) {
    std::lock_guard<std::mutex> lock(g_mutex);
    // Past the cap, start over. Nickname and role changes for members not re-seen are missed until then.
    if (g_members.size() >= kMaxMemberSnapshots && g_members.find(key) == g_members.end()) g_members.clear();
    g_members[key] = std::move(snap);
}

std::optional<MemberSnapshot> find_member(std::pair<uint64_t, uint64_t> key) {
    std::lock_guard<std::mutex> lock(g_mutex);
    auto it = g_members.find(key);
    if (it == g_members.end()) return std::nullopt;
    return it->second;
}

dpp::embed base_embed(const std::string& title, uint32_t color) {
    dpp::embed e;
    e.set_title(title);
    e.set_color(color);
    e.set_timestamp(time(nullptr));
    return e;
}

// Posts to the log channel if logging is on for this server and this kind of event is enabled.
void post(App& app, uint64_t guild_id, LogEvent kind, const dpp::embed& e) {
    const LogConfig lc = app.db.get_log_config(guild_id);
    if (lc.channel_id == 0 || (lc.events & kind) == 0) return;
    app.bot.message_create(dpp::message(lc.channel_id, e),
        [&app](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) app.bot.log(dpp::ll_warning, "logging: " + cb.get_error().message);
        });
}

}  // namespace

// ============================================================ message events

void logging_on_message(App&, const dpp::message_create_t& event) {
    const dpp::message& m = event.msg;
    if (m.guild_id == 0 || m.author.is_bot()) return;

    CachedMessage c;
    c.guild_id = static_cast<uint64_t>(m.guild_id);
    c.channel_id = static_cast<uint64_t>(m.channel_id);
    c.author_id = static_cast<uint64_t>(m.author.id);
    c.author_name = m.author.username;
    c.content = m.content;
    remember_message(static_cast<uint64_t>(m.id), std::move(c));
}

void logging_on_message_update(App& app, const dpp::message_update_t& event) {
    const dpp::message& m = event.msg;
    const uint64_t id = static_cast<uint64_t>(m.id);

    // Discord also sends updates for embeds and pins. Those come without a content change, so skip them.
    if (m.content.empty()) return;

    // Only edits of messages we saw earlier can be compared. Messages from before a restart are skipped.
    auto before = peek_message(id);
    if (!before) return;

    CachedMessage after = *before;
    after.content = m.content;
    remember_message(id, after);
    if (before->content == m.content) return;

    dpp::embed e = base_embed("Message edited", color::warn);
    e.add_field("Author", mention(before->author_id) + " in " + channel_ref(before->channel_id), true);
    e.add_field("Before", shown(before->content), false);
    e.add_field("After", shown(m.content), false);
    e.add_field("Jump", "[Open message](" + jump_link(before->guild_id, before->channel_id, id) + ")", false);
    post(app, before->guild_id, log_messages, e);
}

void logging_on_message_delete(App& app, const dpp::message_delete_t& event) {
    const uint64_t guild = static_cast<uint64_t>(event.guild_id);
    const uint64_t channel = static_cast<uint64_t>(event.channel_id);
    if (guild == 0) return;

    auto old = take_message(static_cast<uint64_t>(event.id));
    dpp::embed e = base_embed("Message deleted", color::danger);
    if (old) {
        e.add_field("Author", mention(old->author_id) + " in " + channel_ref(channel), true);
        e.add_field("Content", shown(old->content), false);
    } else {
        // Sent before the bot started, or by a bot. The content was never seen, so only the basics are shown.
        e.add_field("Channel", channel_ref(channel), true);
        e.set_description("Content not available (the message was sent before Flour started watching this server).");
    }
    post(app, guild, log_messages, e);
}

void logging_on_message_delete_bulk(App& app, const dpp::message_delete_bulk_t& event) {
    const uint64_t guild = static_cast<uint64_t>(event.deleting_channel.guild_id);
    const uint64_t channel = static_cast<uint64_t>(event.deleting_channel.id);
    if (guild == 0) return;

    std::string lines;
    size_t known = 0;
    for (const dpp::snowflake& id : event.deleted) {
        auto old = take_message(static_cast<uint64_t>(id));
        if (!old) continue;
        ++known;
        if (known <= 10) lines += "**" + old->author_name + "**: " + shown(old->content, 200) + "\n";
    }

    dpp::embed e = base_embed("Messages bulk deleted", color::danger);
    e.add_field("Channel", channel_ref(channel), true);
    e.add_field("Count", std::to_string(event.deleted.size()), true);
    if (known > 0) {
        std::string body = lines;
        if (known > 10) body += "...and " + std::to_string(known - 10) + " more with content cached";
        e.add_field("Recovered", truncate(body, 1000), false);
    }
    post(app, guild, log_messages, e);
}

// ============================================================ member events

void logging_on_member_add(App& app, const dpp::guild_member_add_t& event) {
    const uint64_t guild = static_cast<uint64_t>(event.added.guild_id);
    const uint64_t user = static_cast<uint64_t>(event.added.user_id);
    if (guild == 0) return;

    store_member({guild, user}, MemberSnapshot{event.added.get_nickname(), sorted_roles(event.added)});

    const double created = dpp::snowflake(user).get_creation_time();
    dpp::embed e = base_embed("Member joined", color::ok);
    e.add_field("Member", mention(user), true);
    e.add_field("Account created", discord_time(static_cast<int64_t>(created), 'R'), true);
    post(app, guild, log_members, e);
}

void logging_on_member_remove(App& app, const dpp::guild_member_remove_t& event) {
    const uint64_t guild = static_cast<uint64_t>(event.guild_id);
    const uint64_t user = static_cast<uint64_t>(event.removed.id);
    if (guild == 0) return;

    {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_members.erase({guild, user});
    }

    dpp::embed e = base_embed("Member left", color::neutral);
    e.add_field("Member", mention(user) + " (" + event.removed.username + ")", true);
    e.set_footer(dpp::embed_footer().set_text("Kicks and bans show up here too. Check the mod log for the reason."));
    post(app, guild, log_members, e);
}

void logging_on_member_update(App& app, const dpp::guild_member_update_t& event) {
    const dpp::guild_member& m = event.updated;
    const uint64_t guild = static_cast<uint64_t>(event.updating_guild.id);
    const uint64_t user = static_cast<uint64_t>(m.user_id);
    if (guild == 0 || user == 0) return;

    MemberSnapshot now{m.get_nickname(), sorted_roles(m)};
    auto before = find_member({guild, user});
    store_member({guild, user}, now);
    if (!before) return;  // first time we've seen this member, so there's nothing to compare against

    if (before->nickname != now.nickname) {
        dpp::embed e = base_embed("Nickname changed", color::info);
        e.add_field("Member", mention(user), true);
        e.add_field("Before", before->nickname.empty() ? "*(none)*" : shown(before->nickname, 100), true);
        e.add_field("After", now.nickname.empty() ? "*(none)*" : shown(now.nickname, 100), true);
        post(app, guild, log_nicknames, e);
    }

    std::vector<uint64_t> added, removed;
    std::set_difference(now.roles.begin(), now.roles.end(), before->roles.begin(), before->roles.end(),
                        std::back_inserter(added));
    std::set_difference(before->roles.begin(), before->roles.end(), now.roles.begin(), now.roles.end(),
                        std::back_inserter(removed));
    if (!added.empty() || !removed.empty()) {
        auto list = [](const std::vector<uint64_t>& ids) {
            std::string out;
            for (uint64_t id : ids) out += role_ref(id) + " ";
            return out.empty() ? std::string("*(none)*") : out;
        };
        dpp::embed e = base_embed("Roles changed", color::info);
        e.add_field("Member", mention(user), true);
        e.add_field("Added", list(added), false);
        e.add_field("Removed", list(removed), false);
        post(app, guild, log_roles, e);
    }
}

// ============================================================ voice

void logging_on_voice_state(App& app, const dpp::voice_state_update_t& event) {
    const uint64_t guild = static_cast<uint64_t>(event.state.guild_id);
    const uint64_t user = static_cast<uint64_t>(event.state.user_id);
    const uint64_t now_channel = static_cast<uint64_t>(event.state.channel_id);
    if (guild == 0 || user == 0) return;

    uint64_t before_channel = 0;
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        auto it = g_voice.find({guild, user});
        if (it != g_voice.end()) before_channel = it->second;
        if (now_channel) g_voice[{guild, user}] = now_channel;
        else g_voice.erase({guild, user});
    }

    // Mute, deafen and camera changes keep the same channel, so they're ignored here.
    if (before_channel == now_channel) return;

    dpp::embed e;
    if (before_channel == 0) {
        e = base_embed("Joined voice", color::ok);
        e.add_field("Member", mention(user), true);
        e.add_field("Channel", channel_ref(now_channel), true);
    } else if (now_channel == 0) {
        e = base_embed("Left voice", color::neutral);
        e.add_field("Member", mention(user), true);
        e.add_field("Channel", channel_ref(before_channel), true);
    } else {
        e = base_embed("Moved voice channel", color::info);
        e.add_field("Member", mention(user), true);
        e.add_field("From", channel_ref(before_channel), true);
        e.add_field("To", channel_ref(now_channel), true);
    }
    e.set_footer(dpp::embed_footer().set_text("Only changes seen since Flour started are logged."));
    post(app, guild, log_voice, e);
}

// ============================================================ /logs

namespace {

struct EventChoice {
    const char* key;
    const char* label;
    int bit;
};

const EventChoice kEvents[] = {
    {"messages", "Message edits and deletes", log_messages},
    {"members", "Joins and leaves", log_members},
    {"roles", "Role changes", log_roles},
    {"nicknames", "Nickname changes", log_nicknames},
    {"voice", "Voice joins, leaves and moves", log_voice},
};

const EventChoice* find_event(const std::string& key) {
    for (const EventChoice& ev : kEvents) {
        if (key == ev.key) return &ev;
    }
    return nullptr;
}

void cmd_logs_set(App& app, const dpp::slashcommand_t& e) {
    const uint64_t gid = e.command.guild_id;
    const dpp::snowflake channel = opt_id(e, "channel");

    e.thinking(true);
    app.bot.message_create(dpp::message(channel, "Flour will post server activity logs here."),
        [&app, e, gid, channel](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) {
                e.edit_response(dpp::message("I can't send messages in that channel. Give me **View Channel**, "
                                             "**Send Messages** and **Embed Links** there, then try again.")
                                    .set_flags(dpp::m_ephemeral));
                return;
            }
            app.db.set_log_channel(gid, channel);
            e.edit_response(dpp::message("Server logs will go to <#" +
                                         std::to_string(static_cast<uint64_t>(channel)) + ">.")
                                .set_flags(dpp::m_ephemeral));
        });
}

void cmd_logs_off(App& app, const dpp::slashcommand_t& e) {
    app.db.set_log_channel(e.command.guild_id, 0);
    e.reply(dpp::message("Server logs are off.").set_flags(dpp::m_ephemeral));
}

void cmd_logs_toggle(App& app, const dpp::slashcommand_t& e) {
    const EventChoice* ev = find_event(opt_str(e, "event"));
    if (!ev) return reply_error(e, "Unknown event type.");

    const uint64_t gid = e.command.guild_id;
    int events = app.db.get_log_config(gid).events;
    events = opt_bool(e, "enabled", true) ? (events | ev->bit) : (events & ~ev->bit);
    app.db.set_log_events(gid, events);

    e.reply(dpp::message(std::string(ev->label) + " are now " +
                         ((events & ev->bit) ? "logged." : "not logged."))
                .set_flags(dpp::m_ephemeral));
}

void cmd_logs_show(App& app, const dpp::slashcommand_t& e) {
    const LogConfig lc = app.db.get_log_config(e.command.guild_id);

    dpp::embed emb;
    emb.set_color(color::info);
    emb.set_title("Server logs");
    emb.set_description(lc.channel_id ? "Posting to <#" + std::to_string(lc.channel_id) + ">"
                                      : "Logging is off. Turn it on with `/logs set`.");
    for (const EventChoice& ev : kEvents) {
        emb.add_field(ev.label, (lc.events & ev.bit) ? "on" : "off", true);
    }
    dpp::message m;
    m.add_embed(emb);
    m.set_flags(dpp::m_ephemeral);
    e.reply(m);
}

}  // namespace

std::vector<dpp::slashcommand> build_logging_commands(dpp::snowflake bot_id) {
    dpp::command_option event_opt(dpp::co_string, "event", "What kind of activity", true);
    for (const EventChoice& ev : kEvents) event_opt.add_choice(dpp::command_option_choice(ev.label, std::string(ev.key)));

    std::vector<dpp::slashcommand> cmds;
    cmds.push_back(make_command("logs", "Log server activity to a channel", bot_id, dpp::p_manage_guild)
        .add_option(dpp::command_option(dpp::co_sub_command, "set", "Choose the log channel")
            .add_option(dpp::command_option(dpp::co_channel, "channel", "Where logs are posted", true)
                            .add_channel_type(dpp::CHANNEL_TEXT)))
        .add_option(dpp::command_option(dpp::co_sub_command, "off", "Stop logging"))
        .add_option(dpp::command_option(dpp::co_sub_command, "toggle", "Turn one kind of event on or off")
            .add_option(event_opt)
            .add_option(dpp::command_option(dpp::co_boolean, "enabled", "On or off", true)))
        .add_option(dpp::command_option(dpp::co_sub_command, "show", "Show what is being logged")));
    return cmds;
}

bool handle_logging_command(App& app, const dpp::slashcommand_t& e) {
    if (e.command.get_command_name() != "logs") return false;

    const std::string sub = subcommand_name(e);
    if (sub == "set") cmd_logs_set(app, e);
    else if (sub == "off") cmd_logs_off(app, e);
    else if (sub == "toggle") cmd_logs_toggle(app, e);
    else if (sub == "show") cmd_logs_show(app, e);
    return true;
}

}  // namespace flour
