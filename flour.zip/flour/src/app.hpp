#pragma once
#include <dpp/dpp.h>

#include <functional>
#include <string>
#include <vector>

#include "database.hpp"

namespace flour {

// The web dashboard. Bind it to 127.0.0.1 and put `tailscale serve` in front of it.
struct DashboardConfig {
    bool enabled = false;
    std::string host = "127.0.0.1";
    int port = 8080;
    std::string client_id;
    std::string client_secret;
    std::string redirect_uri;  // must match the OAuth2 redirect in the developer portal
};

struct Config {
    std::string token;
    std::string database_path = "flour.db";
    uint64_t dev_guild_id = 0;  // if set, slash commands register to this guild only (instant)
    DashboardConfig dashboard;
};

// Everything the handlers need, passed around by reference.
struct App {
    dpp::cluster& bot;
    Database& db;
    Config config;
};

// ---- modlog.cpp ----------------------------------------------------------

// Stores a case and posts it to the guild's mod log channel (if one is set).
CaseRow record_case(App& app, uint64_t guild_id, uint64_t user_id, uint64_t mod_id,
                    const std::string& action, const std::string& reason,
                    int64_t expires_at = 0, bool active = true);

// Free-form entry for things that aren't tied to a user (purge, lock, config changes...).
void log_event(App& app, uint64_t guild_id, const std::string& title,
               const std::string& description, uint32_t color);

dpp::embed case_embed(const CaseRow& c);

// ---- commands.cpp / config_commands.cpp -----------------------------------

std::vector<dpp::slashcommand> build_commands(dpp::snowflake bot_id);
void handle_slashcommand(App& app, const dpp::slashcommand_t& event);

// config_commands.cpp
std::vector<dpp::slashcommand> build_config_commands(dpp::snowflake bot_id);
bool handle_config_command(App& app, const dpp::slashcommand_t& event);

// Shared helpers (commands.cpp)
void reply_error(const dpp::slashcommand_t& event, const std::string& text);
// Option lookups that also work inside subcommands.
dpp::command_value find_option_value(const dpp::slashcommand_t& event, const std::string& name);
std::string opt_str(const dpp::slashcommand_t& event, const std::string& name, const std::string& def = "");
int64_t opt_int(const dpp::slashcommand_t& event, const std::string& name, int64_t def = 0);
bool opt_bool(const dpp::slashcommand_t& event, const std::string& name, bool def = false);
dpp::snowflake opt_id(const dpp::slashcommand_t& event, const std::string& name);
std::string subcommand_name(const dpp::slashcommand_t& event);
// A command that only works in servers, visible to members holding `default_permissions`.
dpp::slashcommand make_command(const std::string& name, const std::string& description,
                               dpp::snowflake bot_id, uint64_t default_permissions);

// ---- automod.cpp ------------------------------------------------------------

void automod_on_message(App& app, const dpp::message_create_t& event);
void automod_on_member_join(App& app, const dpp::guild_member_add_t& event);
void automod_sweep();

// ---- heat.cpp ---------------------------------------------------------------
//
// Each server has a "heat" value. Suspicious events add to it, it cools over time, and the
// response gets stricter as it crosses the warm / hot / critical thresholds.

enum HeatLevel { heat_calm = 0, heat_warm = 1, heat_hot = 2, heat_critical = 3 };

struct HeatReading {
    double heat = 0;
    int level = heat_calm;
};

const char* heat_level_name(int level);
// Adds heat (no-op if the system is off for this server) and applies any level change.
// `skip_user` is left alone if a lockdown sweep happens (the caller is handling them).
HeatReading heat_add(App& app, uint64_t guild_id, double points, const std::string& why,
                     uint64_t skip_user = 0);
HeatReading heat_peek(App& app, uint64_t guild_id);
void heat_reset(App& app, uint64_t guild_id);
void heat_on_member_join(App& app, const dpp::guild_member_add_t& event);
void heat_sweep();
std::string heat_bar(double heat, double max_value);

// Moderation actions the automod and the slash commands share.
// DMs the user (best effort, failures ignored), then runs `next` either way.
// If `appeal_guild` is set and that server has ban appeals switched on, the DM carries an
// "Appeal this ban" button.
void dm_then(App& app, uint64_t user_id, const std::string& text, std::function<void()> next,
             uint64_t appeal_guild = 0);
void action_timeout(App& app, uint64_t guild_id, uint64_t user_id, uint64_t mod_id,
                    int64_t seconds, const std::string& reason);
void action_ban(App& app, uint64_t guild_id, uint64_t user_id, uint64_t mod_id,
                const std::string& reason);
void action_kick(App& app, uint64_t guild_id, uint64_t user_id, uint64_t mod_id,
                 const std::string& reason, bool send_dm = true);
// Adds a warn case and applies the escalation ladder. Returns a short description of any
// escalation that was triggered (empty if none).
std::string action_warn(App& app, uint64_t guild_id, uint64_t user_id, uint64_t mod_id,
                        const std::string& reason, int* active_warns_out = nullptr,
                        int64_t* case_num_out = nullptr);

// ---- automod_commands.cpp -----------------------------------------------------------

std::vector<dpp::slashcommand> build_automod_commands(dpp::snowflake bot_id);
bool handle_automod_command(App& app, const dpp::slashcommand_t& event);
// "spam, links" or "all rules off", for /config show
std::string automod_summary(const GuildConfig& cfg);

// ---- tickets.cpp ------------------------------------------------------------------

std::vector<dpp::slashcommand> build_ticket_commands(dpp::snowflake bot_id);
bool handle_ticket_command(App& app, const dpp::slashcommand_t& event);
void handle_button(App& app, const dpp::button_click_t& event);
void handle_form(App& app, const dpp::form_submit_t& event);
void ticket_on_channel_delete(App& app, uint64_t channel_id);

// ---- logging.cpp -----------------------------------------------------------------

enum LogEvent : int {
    log_messages = 1,   // edits and deletes
    log_members = 2,    // joins and leaves
    log_roles = 4,      // role added or removed
    log_nicknames = 8,
    log_voice = 16,     // voice join, leave, move
};

void logging_on_message(App& app, const dpp::message_create_t& event);
void logging_on_message_update(App& app, const dpp::message_update_t& event);
void logging_on_message_delete(App& app, const dpp::message_delete_t& event);
void logging_on_message_delete_bulk(App& app, const dpp::message_delete_bulk_t& event);
void logging_on_member_add(App& app, const dpp::guild_member_add_t& event);
void logging_on_member_remove(App& app, const dpp::guild_member_remove_t& event);
void logging_on_member_update(App& app, const dpp::guild_member_update_t& event);
void logging_on_voice_state(App& app, const dpp::voice_state_update_t& event);

std::vector<dpp::slashcommand> build_logging_commands(dpp::snowflake bot_id);
bool handle_logging_command(App& app, const dpp::slashcommand_t& event);

// ---- antinuke.cpp ---------------------------------------------------------------

void antinuke_on_ban(App& app, const dpp::guild_ban_add_t& event);
void antinuke_on_kick(App& app, const dpp::guild_member_remove_t& event);
void antinuke_on_channel_delete(App& app, const dpp::channel_delete_t& event);
void antinuke_on_role_delete(App& app, const dpp::guild_role_delete_t& event);
void antinuke_on_role_create(App& app, const dpp::guild_role_create_t& event);
void antinuke_on_role_update(App& app, const dpp::guild_role_update_t& event);
void antinuke_on_member_update(App& app, const dpp::guild_member_update_t& event);
void antinuke_on_webhooks(App& app, const dpp::webhooks_update_t& event);

std::vector<dpp::slashcommand> build_antinuke_commands(dpp::snowflake bot_id);
bool handle_antinuke_command(App& app, const dpp::slashcommand_t& event);

// ---- archive.cpp -----------------------------------------------------------------

void archive_on_member(App& app, uint64_t guild_id, const dpp::guild_member& member);
void archive_on_member_remove(App& app, uint64_t guild_id, uint64_t user_id);
void archive_on_channel(App& app, uint64_t guild_id, const dpp::channel& channel);
void archive_on_channel_delete(App& app, uint64_t guild_id, uint64_t channel_id);
void archive_capture_role_overwrites(App& app, uint64_t guild_id, uint64_t role_id);
void archive_seed(App& app);

// ---- dashboard.cpp ---------------------------------------------------------------

void start_dashboard(App& app, const DashboardConfig& cfg);

// ---- scheduler.cpp ------------------------------------------------------------

void start_scheduler(App& app);

}  // namespace flour
