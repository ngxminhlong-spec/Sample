#include <algorithm>
#include <optional>

#include "app.hpp"
#include "util.hpp"

namespace flour {

namespace {

using Event = dpp::slashcommand_t;

struct Rule {
    const char* key;
    const char* label;
    int GuildConfig::*field;
    const char* column;
};

const Rule kRules[] = {
    {"spam", "Spam", &GuildConfig::spam_action, "spam_action"},
    {"duplicates", "Repeated messages", &GuildConfig::dup_action, "dup_action"},
    {"mentions", "Mass mentions", &GuildConfig::mention_action, "mention_action"},
    {"invites", "Invite links", &GuildConfig::invite_action, "invite_action"},
    {"links", "Link allowlist", &GuildConfig::link_action, "link_action"},
    {"words", "Word filter", &GuildConfig::word_action, "word_action"},
    {"caps", "Excessive caps", &GuildConfig::caps_action, "caps_action"},
    {"emoji", "Emoji spam", &GuildConfig::emoji_action, "emoji_action"},
};

const char* kActionNames[] = {"off", "delete", "warn", "timeout"};

struct Tunable {
    const char* key;
    const char* label;
    int64_t min;
    int64_t max;
};

const Tunable kTunables[] = {
    {"spam_limit", "Spam: messages allowed per window", 1, 30},
    {"spam_window", "Spam: window in seconds", 1, 60},
    {"dup_limit", "Repeats: identical messages that trigger it", 2, 20},
    {"dup_window", "Repeats: window in seconds", 5, 300},
    {"mention_limit", "Mentions: allowed per message", 1, 50},
    {"caps_percent", "Caps: percent of letters that must be capitals", 40, 100},
    {"caps_min_len", "Caps: ignore messages with fewer letters than this", 5, 200},
    {"emoji_limit", "Emoji: allowed per message", 1, 100},
    {"automod_timeout_mins", "Length of auto-mod timeouts, in minutes", 1, 40320},
};

dpp::message ephemeral(const std::string& text) {
    return dpp::message(text).set_flags(dpp::m_ephemeral);
}

std::string mention(uint64_t id) { return "<@" + std::to_string(id) + ">"; }

const Rule* find_rule(const std::string& key) {
    for (const Rule& r : kRules) {
        if (key == r.key) return &r;
    }
    return nullptr;
}

int action_from_name(const std::string& name) {
    for (int i = 0; i < 4; ++i) {
        if (name == kActionNames[i]) return i;
    }
    return -1;
}

std::string rule_detail(const std::string& key, const GuildConfig& c, const AutomodLists& lists) {
    if (key == "spam") return "more than " + std::to_string(c.spam_limit) + " messages in " + std::to_string(c.spam_window) + "s";
    if (key == "duplicates") return std::to_string(c.dup_limit) + " identical messages in " + std::to_string(c.dup_window) + "s";
    if (key == "mentions") return "more than " + std::to_string(c.mention_limit) + " per message";
    if (key == "invites") return "Discord invite links";
    if (key == "links") return "everything except " + std::to_string(lists.allowed_domains.size()) + " approved site(s)";
    if (key == "words") return std::to_string(lists.filters.size()) + " filter(s)";
    if (key == "caps") return std::to_string(c.caps_percent) + "% capitals, " + std::to_string(c.caps_min_len) + "+ letters";
    if (key == "emoji") return "more than " + std::to_string(c.emoji_limit) + " per message";
    return "";
}

std::optional<std::string> normalize_domain(std::string d) {
    d = to_lower(d);
    for (const char* prefix : {"https://", "http://"}) {
        if (d.rfind(prefix, 0) == 0) d = d.substr(std::string(prefix).size());
    }
    const size_t cut = d.find_first_of("/?#:");
    if (cut != std::string::npos) d = d.substr(0, cut);
    if (d.rfind("www.", 0) == 0) d = d.substr(4);

    if (d.size() < 3 || d.size() > 100 || d.find('.') == std::string::npos) return std::nullopt;
    if (d.front() == '.' || d.back() == '.' || d.front() == '-' || d.back() == '-') return std::nullopt;
    for (char c : d) {
        if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '.' || c == '-')) return std::nullopt;
    }
    return d;
}

void cmd_show(App& app, const Event& e) {
    const GuildConfig c = app.db.get_config(e.command.guild_id);
    const auto lists = app.db.get_automod_lists(e.command.guild_id);

    dpp::embed emb;
    emb.set_color(color::info);
    emb.set_title("Auto-mod rules");
    for (const Rule& r : kRules) {
        const int action = c.*(r.field);
        std::string value = std::string("**") + kActionNames[action] + "**";
        if (action != automod_off) value += "\n" + rule_detail(r.key, c, *lists);
        emb.add_field(r.label, value, true);
    }
    emb.add_field("Exempt",
                  std::to_string(lists->exempt_roles.size()) + " role(s), " +
                      std::to_string(lists->exempt_channels.size()) + " channel(s)",
                  true);
    emb.set_footer(dpp::embed_footer().set_text(
        "Timeouts last " + format_duration(static_cast<int64_t>(c.automod_timeout_mins) * 60) +
        ". Moderators are always exempt. Change a rule with /automod rule."));

    dpp::message m;
    m.add_embed(emb);
    m.set_flags(dpp::m_ephemeral);
    e.reply(m);
}

void cmd_rule(App& app, const Event& e) {
    const uint64_t gid = e.command.guild_id;
    const Rule* rule = find_rule(opt_str(e, "name"));
    const int action = action_from_name(opt_str(e, "action"));
    if (!rule || action < 0) return reply_error(e, "Unknown rule or action.");

    app.db.set_config_value(gid, rule->column, action);

    // Servers upgraded from older versions can have a zero threshold stored. Give those a sane value.
    if (action != automod_off) {
        const GuildConfig c = app.db.get_config(gid);
        const std::string key = rule->key;
        if (key == "spam" && c.spam_limit <= 0) app.db.set_config_value(gid, "spam_limit", 6);
        if (key == "spam" && c.spam_window <= 0) app.db.set_config_value(gid, "spam_window", 5);
        if (key == "mentions" && c.mention_limit <= 0) app.db.set_config_value(gid, "mention_limit", 5);
    }

    log_event(app, gid, "Auto-mod changed",
              mention(e.command.usr.id) + " set **" + rule->label + "** to **" + kActionNames[action] + "**",
              color::info);

    std::string text = std::string("**") + rule->label + "** is now **" + kActionNames[action] + "**.";
    const auto lists = app.db.get_automod_lists(gid);
    if (action != automod_off && std::string(rule->key) == "words" && lists->filters.empty()) {
        text += "\nThere are no filters yet. Add some with `/filter add`.";
    }
    if (action != automod_off && std::string(rule->key) == "links" && lists->allowed_domains.empty()) {
        text += "\nNo sites are approved yet, so every link will be removed. Approve some with `/automod allow-domain`.";
    }
    e.reply(ephemeral(text));
}

void cmd_tune(App& app, const Event& e) {
    const uint64_t gid = e.command.guild_id;
    const std::string key = opt_str(e, "setting");
    const int64_t value = opt_int(e, "value");

    const Tunable* t = nullptr;
    for (const Tunable& candidate : kTunables) {
        if (key == candidate.key) t = &candidate;
    }
    if (!t) return reply_error(e, "Unknown setting.");
    if (value < t->min || value > t->max) {
        return reply_error(e, "`" + key + "` must be between " + std::to_string(t->min) + " and " + std::to_string(t->max) + ".");
    }
    app.db.set_config_value(gid, key, value);
    log_event(app, gid, "Auto-mod changed",
              mention(e.command.usr.id) + " set `" + key + "` to `" + std::to_string(value) + "`", color::info);
    e.reply(ephemeral("`" + key + "` is now `" + std::to_string(value) + "`."));
}

void cmd_exempt(App& app, const Event& e, const std::string& kind) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t target = opt_id(e, kind);
    const bool remove = opt_bool(e, "remove", false);
    const std::string shown = kind == "role" ? "<@&" + std::to_string(target) + ">" : "<#" + std::to_string(target) + ">";

    if (remove) {
        if (!app.db.remove_exempt(gid, kind, target)) return reply_error(e, shown + " wasn't exempt.");
        e.reply(ephemeral(shown + " is no longer exempt from auto-mod."));
    } else {
        if (!app.db.add_exempt(gid, kind, target)) return reply_error(e, shown + " is already exempt.");
        e.reply(ephemeral(shown + " is now exempt from every auto-mod rule."));
    }
}

void cmd_exempt_list(App& app, const Event& e) {
    const auto lists = app.db.get_automod_lists(e.command.guild_id);
    std::string roles, channels;
    for (uint64_t id : lists->exempt_roles) roles += "<@&" + std::to_string(id) + "> ";
    for (uint64_t id : lists->exempt_channels) channels += "<#" + std::to_string(id) + "> ";

    dpp::embed emb;
    emb.set_color(color::info);
    emb.set_title("Auto-mod exemptions");
    emb.add_field("Roles", roles.empty() ? "None" : roles, false);
    emb.add_field("Channels", channels.empty() ? "None" : channels, false);

    dpp::message m;
    m.add_embed(emb);
    m.set_flags(dpp::m_ephemeral);
    e.reply(m);
}

void cmd_domain(App& app, const Event& e, bool add) {
    const uint64_t gid = e.command.guild_id;
    auto domain = normalize_domain(opt_str(e, "domain"));
    if (!domain) return reply_error(e, "That doesn't look like a domain. Try something like `youtube.com`.");

    if (add) {
        if (!app.db.add_domain(gid, *domain)) return reply_error(e, "`" + *domain + "` is already approved.");
        e.reply(ephemeral("`" + *domain + "` and its subdomains are approved."));
    } else {
        if (!app.db.remove_domain(gid, *domain)) return reply_error(e, "`" + *domain + "` wasn't on the list.");
        e.reply(ephemeral("`" + *domain + "` is no longer approved."));
    }
}

void cmd_domains(App& app, const Event& e) {
    const auto lists = app.db.get_automod_lists(e.command.guild_id);
    std::string body;
    for (const std::string& d : lists->allowed_domains) body += "`" + d + "`\n";
    if (body.empty()) body = "No sites are approved yet.";

    dpp::embed emb;
    emb.set_color(color::info);
    emb.set_title("Approved sites");
    emb.set_description(truncate(body, 4000));

    dpp::message m;
    m.add_embed(emb);
    m.set_flags(dpp::m_ephemeral);
    e.reply(m);
}

}  // namespace

std::string automod_summary(const GuildConfig& c) {
    std::string out;
    for (const Rule& r : kRules) {
        if (c.*(r.field) != automod_off) out += (out.empty() ? "" : ", ") + std::string(r.key);
    }
    return out.empty() ? "all rules off" : out;
}

std::vector<dpp::slashcommand> build_automod_commands(dpp::snowflake bot_id) {
    dpp::command_option rule_name(dpp::co_string, "name", "Which rule", true);
    for (const Rule& r : kRules) rule_name.add_choice(dpp::command_option_choice(r.label, std::string(r.key)));

    dpp::command_option rule_action(dpp::co_string, "action", "What to do when someone breaks it", true);
    rule_action.add_choice(dpp::command_option_choice("Off", std::string("off")));
    rule_action.add_choice(dpp::command_option_choice("Delete the message only", std::string("delete")));
    rule_action.add_choice(dpp::command_option_choice("Delete and warn (counts toward the warning ladder)", std::string("warn")));
    rule_action.add_choice(dpp::command_option_choice("Delete and time the user out", std::string("timeout")));

    dpp::command_option tune_setting(dpp::co_string, "setting", "What to change", true);
    for (const Tunable& t : kTunables) tune_setting.add_choice(dpp::command_option_choice(t.label, std::string(t.key)));

    std::vector<dpp::slashcommand> cmds;
    cmds.push_back(make_command("automod", "Configure auto-moderation", bot_id, dpp::p_manage_guild)
        .add_option(dpp::command_option(dpp::co_sub_command, "show", "Show every rule and what it does"))
        .add_option(dpp::command_option(dpp::co_sub_command, "rule", "Turn a rule on, off, or change its punishment")
                        .add_option(rule_name).add_option(rule_action))
        .add_option(dpp::command_option(dpp::co_sub_command, "tune", "Change a rule's thresholds")
                        .add_option(tune_setting)
                        .add_option(dpp::command_option(dpp::co_integer, "value", "The new value", true).set_min_value(1)))
        .add_option(dpp::command_option(dpp::co_sub_command, "exempt-role", "Exempt a role from every rule")
                        .add_option(dpp::command_option(dpp::co_role, "role", "The role", true))
                        .add_option(dpp::command_option(dpp::co_boolean, "remove", "Remove the exemption instead", false)))
        .add_option(dpp::command_option(dpp::co_sub_command, "exempt-channel", "Exempt a channel from every rule")
                        .add_option(dpp::command_option(dpp::co_channel, "channel", "The channel", true))
                        .add_option(dpp::command_option(dpp::co_boolean, "remove", "Remove the exemption instead", false)))
        .add_option(dpp::command_option(dpp::co_sub_command, "exempt-list", "List exempt roles and channels"))
        .add_option(dpp::command_option(dpp::co_sub_command, "allow-domain", "Approve a site for the link rule")
                        .add_option(dpp::command_option(dpp::co_string, "domain", "e.g. youtube.com", true)))
        .add_option(dpp::command_option(dpp::co_sub_command, "remove-domain", "Stop approving a site")
                        .add_option(dpp::command_option(dpp::co_string, "domain", "e.g. youtube.com", true)))
        .add_option(dpp::command_option(dpp::co_sub_command, "domains", "List approved sites")));
    return cmds;
}

bool handle_automod_command(App& app, const dpp::slashcommand_t& e) {
    if (e.command.get_command_name() != "automod") return false;

    const std::string sub = subcommand_name(e);
    if (sub == "show") cmd_show(app, e);
    else if (sub == "rule") cmd_rule(app, e);
    else if (sub == "tune") cmd_tune(app, e);
    else if (sub == "exempt-role") cmd_exempt(app, e, "role");
    else if (sub == "exempt-channel") cmd_exempt(app, e, "channel");
    else if (sub == "exempt-list") cmd_exempt_list(app, e);
    else if (sub == "allow-domain") cmd_domain(app, e, true);
    else if (sub == "remove-domain") cmd_domain(app, e, false);
    else if (sub == "domains") cmd_domains(app, e);
    return true;
}

}  // namespace flour
