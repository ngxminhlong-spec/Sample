#include <algorithm>
#include <chrono>
#include <deque>
#include <map>
#include <mutex>

#include "app.hpp"
#include "util.hpp"

namespace flour {

namespace {

// What each kind of event adds. Join heat scales with how new the account is, because
// raids are almost always made of freshly created accounts.
constexpr double kJoinBase = 4.0;
constexpr double kJoinUnderDay = 10.0;
constexpr double kJoinUnderWeek = 6.0;
constexpr double kJoinUnderMonth = 2.0;

constexpr int64_t kQuarantineSeconds = 600;
constexpr double kYoungAccountDays = 30.0;
constexpr int64_t kRecentJoinWindow = 180;  // seconds of joins remembered for a lockdown sweep
constexpr double kHysteresis = 0.7;         // a level only drops once heat is below 70% of it

struct HeatState {
    double heat = 0;
    int level = heat_calm;
    double last_update = 0;                           // seconds, steady clock
    std::deque<std::pair<int64_t, uint64_t>> joins;   // (unix seconds, user id)
};

std::mutex g_mutex;
std::map<uint64_t, HeatState> g_heat;

double steady_seconds() {
    return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

int64_t unix_now() { return static_cast<int64_t>(time(nullptr)); }

double account_age_days(uint64_t user_id) {
    return (static_cast<double>(unix_now()) - dpp::snowflake(user_id).get_creation_time()) / 86400.0;
}

void cool_down(HeatState& st, const GuildConfig& cfg, double now) {
    if (st.last_update > 0) {
        const double dt = now - st.last_update;
        st.heat = std::max(0.0, st.heat - cfg.heat_decay / 60.0 * dt);
    }
    st.last_update = now;
}

int threshold(const GuildConfig& cfg, int level) {
    switch (level) {
        case heat_warm: return cfg.heat_warm;
        case heat_hot: return cfg.heat_hot;
        case heat_critical: return cfg.heat_critical;
        default: return 0;
    }
}

int next_level(int current, double heat, const GuildConfig& cfg) {
    int level = current;
    for (int l = heat_critical; l > level; --l) {
        if (heat >= threshold(cfg, l)) { level = l; break; }
    }
    if (level == current) {
        while (level > heat_calm && heat < threshold(cfg, level) * kHysteresis) --level;
    }
    return level;
}

std::string bar(double heat, double max_value) {
    const int width = 10;
    const int filled = static_cast<int>(std::clamp(heat / max_value, 0.0, 1.0) * width + 0.5);
    return "[" + std::string(static_cast<size_t>(filled), '#') + std::string(static_cast<size_t>(width - filled), '-') + "]";
}

std::string level_description(int level) {
    switch (level) {
        case heat_warm:
            return "Heat is rising. No restrictions yet, but keep an eye on the server.";
        case heat_hot:
            return "New accounts (under 30 days old) are quarantined with a 10 minute timeout, and invite "
                   "links are blocked.";
        case heat_critical:
            return "Lockdown: every new join is kicked, along with recent young-account joins. "
                   "Use `/heat reset` once it's over.";
        default:
            return "Things have cooled down. Restrictions are lifted.";
    }
}

uint32_t level_color(int level) {
    switch (level) {
        case heat_warm: return color::warn;
        case heat_hot: return 0xE67E22;
        case heat_critical: return color::danger;
        default: return color::ok;
    }
}

void announce(App& app, uint64_t guild_id, int from, int to, double heat, const std::string& why) {
    std::string text = std::string("Heat is now **") + std::to_string(static_cast<int>(heat + 0.5)) + "** (" +
                       heat_level_name(to) + ").\n" + level_description(to);
    if (to > from && !why.empty()) text += "\nLatest trigger: " + why;
    log_event(app, guild_id, std::string("Heat: ") + heat_level_name(from) + " to " + heat_level_name(to),
              text, level_color(to));
}

}  // namespace

const char* heat_level_name(int level) {
    switch (level) {
        case heat_warm: return "warm";
        case heat_hot: return "hot";
        case heat_critical: return "critical";
        default: return "calm";
    }
}

HeatReading heat_add(App& app, uint64_t guild_id, double points, const std::string& why,
                     uint64_t skip_user) {
    const GuildConfig cfg = app.db.get_config(guild_id);
    if (!cfg.heat_enabled) return {};

    int from = heat_calm, to = heat_calm;
    double heat = 0;
    std::vector<uint64_t> sweep;
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        HeatState& st = g_heat[guild_id];
        cool_down(st, cfg, steady_seconds());

        from = st.level;
        st.heat += points;
        st.level = to = next_level(st.level, st.heat, cfg);
        heat = st.heat;

        const int64_t now = unix_now();
        while (!st.joins.empty() && now - st.joins.front().first > kRecentJoinWindow) st.joins.pop_front();

        // Crossing into critical sweeps up the young accounts that just arrived.
        if (to == heat_critical && from < heat_critical) {
            for (const auto& j : st.joins) {
                if (j.second != skip_user && account_age_days(j.second) < kYoungAccountDays) {
                    sweep.push_back(j.second);
                }
            }
        }
    }

    if (to != from) announce(app, guild_id, from, to, heat, why);
    for (uint64_t user : sweep) {
        action_kick(app, guild_id, user, app.bot.me.id, "Heat lockdown", false);
    }
    return {heat, to};
}

HeatReading heat_peek(App& app, uint64_t guild_id) {
    const GuildConfig cfg = app.db.get_config(guild_id);
    if (!cfg.heat_enabled) return {};

    std::lock_guard<std::mutex> lock(g_mutex);
    auto it = g_heat.find(guild_id);
    if (it == g_heat.end()) return {};
    HeatState& st = it->second;
    cool_down(st, cfg, steady_seconds());
    st.level = next_level(st.level, st.heat, cfg);
    return {st.heat, st.level};
}

void heat_reset(App& app, uint64_t guild_id) {
    int from = heat_calm;
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        auto it = g_heat.find(guild_id);
        if (it == g_heat.end()) return;
        from = it->second.level;
        g_heat.erase(it);
    }
    if (from != heat_calm) announce(app, guild_id, from, heat_calm, 0, "");
}

void heat_on_member_join(App& app, const dpp::guild_member_add_t& event) {
    const uint64_t guild_id = event.added.guild_id;
    const uint64_t user_id = event.added.user_id;
    const GuildConfig cfg = app.db.get_config(guild_id);
    if (!cfg.heat_enabled) return;

    const double age = account_age_days(user_id);
    double points = kJoinBase;
    if (age < 1.0) points += kJoinUnderDay;
    else if (age < 7.0) points += kJoinUnderWeek;
    else if (age < kYoungAccountDays) points += kJoinUnderMonth;

    {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_heat[guild_id].joins.push_back({unix_now(), user_id});
    }

    const HeatReading r = heat_add(app, guild_id, points,
                                   "join from an account " + std::to_string(static_cast<int>(age)) + " day(s) old",
                                   user_id);

    // The newcomer gets whatever the current level calls for.
    if (r.level >= heat_critical) {
        action_kick(app, guild_id, user_id, app.bot.me.id, "Heat lockdown", false);
    } else if (r.level == heat_hot && age < kYoungAccountDays) {
        action_timeout(app, guild_id, user_id, app.bot.me.id, kQuarantineSeconds,
                       "Heat quarantine: new account joined while the server was hot");
    }
}

void heat_sweep() {
    std::lock_guard<std::mutex> lock(g_mutex);
    const int64_t now = unix_now();
    for (auto it = g_heat.begin(); it != g_heat.end();) {
        HeatState& st = it->second;
        while (!st.joins.empty() && now - st.joins.front().first > kRecentJoinWindow) st.joins.pop_front();
        // Idle for a while with nothing recorded: forget it. Heat restarts from zero next time.
        const bool idle = steady_seconds() - st.last_update > 1800;
        it = (st.joins.empty() && idle) ? g_heat.erase(it) : std::next(it);
    }
}

std::string heat_bar(double heat, double max_value) { return bar(heat, max_value); }

}  // namespace flour
