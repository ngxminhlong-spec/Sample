#include <algorithm>
#include <deque>
#include <memory>
#include <functional>
#include <map>
#include <mutex>
#include <set>
#include <tuple>
#include <unordered_set>

#include "app.hpp"
#include "ratewindow.hpp"
#include "util.hpp"

namespace flour {

namespace {

constexpr int64_t kEntryMaxAge = 30;    // audit entries older than this belong to an earlier action
constexpr int64_t kScanDelay = 3;       // events in this many seconds share one audit log request
constexpr int64_t kPunishMemory = 120;  // after a punishment, further actions by that user are undone
constexpr int64_t kDeletedKeep = 600;   // deleted channels and roles are kept this long for undo
constexpr size_t kMaxSeen = 10000;
constexpr size_t kMaxDeleted = 500;
constexpr int kScanEntries = 25;

enum Kind { kind_bans = 0, kind_kicks, kind_channels, kind_roles, kind_admin_grants, kind_webhooks, kind_count };

const char* kNoun[kind_count] = {"banned members", "kicked members", "deleted channels", "deleted roles",
                                 "granted Administrator", "created or deleted webhooks"};
const char* kKey[kind_count] = {"bans", "kicks", "channels", "roles", "admin_roles", "webhooks"};
const char* kColumn[kind_count] = {"bans_limit", "kicks_limit", "channels_limit", "roles_limit",
                                   "admin_roles_limit", "webhooks_limit"};

// Which kind of damage an audit log entry type counts toward. -1 for types we don't watch.
int kind_for_audit(uint32_t type) {
    switch (type) {
        case dpp::aut_member_ban_add: return kind_bans;
        case dpp::aut_member_kick: return kind_kicks;
        case dpp::aut_channel_delete: return kind_channels;
        case dpp::aut_role_delete: return kind_roles;
        case dpp::aut_role_create:
        case dpp::aut_role_update:
        case dpp::aut_member_role_update: return kind_admin_grants;
        case dpp::aut_webhook_create:
        case dpp::aut_webhook_delete: return kind_webhooks;
    }
    return -1;
}

int limit_for(const NukeConfig& c, int kind) {
    switch (kind) {
        case kind_bans: return c.bans_limit;
        case kind_kicks: return c.kicks_limit;
        case kind_channels: return c.channels_limit;
        case kind_roles: return c.roles_limit;
        case kind_admin_grants: return c.admin_roles_limit;
        case kind_webhooks: return c.webhooks_limit;
    }
    return 1;
}

int64_t now_s() { return static_cast<int64_t>(time(nullptr)); }

std::string api_error(const dpp::confirmation_callback_t& cb) {
    const std::string m = cb.get_error().message;
    return m.empty() ? "Discord rejected the request." : m;
}

std::mutex g_mutex;
std::set<std::pair<uint64_t, uint32_t>> g_scheduled;      // (guild, audit type) waiting for a scan
std::unordered_set<uint64_t> g_seen;                      // audit entries already judged
std::deque<uint64_t> g_seen_order;
std::map<std::tuple<uint64_t, uint64_t, int>, RateWindow> g_windows;  // (guild, executor, kind)
std::map<std::pair<uint64_t, uint64_t>, int64_t> g_punished;          // (guild, executor) -> when

// Returns true if this audit entry hasn't been judged yet.
bool mark_seen(uint64_t id) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_seen.insert(id).second) return false;
    g_seen_order.push_back(id);
    while (g_seen_order.size() > kMaxSeen) {
        g_seen.erase(g_seen_order.front());
        g_seen_order.pop_front();
    }
    return true;
}

// Records one action by `executor`. True when they've reached the limit for this kind.
bool count_action(uint64_t guild, uint64_t executor, int kind, const NukeConfig& cfg, int& count_out) {
    std::lock_guard<std::mutex> lock(g_mutex);
    RateWindow& w = g_windows[{guild, executor, kind}];
    count_out = static_cast<int>(w.record(now_s(), cfg.window_secs));
    return count_out >= limit_for(cfg, kind);
}

void forget_executor(uint64_t guild, uint64_t executor) {
    std::lock_guard<std::mutex> lock(g_mutex);
    for (auto it = g_windows.begin(); it != g_windows.end();) {
        it = (std::get<0>(it->first) == guild && std::get<1>(it->first) == executor) ? g_windows.erase(it)
                                                                                    : std::next(it);
    }
}

bool recently_punished(uint64_t guild, uint64_t executor) {
    std::lock_guard<std::mutex> lock(g_mutex);
    auto it = g_punished.find({guild, executor});
    return it != g_punished.end() && now_s() - it->second < kPunishMemory;
}

// Discord sends permission bitmasks as strings in audit log changes.
uint64_t parse_bits(const std::string& json_text) {
    if (json_text.empty()) return 0;
    try {
        const dpp::json j = dpp::json::parse(json_text);
        if (j.is_string()) return std::stoull(j.get<std::string>());
        if (j.is_number_unsigned()) return j.get<uint64_t>();
    } catch (...) {
    }
    return 0;
}

bool role_is_admin(const dpp::snowflake& role_id) {
    const dpp::role* r = dpp::find_role(role_id);
    return r && r->permissions.can(dpp::p_administrator);
}

// Does this audit entry actually hand out Administrator, rather than just editing a role?
bool grants_admin(const dpp::audit_entry& entry, uint32_t type) {
    if (type == dpp::aut_role_create) return role_is_admin(entry.target_id);

    if (type == dpp::aut_role_update) {
        for (const dpp::audit_change& ch : entry.changes) {
            if (ch.key != "permissions") continue;
            const uint64_t before = parse_bits(ch.old_value);
            const uint64_t after = parse_bits(ch.new_value);
            return (after & dpp::p_administrator) != 0 && (before & dpp::p_administrator) == 0;
        }
        return false;
    }

    if (type == dpp::aut_member_role_update) {
        for (const dpp::audit_change& ch : entry.changes) {
            if (ch.key != "$add") continue;
            try {
                const dpp::json added = dpp::json::parse(ch.new_value);
                if (!added.is_array()) continue;
                for (const auto& item : added) {
                    const std::string id = item.value("id", std::string());
                    if (!id.empty() && role_is_admin(dpp::snowflake(std::stoull(id)))) return true;
                }
            } catch (...) {
            }
        }
    }
    return false;
}

// ============================================================ undo (SQLite-backed)

using Step = std::function<void(std::function<void()>)>;

// Runs steps one after another. Each step calls its `next` argument when it has finished.
void run_chain(std::shared_ptr<std::deque<Step>> q, std::function<void()> done) {
    if (q->empty()) {
        if (done) done();
        return;
    }
    Step step = q->front();
    q->pop_front();
    step([q, done]() { run_chain(q, done); });
}

struct Restore {
    std::map<uint64_t, uint64_t> roles;     // old role id -> new role id
    std::map<uint64_t, uint64_t> channels;  // old channel id -> new channel id
    int role_count = 0;
    int channel_count = 0;
    int member_count = 0;
};

int64_t json_int(const dpp::json& j, const char* key, int64_t def = 0) {
    auto it = j.find(key);
    if (it == j.end() || !it->is_number()) return def;
    return it->get<int64_t>();
}

void restore_role(App& app, uint64_t guild, const Tombstone& row, std::shared_ptr<Restore> st, std::function<void()> next) {
    dpp::role r;
    try {
        dpp::json j = dpp::json::parse(row.data);
        r.fill_from_json(dpp::snowflake(guild), &j);
    } catch (...) {
        app.db.tombstone_delete(row.id);
        next();
        return;
    }
    const uint64_t old_id = row.obj_id;
    const std::string name = r.name;
    r.id = 0;
    app.bot.role_create(r, [&app, guild, row, st, old_id, name, next](const dpp::confirmation_callback_t& cb) {
        app.db.tombstone_delete(row.id);
        if (!cb.is_error() && std::holds_alternative<dpp::role>(cb.value)) {
            const uint64_t new_id = static_cast<uint64_t>(std::get<dpp::role>(cb.value).id);
            st->roles[old_id] = new_id;
            st->role_count++;
            app.db.role_remap(guild, old_id, new_id);
            log_event(app, guild, "Role ID changed",
                      "**" + name + "**: `" + std::to_string(old_id) + "` is now `" + std::to_string(new_id) +
                          "`. Flour's staff role and auto-mod exemptions were updated. Anything outside Flour "
                          "that uses the old ID (other bots, role menus, pings in saved messages) needs changing by hand.",
                      color::warn);
        } else {
            log_event(app, guild, "Anti-nuke could not restore a role", "Role **" + name + "**: " + api_error(cb), color::danger);
        }
        next();
    });
}

void restore_channel(App& app, uint64_t guild, const Tombstone& row, std::shared_ptr<Restore> st, std::function<void()> next) {
    dpp::channel c;
    try {
        dpp::json j = dpp::json::parse(row.data);
        c.fill_from_json(&j);
    } catch (...) {
        app.db.tombstone_delete(row.id);
        next();
        return;
    }
    const uint64_t old_id = row.obj_id;
    const std::string name = c.name;
    c.id = 0;

    // Point the channel at its restored category, and keep only overwrites that still make sense.
    const uint64_t parent = static_cast<uint64_t>(c.parent_id);
    if (parent != 0) {
        auto it = st->channels.find(parent);
        if (it != st->channels.end()) c.parent_id = dpp::snowflake(it->second);
        else if (!dpp::find_channel(dpp::snowflake(parent))) c.parent_id = dpp::snowflake(0);
    }
    std::vector<dpp::permission_overwrite> kept;
    for (dpp::permission_overwrite ov : c.permission_overwrites) {
        if (ov.type == dpp::ot_role) {
            const uint64_t role_id = static_cast<uint64_t>(ov.id);
            auto it = st->roles.find(role_id);
            if (it != st->roles.end()) ov.id = dpp::snowflake(it->second);
            else if (!dpp::find_role(dpp::snowflake(role_id))) continue;  // role no longer exists
        }
        kept.push_back(ov);
    }
    c.permission_overwrites = kept;

    app.bot.channel_create(c, [&app, guild, row, st, old_id, name, next](const dpp::confirmation_callback_t& cb) {
        app.db.tombstone_delete(row.id);
        if (cb.is_error() || !std::holds_alternative<dpp::channel>(cb.value)) {
            log_event(app, guild, "Anti-nuke could not restore a channel", "Channel **#" + name + "**: " + api_error(cb), color::danger);
            next();
            return;
        }
        st->channels[old_id] = static_cast<uint64_t>(std::get<dpp::channel>(cb.value).id);
        st->channel_count++;
        next();
    });
}

// Puts a deleted role's overwrite back on a channel that still exists. Channels that were
// themselves restored already have it, so they're skipped.
void restore_overwrite(App& app, uint64_t guild, const Tombstone& row, std::shared_ptr<Restore> st, std::function<void()> next) {
    uint64_t channel = 0, allow = 0, deny = 0;
    try {
        const dpp::json j = dpp::json::parse(row.data);
        channel = std::stoull(j.value("c", std::string("0")));
        allow = std::stoull(j.value("a", std::string("0")));
        deny = std::stoull(j.value("d", std::string("0")));
    } catch (...) {
    }
    app.db.tombstone_delete(row.id);

    auto role_it = st->roles.find(row.obj_id);
    if (channel == 0 || role_it == st->roles.end() || st->channels.count(channel) ||
        !dpp::find_channel(dpp::snowflake(channel))) {
        next();
        return;
    }
    app.bot.channel_edit_permissions(dpp::snowflake(channel), dpp::snowflake(role_it->second), allow, deny, false,
        [&app, guild, channel, next](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) {
                log_event(app, guild, "Anti-nuke could not restore an overwrite",
                          "<#" + std::to_string(channel) + ">: " + api_error(cb), color::danger);
            } else {
                log_event(app, guild, "Anti-nuke restored a permission overwrite",
                          "Put a restored role's permissions back on <#" + std::to_string(channel) + ">.", color::ok);
            }
            next();
        });
}

void restore_member(App& app, uint64_t guild, const ArchiveRow& row, std::shared_ptr<Restore> st, std::function<void()> next) {
    std::vector<uint64_t> mapped;
    try {
        const dpp::json arr = dpp::json::parse(row.data);
        for (const auto& item : arr) {
            auto it = st->roles.find(std::stoull(item.get<std::string>()));
            if (it != st->roles.end()) mapped.push_back(it->second);
        }
    } catch (...) {
    }
    if (mapped.empty()) {
        next();
        return;
    }

    const uint64_t user = row.id;
    app.bot.guild_get_member(guild, user, [&app, guild, user, mapped, st, next](const dpp::confirmation_callback_t& cb) {
        if (cb.is_error() || !std::holds_alternative<dpp::guild_member>(cb.value)) {
            next();  // they've left the server
            return;
        }
        dpp::guild_member member = std::get<dpp::guild_member>(cb.value);
        std::vector<dpp::snowflake> roles = member.get_roles();
        bool changed = false;
        for (uint64_t id : mapped) {
            const dpp::snowflake sid(id);
            if (std::find(roles.begin(), roles.end(), sid) == roles.end()) {
                roles.push_back(sid);
                changed = true;
            }
        }
        if (!changed) {
            next();
            return;
        }
        member.set_roles(roles);
        app.bot.guild_edit_member(member, [st, next](const dpp::confirmation_callback_t& ecb) {
            if (!ecb.is_error()) st->member_count++;
            next();
        });
    });
}

// Restores what `executor` deleted. Roles first, then channels (categories first), then the member
// roles that point at the new role IDs. Everything comes from SQLite, so it works after a restart.
void restore_for(App& app, uint64_t guild, uint64_t executor) {
    std::vector<Tombstone> rows = app.db.tombstones_claim(guild, executor);
    if (rows.empty()) return;

    std::vector<Tombstone> roles, channels, overwrites;
    std::set<uint64_t> deleted_roles;
    for (const Tombstone& t : rows) {
        if (t.kind == "role") {
            roles.push_back(t);
            deleted_roles.insert(t.obj_id);
        } else if (t.kind == "overwrite") {
            overwrites.push_back(t);
        } else {
            channels.push_back(t);
        }
    }
    auto role_pos = [](const Tombstone& t) {
        try { return json_int(dpp::json::parse(t.data), "position"); } catch (...) { return int64_t(0); }
    };
    auto channel_order = [](const Tombstone& t) {
        try {
            const dpp::json j = dpp::json::parse(t.data);
            return std::make_pair(json_int(j, "type") == 4 ? 0 : 1, json_int(j, "position"));
        } catch (...) {
            return std::make_pair(1, int64_t(0));
        }
    };
    std::stable_sort(roles.begin(), roles.end(), [&](const Tombstone& a, const Tombstone& b) { return role_pos(a) < role_pos(b); });
    std::stable_sort(channels.begin(), channels.end(), [&](const Tombstone& a, const Tombstone& b) { return channel_order(a) < channel_order(b); });

    auto st = std::make_shared<Restore>();
    auto q = std::make_shared<std::deque<Step>>();
    for (const Tombstone& t : roles) {
        q->push_back([&app, guild, t, st](std::function<void()> next) { restore_role(app, guild, t, st, next); });
    }
    for (const Tombstone& t : channels) {
        q->push_back([&app, guild, t, st](std::function<void()> next) { restore_channel(app, guild, t, st, next); });
    }
    // After channels, so a channel that was recreated isn't handled twice.
    for (const Tombstone& t : overwrites) {
        q->push_back([&app, guild, t, st](std::function<void()> next) { restore_overwrite(app, guild, t, st, next); });
    }

    // Only members who had one of the deleted roles need touching.
    for (const ArchiveRow& row : app.db.archive_members(guild)) {
        bool had = false;
        try {
            for (const auto& item : dpp::json::parse(row.data)) {
                if (deleted_roles.count(std::stoull(item.get<std::string>()))) had = true;
            }
        } catch (...) {
        }
        if (had) q->push_back([&app, guild, row, st](std::function<void()> next) { restore_member(app, guild, row, st, next); });
    }

    q->push_back([&app, guild, executor, st](std::function<void()> next) {
        log_event(app, guild, "Anti-nuke restore finished",
                  "Restored " + std::to_string(st->role_count) + " role(s), " + std::to_string(st->channel_count) +
                      " channel(s) and " +
                      std::to_string(st->member_count) + " member role assignment(s) that <@" +
                      std::to_string(executor) + "> removed.",
                  color::ok);
        next();
    });
    run_chain(q, nullptr);
}

// ============================================================ punishment

void strip_roles(App& app, uint64_t guild, uint64_t executor, const std::string& why) {
    app.bot.guild_get_member(guild, app.bot.me.id,
        [&app, guild, executor, why](const dpp::confirmation_callback_t& bot_cb) {
            if (bot_cb.is_error()) {
                log_event(app, guild, "Anti-nuke could not strip roles", api_error(bot_cb), color::danger);
                return;
            }
            // Flour can only remove roles below its own highest role.
            int bot_top = 0;
            for (const dpp::snowflake& r : std::get<dpp::guild_member>(bot_cb.value).get_roles()) {
                if (const dpp::role* role = dpp::find_role(r)) bot_top = std::max<int>(bot_top, role->position);
            }

            app.bot.guild_get_member(guild, executor,
                [&app, guild, executor, why, bot_top](const dpp::confirmation_callback_t& cb) {
                    if (cb.is_error()) {
                        log_event(app, guild, "Anti-nuke could not strip roles",
                                  "<@" + std::to_string(executor) + "> is no longer in the server.", color::danger);
                        return;
                    }
                    dpp::guild_member member = std::get<dpp::guild_member>(cb.value);
                    std::vector<dpp::snowflake> keep;
                    for (const dpp::snowflake& r : member.get_roles()) {
                        const dpp::role* role = dpp::find_role(r);
                        if (!role || role->position >= bot_top) keep.push_back(r);  // Flour can't remove these
                    }
                    member.set_roles(keep);
                    app.bot.guild_edit_member(member,
                        [&app, guild, executor, why](const dpp::confirmation_callback_t& ecb) {
                            if (ecb.is_error()) {
                                log_event(app, guild, "Anti-nuke could not strip roles",
                                          "Removing roles from <@" + std::to_string(executor) + "> failed: " +
                                              api_error(ecb) + "\nCheck that Flour's role is above theirs.",
                                          color::danger);
                                return;
                            }
                            record_case(app, guild, executor, app.bot.me.id, "strip", "Anti-nuke: " + why);
                        });
                });
        });
}

void punish(App& app, uint64_t guild, uint64_t executor, const std::string& why) {
    forget_executor(guild, executor);
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_punished[{guild, executor}] = now_s();
    }

    const NukeConfig cfg = app.db.get_nuke_config(guild);
    const uint64_t bot = app.bot.me.id;
    dpp::guild* g = dpp::find_guild(guild);
    const uint64_t owner = g ? static_cast<uint64_t>(g->owner_id) : 0;
    const std::string who = "<@" + std::to_string(executor) + ">";

    std::string outcome;
    if (cfg.action == 2) {
        outcome = "banned";
        app.bot.guild_ban_add(guild, executor, 0,
            [&app, guild, executor, why, bot](const dpp::confirmation_callback_t& cb) {
                if (cb.is_error()) {
                    log_event(app, guild, "Anti-nuke could not ban",
                              "Flour could not ban <@" + std::to_string(executor) + ">: " + api_error(cb) +
                                  "\nRemove their access manually.",
                              color::danger);
                    return;
                }
                record_case(app, guild, executor, bot, "ban", "Anti-nuke: " + why);
            });
    } else {
        outcome = "stripped of every role Flour can remove";
        strip_roles(app, guild, executor, why);
    }

    restore_for(app, guild, executor);

    const std::string text = "Anti-nuke stopped " + who + " after " + why + ".\nAction: " + outcome +
                             ". Deleted channels and roles from this window are being restored.\n"
                             "If this was legitimate, trust them with `/antinuke trust`.";
    log_event(app, guild, "Anti-nuke triggered", text, color::danger);

    if (owner != 0) {
        app.bot.direct_message_create(owner,
            dpp::message("**" + (g ? g->name : std::string("Your server")) + "**: " + text),
            [](const dpp::confirmation_callback_t&) {});
    }
}

// ============================================================ judging audit entries

void handle_entry(App& app, uint64_t guild, uint32_t audit_type, const dpp::audit_entry& entry) {
    const double age = static_cast<double>(now_s()) - entry.id.get_creation_time();
    if (age > kEntryMaxAge || age < -5) return;
    if (!mark_seen(static_cast<uint64_t>(entry.id))) return;

    const int kind = kind_for_audit(audit_type);
    if (kind < 0) return;
    if (kind == kind_admin_grants && !grants_admin(entry, audit_type)) return;

    const uint64_t executor = static_cast<uint64_t>(entry.user_id);
    const uint64_t target = static_cast<uint64_t>(entry.target_id);
    dpp::guild* g = dpp::find_guild(guild);
    if (!g || executor == 0) return;
    if (executor == app.bot.me.id || executor == static_cast<uint64_t>(g->owner_id)) return;
    for (uint64_t trusted : app.db.nuke_trusted(guild)) {
        if (trusted == executor) return;
    }

    const NukeConfig cfg = app.db.get_nuke_config(guild);
    if (!cfg.enabled) return;

    if (kind == kind_channels || kind == kind_roles) app.db.tombstone_set_executor(guild, target, executor);

    // Someone already punished is undone straight away, without counting toward another punishment.
    if (recently_punished(guild, executor)) {
        restore_for(app, guild, executor);
        return;
    }

    int count = 0;
    if (!count_action(guild, executor, kind, cfg, count)) return;
    punish(app, guild, executor,
           std::to_string(count) + " " + kNoun[kind] + " in " + std::to_string(cfg.window_secs) + "s");
}

// Reads the audit log for one type, judging anything new from the last half minute.
void scan(App& app, uint64_t guild, uint32_t audit_type) {
    if (!app.db.get_nuke_config(guild).enabled) return;
    app.bot.guild_auditlog_get(guild, 0, audit_type, 0, 0, kScanEntries,
        [&app, guild, audit_type](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) {
                app.bot.log(dpp::ll_warning, "anti-nuke audit log read failed: " + api_error(cb));
                return;
            }
            const dpp::auditlog log = std::get<dpp::auditlog>(cb.value);
            // Oldest first, so the count follows the order things happened in.
            std::vector<dpp::audit_entry> entries(log.entries.begin(), log.entries.end());
            std::reverse(entries.begin(), entries.end());
            for (const dpp::audit_entry& entry : entries) handle_entry(app, guild, audit_type, entry);
        });
}

// Several events close together share one audit log request.
void schedule_scan(App& app, uint64_t guild, uint32_t audit_type) {
    if (guild == 0 || !app.db.get_nuke_config(guild).enabled) return;
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        if (!g_scheduled.insert({guild, audit_type}).second) return;
    }
    app.bot.start_timer([&app, guild, audit_type](dpp::timer h) {
        app.bot.stop_timer(h);
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            g_scheduled.erase({guild, audit_type});
        }
        scan(app, guild, audit_type);
    }, kScanDelay);
}

}  // namespace

// ============================================================ event entry points

void antinuke_on_ban(App& app, const dpp::guild_ban_add_t& event) {
    schedule_scan(app, static_cast<uint64_t>(event.banning_guild.id), dpp::aut_member_ban_add);
}

void antinuke_on_kick(App& app, const dpp::guild_member_remove_t& event) {
    // Most leaves aren't kicks. The debounce means a burst of leaves makes one audit request.
    schedule_scan(app, static_cast<uint64_t>(event.guild_id), dpp::aut_member_kick);
}

void antinuke_on_channel_delete(App& app, const dpp::channel_delete_t& event) {
    const uint64_t guild = static_cast<uint64_t>(event.deleting_guild.id);
    if (guild == 0) return;
    // The tombstone is kept even when anti-nuke is off, so a later enable can still undo this.
    app.db.tombstone_add(guild, "channel", static_cast<uint64_t>(event.deleted.id), event.deleted.build_json(true));
    schedule_scan(app, guild, dpp::aut_channel_delete);
}

void antinuke_on_role_delete(App& app, const dpp::guild_role_delete_t& event) {
    const uint64_t guild = static_cast<uint64_t>(event.deleting_guild.id);
    if (guild == 0) return;
    const uint64_t role_id = static_cast<uint64_t>(event.deleted.id);
    archive_capture_role_overwrites(app, guild, role_id);
    app.db.tombstone_add(guild, "role", role_id, event.deleted.build_json(true));
    schedule_scan(app, guild, dpp::aut_role_delete);
}

void antinuke_on_role_create(App& app, const dpp::guild_role_create_t& event) {
    if (!event.created.permissions.can(dpp::p_administrator)) return;
    schedule_scan(app, static_cast<uint64_t>(event.creating_guild.id), dpp::aut_role_create);
}

void antinuke_on_role_update(App& app, const dpp::guild_role_update_t& event) {
    if (!event.updated.permissions.can(dpp::p_administrator)) return;
    schedule_scan(app, static_cast<uint64_t>(event.updating_guild.id), dpp::aut_role_update);
}

void antinuke_on_member_update(App& app, const dpp::guild_member_update_t& event) {
    // Only members who already hold Administrator can matter here, so most member updates cost nothing.
    for (const dpp::snowflake& r : event.updated.get_roles()) {
        if (role_is_admin(r)) {
            schedule_scan(app, static_cast<uint64_t>(event.updating_guild.id), dpp::aut_member_role_update);
            return;
        }
    }
}

void antinuke_on_webhooks(App& app, const dpp::webhooks_update_t& event) {
    const uint64_t guild = static_cast<uint64_t>(event.webhook_guild.id);
    schedule_scan(app, guild, dpp::aut_webhook_create);
    schedule_scan(app, guild, dpp::aut_webhook_delete);
}

// ============================================================ /antinuke

namespace {

dpp::message ephemeral(const std::string& text) { return dpp::message(text).set_flags(dpp::m_ephemeral); }

void cmd_show(App& app, const dpp::slashcommand_t& e) {
    const NukeConfig c = app.db.get_nuke_config(e.command.guild_id);
    const size_t trusted = app.db.nuke_trusted(e.command.guild_id).size();

    dpp::embed emb;
    emb.set_color(c.enabled ? color::info : color::neutral);
    emb.set_title("Anti-nuke");
    emb.set_description(c.enabled ? "**On.** Watching bans, kicks, deletions, webhooks and Administrator grants."
                                  : "**Off.** Turn it on with `/antinuke enable`.");
    emb.add_field("Response", c.action == 2 ? "Ban the executor" : "Strip removable roles", true);
    emb.add_field("Window", std::to_string(c.window_secs) + " seconds", true);
    emb.add_field("Trusted users", std::to_string(trusted), true);
    emb.add_field("Bans", "at " + std::to_string(c.bans_limit), true);
    emb.add_field("Kicks", "at " + std::to_string(c.kicks_limit), true);
    emb.add_field("Channel deletes", "at " + std::to_string(c.channels_limit), true);
    emb.add_field("Role deletes", "at " + std::to_string(c.roles_limit), true);
    emb.add_field("Administrator grants", "at " + std::to_string(c.admin_roles_limit), true);
    emb.add_field("Webhook changes", "at " + std::to_string(c.webhooks_limit), true);
    emb.set_footer(dpp::embed_footer().set_text("The server owner is never punished. Only the owner and Administrators can change anti-nuke."));

    dpp::message m;
    m.add_embed(emb);
    m.set_flags(dpp::m_ephemeral);
    e.reply(m);
}

void set_and_log(App& app, const dpp::slashcommand_t& e, const std::string& column, int64_t value,
                 const std::string& shown) {
    if (!app.db.set_nuke_value(e.command.guild_id, column, value)) return reply_error(e, "Couldn't save that.");
    log_event(app, e.command.guild_id, "Anti-nuke changed",
              "<@" + std::to_string(static_cast<uint64_t>(e.command.usr.id)) + "> " + shown, color::info);
    e.reply(ephemeral("Done: " + shown + "."));
}

void cmd_enable(App& app, const dpp::slashcommand_t& e) {
    const bool on = opt_bool(e, "on", true);
    set_and_log(app, e, "enabled", on ? 1 : 0, on ? "turned anti-nuke **on**" : "turned anti-nuke **off**");
}

void cmd_action(App& app, const dpp::slashcommand_t& e) {
    const bool ban = opt_str(e, "mode", "ban") == "ban";
    set_and_log(app, e, "action", ban ? 2 : 1, ban ? "the response is now **ban**" : "the response is now **strip roles**");
}

void cmd_limit(App& app, const dpp::slashcommand_t& e) {
    const std::string kind = opt_str(e, "kind");
    const int64_t count = opt_int(e, "count", 0);
    for (int i = 0; i < kind_count; ++i) {
        if (kind == kKey[i]) {
            if (count < 1 || count > 100) return reply_error(e, "The limit must be between 1 and 100.");
            return set_and_log(app, e, kColumn[i], count,
                               std::string("limit for ") + kKey[i] + " is now **" + std::to_string(count) + "**");
        }
    }
    reply_error(e, "Unknown kind.");
}

void cmd_remaps(App& app, const dpp::slashcommand_t& e) {
    std::string body;
    for (const auto& [old_id, new_id] : app.db.role_remaps(e.command.guild_id, 20)) {
        body += "`" + std::to_string(old_id) + "` to `" + std::to_string(new_id) + "`\n";
    }
    dpp::embed emb;
    emb.set_color(color::info);
    emb.set_title("Restored role IDs");
    emb.set_description(body.empty() ? "No roles have been restored yet." : body);
    emb.set_footer(dpp::embed_footer().set_text("Update anything outside Flour that uses the old IDs."));
    dpp::message m;
    m.add_embed(emb);
    m.set_flags(dpp::m_ephemeral);
    e.reply(m);
}

void cmd_window(App& app, const dpp::slashcommand_t& e) {
    const int64_t secs = opt_int(e, "seconds", 0);
    if (secs < 5 || secs > 300) return reply_error(e, "The window must be between 5 and 300 seconds.");
    set_and_log(app, e, "window_secs", secs, "window is now **" + std::to_string(secs) + " seconds**");
}

void cmd_trust(App& app, const dpp::slashcommand_t& e) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t user = opt_id(e, "user");
    if (opt_bool(e, "remove", false)) {
        if (!app.db.remove_nuke_trusted(gid, user)) return reply_error(e, "That user wasn't trusted.");
        log_event(app, gid, "Anti-nuke trust removed", "<@" + std::to_string(user) + "> is no longer trusted.", color::warn);
        e.reply(ephemeral("<@" + std::to_string(user) + "> is no longer exempt from anti-nuke."));
    } else {
        if (!app.db.add_nuke_trusted(gid, user)) return reply_error(e, "That user is already trusted.");
        log_event(app, gid, "Anti-nuke trust granted",
                  "<@" + std::to_string(static_cast<uint64_t>(e.command.usr.id)) + "> trusted <@" +
                      std::to_string(user) + ">. Anti-nuke won't act on their actions.",
                  color::warn);
        e.reply(ephemeral("<@" + std::to_string(user) + "> is trusted. Anti-nuke won't act on their actions."));
    }
}

void cmd_trusted(App& app, const dpp::slashcommand_t& e) {
    std::string body;
    for (uint64_t id : app.db.nuke_trusted(e.command.guild_id)) body += "<@" + std::to_string(id) + "> ";
    dpp::embed emb;
    emb.set_color(color::info);
    emb.set_title("Anti-nuke trusted users");
    emb.set_description(body.empty() ? "Nobody is trusted yet. The server owner is always trusted." : body);
    dpp::message m;
    m.add_embed(emb);
    m.set_flags(dpp::m_ephemeral);
    e.reply(m);
}

}  // namespace

std::vector<dpp::slashcommand> build_antinuke_commands(dpp::snowflake bot_id) {
    dpp::command_option kind(dpp::co_string, "kind", "Which action to limit", true);
    kind.add_choice(dpp::command_option_choice("Bans", std::string("bans")));
    kind.add_choice(dpp::command_option_choice("Kicks", std::string("kicks")));
    kind.add_choice(dpp::command_option_choice("Channel deletes", std::string("channels")));
    kind.add_choice(dpp::command_option_choice("Role deletes", std::string("roles")));
    kind.add_choice(dpp::command_option_choice("Administrator grants", std::string("admin_roles")));
    kind.add_choice(dpp::command_option_choice("Webhook creates and deletes", std::string("webhooks")));

    dpp::command_option mode(dpp::co_string, "mode", "What to do to the executor", true);
    mode.add_choice(dpp::command_option_choice("Ban them", std::string("ban")));
    mode.add_choice(dpp::command_option_choice("Strip their removable roles", std::string("strip")));

    std::vector<dpp::slashcommand> cmds;
    cmds.push_back(make_command("antinuke", "Protect the server from a rogue or compromised admin", bot_id, dpp::p_administrator)
        .add_option(dpp::command_option(dpp::co_sub_command, "show", "Show the current settings"))
        .add_option(dpp::command_option(dpp::co_sub_command, "enable", "Turn anti-nuke on or off")
            .add_option(dpp::command_option(dpp::co_boolean, "on", "On or off", true)))
        .add_option(dpp::command_option(dpp::co_sub_command, "action", "Choose the response")
            .add_option(mode))
        .add_option(dpp::command_option(dpp::co_sub_command, "limit", "How many of one action trigger a response")
            .add_option(kind)
            .add_option(dpp::command_option(dpp::co_integer, "count", "Limit (1-100)", true).set_min_value(1).set_max_value(100)))
        .add_option(dpp::command_option(dpp::co_sub_command, "window", "How many seconds the limits are counted over")
            .add_option(dpp::command_option(dpp::co_integer, "seconds", "5-300", true).set_min_value(5).set_max_value(300)))
        .add_option(dpp::command_option(dpp::co_sub_command, "trust", "Let a user act without triggering anti-nuke")
            .add_option(dpp::command_option(dpp::co_user, "user", "The user to trust", true))
            .add_option(dpp::command_option(dpp::co_boolean, "remove", "Take the trust away instead", false)))
        .add_option(dpp::command_option(dpp::co_sub_command, "trusted", "List trusted users"))
        .add_option(dpp::command_option(dpp::co_sub_command, "remaps", "Show old and new IDs for restored roles")));
    return cmds;
}

bool handle_antinuke_command(App& app, const dpp::slashcommand_t& e) {
    if (e.command.get_command_name() != "antinuke") return false;

    const std::string sub = subcommand_name(e);
    if (sub == "show") cmd_show(app, e);
    else if (sub == "enable") cmd_enable(app, e);
    else if (sub == "action") cmd_action(app, e);
    else if (sub == "limit") cmd_limit(app, e);
    else if (sub == "window") cmd_window(app, e);
    else if (sub == "remaps") cmd_remaps(app, e);
    else if (sub == "trust") cmd_trust(app, e);
    else if (sub == "trusted") cmd_trusted(app, e);
    return true;
}

}  // namespace flour
