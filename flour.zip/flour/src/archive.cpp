#include "app.hpp"
#include "util.hpp"

namespace flour {

namespace {


std::string roles_blob(const dpp::guild_member& m) {
    dpp::json arr = dpp::json::array();
    for (const dpp::snowflake& r : m.get_roles()) arr.push_back(std::to_string(static_cast<uint64_t>(r)));
    return arr.dump(-1, ' ', false, dpp::json::error_handler_t::replace);
}

}  // namespace

void archive_on_member(App& app, uint64_t guild_id, const dpp::guild_member& member) {
    if (guild_id == 0 || member.user_id == 0) return;
    app.db.archive_put(guild_id, "member", static_cast<uint64_t>(member.user_id), 0, roles_blob(member));
}

// Channel permission overwrites, kept so a restored role can be put back on channels that survived.
// Stored as minified JSON: [{"i":id,"t":type,"a":allow,"d":deny}, ...], one row per channel.
void archive_on_channel(App& app, uint64_t guild_id, const dpp::channel& c) {
    if (guild_id == 0 || c.id == 0) return;
    const uint64_t channel = static_cast<uint64_t>(c.id);
    if (c.permission_overwrites.empty()) {
        app.db.archive_delete(guild_id, "overwrites", channel);
        return;
    }
    dpp::json arr = dpp::json::array();
    for (const dpp::permission_overwrite& ov : c.permission_overwrites) {
        dpp::json o = dpp::json::object();
        o["i"] = std::to_string(static_cast<uint64_t>(ov.id));
        o["t"] = static_cast<int>(ov.type);
        o["a"] = std::to_string(ov.allow);
        o["d"] = std::to_string(ov.deny);
        arr.push_back(o);
    }
    app.db.archive_put(guild_id, "overwrites", channel, 0, arr.dump(-1, ' ', false, dpp::json::error_handler_t::replace));
}

void archive_on_channel_delete(App& app, uint64_t guild_id, uint64_t channel_id) {
    if (guild_id == 0) return;
    app.db.archive_delete(guild_id, "overwrites", channel_id);
}

// Called as a role is deleted, before Discord strips it from every channel. Saves the overwrites that
// used it as a tombstone keyed by the role, so the executor from the audit log attaches automatically.
void archive_capture_role_overwrites(App& app, uint64_t guild_id, uint64_t role_id) {
    for (const ArchiveRow& row : app.db.archive_rows(guild_id, "overwrites")) {
        try {
            const dpp::json arr = dpp::json::parse(row.data);
            for (const auto& o : arr) {
                if (o.value("t", -1) != 0) continue;  // 0 = role overwrite
                if (std::stoull(o.value("i", std::string("0"))) != role_id) continue;
                dpp::json data = dpp::json::object();
                data["c"] = std::to_string(row.id);
                data["a"] = o.value("a", std::string("0"));
                data["d"] = o.value("d", std::string("0"));
                app.db.tombstone_add(guild_id, "overwrite", role_id, data.dump(-1, ' ', false, dpp::json::error_handler_t::replace));
            }
        } catch (...) {
        }
    }
}

void archive_on_member_remove(App& app, uint64_t guild_id, uint64_t user_id) {
    if (guild_id == 0) return;
    app.db.archive_delete(guild_id, "member", user_id);
}

void archive_seed(App& app) {
    for (auto& entry : dpp::get_guild_cache()->get_container()) {
        dpp::guild* g = entry.second;
        if (!g) continue;
        const uint64_t guild = static_cast<uint64_t>(g->id);
        for (const auto& member : g->members) archive_on_member(app, guild, member.second);
    }
    for (auto& entry : dpp::get_channel_cache()->get_container()) {
        if (entry.second) archive_on_channel(app, static_cast<uint64_t>(entry.second->guild_id), *entry.second);
    }
    app.bot.log(dpp::ll_info, "undo archive seeded from the member cache");
}

}  // namespace flour
