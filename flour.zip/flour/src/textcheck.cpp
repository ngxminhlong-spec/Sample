#include "textcheck.hpp"

#include <map>
#include <memory>
#include <mutex>
#include <regex>

#include "util.hpp"

namespace flour {

namespace {

constexpr size_t kMinDuplicateLength = 4;  // "lol" repeated isn't worth acting on

const std::regex& invite_regex() {
    static const std::regex re(R"((discord\.gg|discord(app)?\.com/invite)/[A-Za-z0-9-]+)",
                               std::regex::ECMAScript | std::regex::icase);
    return re;
}

// Compiled user regexes, cached by pattern. Returns nullptr if the pattern is invalid.
const std::regex* compiled(const std::string& pattern) {
    static std::mutex mu;
    static std::map<std::string, std::unique_ptr<std::regex>> cache;
    std::lock_guard<std::mutex> lock(mu);
    auto it = cache.find(pattern);
    if (it != cache.end()) return it->second.get();
    std::unique_ptr<std::regex> re;
    try {
        re = std::make_unique<std::regex>(pattern, std::regex::ECMAScript | std::regex::icase);
    } catch (const std::regex_error&) {
    }
    const std::regex* raw = re.get();
    cache[pattern] = std::move(re);
    return raw;
}

// Mentions, custom emoji and links shouldn't count as "text" for the caps check.
std::string strip_tokens(const std::string& s) {
    static const std::regex re(R"(<[^>\s]+>|https?://\S+|www\.\S+)", std::regex::ECMAScript | std::regex::icase);
    return std::regex_replace(s, re, " ");
}

// Decodes one UTF-8 code point starting at s[i]. Returns how many bytes it used (1 if invalid).
size_t decode_utf8(const std::string& s, size_t i, uint32_t& cp) {
    const unsigned char c = static_cast<unsigned char>(s[i]);
    size_t len = 1;
    cp = c;
    if (c >= 0xF0) { len = 4; cp = c & 0x07; }
    else if (c >= 0xE0) { len = 3; cp = c & 0x0F; }
    else if (c >= 0xC0) { len = 2; cp = c & 0x1F; }
    else return 1;
    if (i + len > s.size()) { cp = c; return 1; }
    for (size_t k = 1; k < len; ++k) {
        const unsigned char cc = static_cast<unsigned char>(s[i + k]);
        if ((cc & 0xC0) != 0x80) { cp = c; return 1; }
        cp = (cp << 6) | (cc & 0x3F);
    }
    return len;
}

bool is_emoji_codepoint(uint32_t cp) {
    if (cp >= 0x1F3FB && cp <= 0x1F3FF) return false;  // skin tone modifiers ride along with another emoji
    if (cp >= 0x1F1E6 && cp <= 0x1F1FF) return false;  // flags are counted separately
    return (cp >= 0x1F300 && cp <= 0x1FAFF) || (cp >= 0x1F000 && cp <= 0x1F2FF) ||
           (cp >= 0x2600 && cp <= 0x27BF) || (cp >= 0x23E9 && cp <= 0x23F3) ||
           (cp >= 0x23F8 && cp <= 0x23FA) || cp == 0x231A || cp == 0x231B ||
           cp == 0x2B50 || cp == 0x2B55 || cp == 0x2B1B || cp == 0x2B1C;
}

// Hosts mentioned in a message: explicit links, www. links and bare domains with a common TLD.
std::vector<std::string> extract_hosts(const std::string& content) {
    static const std::regex linked(R"((?:https?://|www\.)([A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+))",
                                   std::regex::ECMAScript | std::regex::icase);
    static const std::regex bare(
        R"((?:^|[^A-Za-z0-9.@-])((?:[A-Za-z0-9-]+\.)+(?:com|net|org|io|gg|co|me|xyz|ru|tv|ly|to|cc|info|biz|link|site|online|store|app|dev|ai|us|uk|de|fr|gift|click|shop|top|be|sh|gl|ws|tk|ml|ga|cf|pw|su|in|ca|eu))(?![A-Za-z0-9-]))",
        std::regex::ECMAScript | std::regex::icase);

    std::vector<std::string> hosts;
    for (const std::regex* re : {&linked, &bare}) {
        for (auto it = std::sregex_iterator(content.begin(), content.end(), *re); it != std::sregex_iterator(); ++it) {
            hosts.push_back(to_lower((*it)[1].str()));
        }
    }
    return hosts;
}

bool host_allowed(const std::string& host, const std::vector<std::string>& allowed) {
    for (const std::string& d : allowed) {
        if (host == d) return true;
        if (host.size() > d.size() && host.compare(host.size() - d.size(), d.size(), d) == 0 &&
            host[host.size() - d.size() - 1] == '.') {
            return true;
        }
    }
    return false;
}

}  // namespace

bool contains_invite(const std::string& content) {
    return std::regex_search(content, invite_regex());
}

bool matches_filter(const std::string& content, const std::string& lowered, const FilterRow& f) {
    if (f.is_regex) {
        const std::regex* re = compiled(f.pattern);
        return re && std::regex_search(content, *re);
    }
    return lowered.find(to_lower(f.pattern)) != std::string::npos;
}

bool is_shouting(const std::string& content, int percent, int min_letters) {
    const std::string text = strip_tokens(content);
    size_t letters = 0, upper = 0;
    for (unsigned char c : text) {
        if (c >= 'A' && c <= 'Z') { ++letters; ++upper; }
        else if (c >= 'a' && c <= 'z') ++letters;
    }
    if (letters < static_cast<size_t>(std::max(min_letters, 1))) return false;
    return upper * 100 >= letters * static_cast<size_t>(percent);
}

int count_emoji(const std::string& s) {
    int count = 0;

    static const std::regex custom(R"(<a?:\w+:\d+>)");
    for (auto it = std::sregex_iterator(s.begin(), s.end(), custom); it != std::sregex_iterator(); ++it) ++count;

    uint32_t previous = 0;
    int regional = 0;
    for (size_t i = 0; i < s.size();) {
        uint32_t cp = 0;
        i += decode_utf8(s, i, cp);
        if (cp >= 0x1F1E6 && cp <= 0x1F1FF) {
            ++regional;
        } else if (previous != 0x200D && is_emoji_codepoint(cp)) {
            ++count;  // anything glued on with a zero-width joiner is part of the same emoji
        }
        previous = cp;
    }
    return count + regional / 2;
}

bool has_unapproved_link(const std::string& content, const std::vector<std::string>& allowed) {
    for (const std::string& host : extract_hosts(content)) {
        if (!host_allowed(host, allowed)) return true;
    }
    return false;
}

size_t duplicate_hash(const std::string& content) {
    std::string norm;
    for (unsigned char c : content) {
        if (!std::isspace(c)) norm.push_back(static_cast<char>(std::tolower(c)));
    }
    if (norm.size() < kMinDuplicateLength) return 0;
    const size_t h = std::hash<std::string>{}(norm);
    return h == 0 ? 1 : h;
}

}  // namespace flour
