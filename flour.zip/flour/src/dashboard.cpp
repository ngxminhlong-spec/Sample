#define CPPHTTPLIB_OPENSSL_SUPPORT
#include "third_party/httplib.h"

#include <cctype>
#include <cstdio>
#include <map>
#include <mutex>
#include <optional>
#include <random>
#include <thread>

#include "app.hpp"
#include "util.hpp"

namespace flour {

namespace {

constexpr int64_t kSessionTtl = 12 * 3600;
constexpr int64_t kStateTtl = 600;
constexpr uint64_t kPermManageGuild = 0x20;
constexpr uint64_t kPermAdministrator = 0x8;

struct GuildAccess {
    bool owner = false;
    uint64_t perms = 0;
    bool manage() const { return owner || (perms & (kPermManageGuild | kPermAdministrator)) != 0; }
    bool admin() const { return owner || (perms & kPermAdministrator) != 0; }
};

struct Session {
    uint64_t user_id = 0;
    std::string username;
    int64_t expires = 0;
    std::map<uint64_t, GuildAccess> guilds;
};

std::mutex g_mutex;
std::map<std::string, Session> g_sessions;
std::map<std::string, int64_t> g_states;
DashboardConfig g_cfg;
App* g_app = nullptr;

int64_t now_s() { return static_cast<int64_t>(time(nullptr)); }

std::string random_hex(size_t bytes) {
    std::random_device rd;
    const char* hex = "0123456789abcdef";
    std::string out;
    for (size_t i = 0; i < bytes; ++i) {
        const unsigned b = rd() & 0xff;
        out += hex[b >> 4];
        out += hex[b & 15];
    }
    return out;
}

std::string url_encode(const std::string& s) {
    std::string out;
    for (unsigned char c : s) {
        if (std::isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') out += static_cast<char>(c);
        else {
            char buf[4];
            std::snprintf(buf, sizeof buf, "%%%02X", c);
            out += buf;
        }
    }
    return out;
}

std::optional<Session> session_from(const httplib::Request& req) {
    const std::string cookie = req.get_header_value("Cookie");
    const std::string key = "flour_session=";
    const size_t at = cookie.find(key);
    if (at == std::string::npos) return std::nullopt;
    size_t end = cookie.find(';', at);
    const std::string token = cookie.substr(at + key.size(), end == std::string::npos ? std::string::npos : end - at - key.size());

    std::lock_guard<std::mutex> lock(g_mutex);
    auto it = g_sessions.find(token);
    if (it == g_sessions.end() || it->second.expires < now_s()) return std::nullopt;
    return it->second;
}

// A session may only touch servers where it still has Manage Server, and where the bot is present.
bool can_manage(const Session& s, uint64_t guild_id) {
    auto it = s.guilds.find(guild_id);
    return it != s.guilds.end() && it->second.manage() && dpp::find_guild(guild_id) != nullptr;
}

void send_error(httplib::Response& res, int status, const std::string& message) {
    res.status = status;
    res.set_content(dpp::json{{"error", message}}.dump(), "application/json");
}

// ============================================================ settings

struct Setting {
    const char* key;
    const char* label;
    const char* group;
    bool nuke;
    int64_t min;
    int64_t max;
    int64_t (*read)(const GuildConfig&, const NukeConfig&);
};

const Setting kSettings[] = {
    {"spam_action", "Spam punishment", "Auto-mod", false, 0, 3, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.spam_action; }},
    {"dup_action", "Repeated messages punishment", "Auto-mod", false, 0, 3, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.dup_action; }},
    {"mention_action", "Mass mention punishment", "Auto-mod", false, 0, 3, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.mention_action; }},
    {"invite_action", "Invite link punishment", "Auto-mod", false, 0, 3, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.invite_action; }},
    {"link_action", "Link allowlist punishment", "Auto-mod", false, 0, 3, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.link_action; }},
    {"word_action", "Word filter punishment", "Auto-mod", false, 0, 3, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.word_action; }},
    {"caps_action", "Excessive caps punishment", "Auto-mod", false, 0, 3, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.caps_action; }},
    {"emoji_action", "Emoji spam punishment", "Auto-mod", false, 0, 3, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.emoji_action; }},
    {"spam_limit", "Spam: messages per window", "Auto-mod thresholds", false, 1, 30, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.spam_limit; }},
    {"spam_window", "Spam: window (seconds)", "Auto-mod thresholds", false, 1, 60, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.spam_window; }},
    {"dup_limit", "Repeats: identical messages", "Auto-mod thresholds", false, 2, 20, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.dup_limit; }},
    {"dup_window", "Repeats: window (seconds)", "Auto-mod thresholds", false, 5, 300, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.dup_window; }},
    {"mention_limit", "Mentions per message", "Auto-mod thresholds", false, 1, 50, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.mention_limit; }},
    {"caps_percent", "Caps: percent capitals", "Auto-mod thresholds", false, 40, 100, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.caps_percent; }},
    {"caps_min_len", "Caps: minimum letters", "Auto-mod thresholds", false, 5, 200, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.caps_min_len; }},
    {"emoji_limit", "Emoji per message", "Auto-mod thresholds", false, 1, 100, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.emoji_limit; }},
    {"automod_timeout_mins", "Auto-mod timeout (minutes)", "Auto-mod thresholds", false, 1, 40320, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.automod_timeout_mins; }},
    {"warn_timeout_at", "Timeout at N active warnings (0 = off)", "Warnings", false, 0, 20, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.warn_timeout_at; }},
    {"warn_timeout_mins", "Warning timeout length (minutes)", "Warnings", false, 1, 40320, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.warn_timeout_mins; }},
    {"warn_ban_at", "Ban at N active warnings (0 = off)", "Warnings", false, 0, 50, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.warn_ban_at; }},
    {"min_account_age", "Kick accounts younger than (days, 0 = off)", "Accounts", false, 0, 365, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.min_account_age; }},
    {"heat_enabled", "Heat system (1 = on)", "Heat (anti-raid)", false, 0, 1, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.heat_enabled ? 1 : 0; }},
    {"heat_warm", "Warm level", "Heat (anti-raid)", false, 1, 1000, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.heat_warm; }},
    {"heat_hot", "Hot level", "Heat (anti-raid)", false, 1, 1000, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.heat_hot; }},
    {"heat_critical", "Critical level", "Heat (anti-raid)", false, 1, 1000, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.heat_critical; }},
    {"heat_decay", "Points cooled per minute", "Heat (anti-raid)", false, 0, 1000, [](const GuildConfig& c, const NukeConfig&) -> int64_t { return c.heat_decay; }},
    {"enabled", "Anti-nuke on (1 = on)", "Anti-nuke", true, 0, 1, [](const GuildConfig&, const NukeConfig& n) -> int64_t { return n.enabled ? 1 : 0; }},
    {"action", "Anti-nuke response (1 = strip roles, 2 = ban)", "Anti-nuke", true, 1, 2, [](const GuildConfig&, const NukeConfig& n) -> int64_t { return n.action; }},
    {"bans_limit", "Bans limit", "Anti-nuke", true, 1, 100, [](const GuildConfig&, const NukeConfig& n) -> int64_t { return n.bans_limit; }},
    {"kicks_limit", "Kicks limit", "Anti-nuke", true, 1, 100, [](const GuildConfig&, const NukeConfig& n) -> int64_t { return n.kicks_limit; }},
    {"channels_limit", "Channel deletes limit", "Anti-nuke", true, 1, 100, [](const GuildConfig&, const NukeConfig& n) -> int64_t { return n.channels_limit; }},
    {"roles_limit", "Role deletes limit", "Anti-nuke", true, 1, 100, [](const GuildConfig&, const NukeConfig& n) -> int64_t { return n.roles_limit; }},
    {"admin_roles_limit", "Administrator grants limit", "Anti-nuke", true, 1, 100, [](const GuildConfig&, const NukeConfig& n) -> int64_t { return n.admin_roles_limit; }},
    {"webhooks_limit", "Webhook changes limit", "Anti-nuke", true, 1, 100, [](const GuildConfig&, const NukeConfig& n) -> int64_t { return n.webhooks_limit; }},
    {"window_secs", "Anti-nuke window (seconds)", "Anti-nuke", true, 5, 300, [](const GuildConfig&, const NukeConfig& n) -> int64_t { return n.window_secs; }},
};

const Setting* find_setting(const std::string& key) {
    for (const Setting& s : kSettings) {
        if (key == s.key) return &s;
    }
    return nullptr;
}

// Heat levels must stay in order, the same check the slash command does.
bool heat_order_ok(App& app, uint64_t guild, const std::string& key, int64_t value) {
    if (key != "heat_warm" && key != "heat_hot" && key != "heat_critical") return true;
    GuildConfig c = app.db.get_config(guild);
    if (key == "heat_warm") c.heat_warm = static_cast<int>(value);
    if (key == "heat_hot") c.heat_hot = static_cast<int>(value);
    if (key == "heat_critical") c.heat_critical = static_cast<int>(value);
    return c.heat_warm < c.heat_hot && c.heat_hot < c.heat_critical;
}

// ============================================================ OAuth login

void handle_login(const httplib::Request&, httplib::Response& res) {
    const std::string state = random_hex(16);
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_states[state] = now_s() + kStateTtl;
    }
    const std::string url = "https://discord.com/oauth2/authorize?client_id=" + g_cfg.client_id +
                            "&redirect_uri=" + url_encode(g_cfg.redirect_uri) +
                            "&response_type=code&scope=identify%20guilds&state=" + state;
    res.set_redirect(url);
}

bool consume_state(const std::string& state) {
    std::lock_guard<std::mutex> lock(g_mutex);
    auto it = g_states.find(state);
    if (it == g_states.end()) return false;
    const bool fresh = it->second >= now_s();
    g_states.erase(it);
    return fresh;
}

void handle_callback(const httplib::Request& req, httplib::Response& res) {
    const std::string code = req.get_param_value("code");
    if (code.empty() || !consume_state(req.get_param_value("state"))) {
        send_error(res, 400, "That login link has expired. Try logging in again.");
        return;
    }

    httplib::SSLClient cli("discord.com");
    cli.set_connection_timeout(10);
    cli.set_read_timeout(10);

    httplib::Params form{
        {"client_id", g_cfg.client_id},
        {"client_secret", g_cfg.client_secret},
        {"grant_type", "authorization_code"},
        {"code", code},
        {"redirect_uri", g_cfg.redirect_uri},
    };
    auto tok = cli.Post("/api/v10/oauth2/token", form);
    if (!tok || tok->status != 200) {
        send_error(res, 502, "Discord rejected the login.");
        return;
    }

    std::string access;
    try {
        access = dpp::json::parse(tok->body).value("access_token", std::string());
    } catch (...) {
    }
    if (access.empty()) {
        send_error(res, 502, "Discord didn't return a token.");
        return;
    }

    const httplib::Headers auth{{"Authorization", "Bearer " + access}};
    auto me = cli.Get("/api/v10/users/@me", auth);
    auto guilds = cli.Get("/api/v10/users/@me/guilds", auth);
    if (!me || me->status != 200 || !guilds || guilds->status != 200) {
        send_error(res, 502, "Couldn't read your Discord account.");
        return;
    }

    Session s;
    s.expires = now_s() + kSessionTtl;
    try {
        const dpp::json user = dpp::json::parse(me->body);
        s.user_id = std::stoull(user.value("id", std::string("0")));
        s.username = user.value("username", std::string());
        for (const auto& g : dpp::json::parse(guilds->body)) {
            GuildAccess a;
            a.owner = g.value("owner", false);
            a.perms = std::stoull(g.value("permissions", std::string("0")));
            s.guilds[std::stoull(g.value("id", std::string("0")))] = a;
        }
    } catch (...) {
        send_error(res, 502, "Couldn't read your Discord account.");
        return;
    }

    const std::string token = random_hex(32);
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_sessions[token] = s;
    }
    res.set_header("Set-Cookie", "flour_session=" + token + "; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=" +
                                     std::to_string(kSessionTtl));
    res.set_redirect("/");
}

// ============================================================ API

void handle_me(const httplib::Request& req, httplib::Response& res) {
    auto s = session_from(req);
    if (!s) return send_error(res, 401, "Log in first.");

    dpp::json servers = dpp::json::array();
    for (const auto& [gid, access] : s->guilds) {
        if (!access.manage()) continue;
        dpp::guild* g = dpp::find_guild(gid);
        if (!g) continue;  // the bot isn't in this server
        servers.push_back({{"id", std::to_string(gid)}, {"name", g->name}, {"admin", access.admin()}});
    }
    res.set_content(dpp::json{{"username", s->username}, {"servers", servers}}.dump(), "application/json");
}

void handle_get_guild(const httplib::Request& req, httplib::Response& res) {
    auto s = session_from(req);
    if (!s) return send_error(res, 401, "Log in first.");
    const uint64_t gid = std::stoull(req.matches[1]);
    if (!can_manage(*s, gid)) return send_error(res, 403, "You don't manage that server.");

    const GuildConfig c = g_app->db.get_config(gid);
    const NukeConfig n = g_app->db.get_nuke_config(gid);
    dpp::json settings = dpp::json::array();
    for (const Setting& st : kSettings) {
        settings.push_back({{"key", st.key}, {"label", st.label}, {"group", st.group}, {"nuke", st.nuke},
                            {"min", st.min}, {"max", st.max}, {"value", st.read(c, n)}});
    }
    res.set_content(dpp::json{{"guild", std::to_string(gid)}, {"settings", settings}}.dump(), "application/json");
}

void handle_set(const httplib::Request& req, httplib::Response& res) {
    auto s = session_from(req);
    if (!s) return send_error(res, 401, "Log in first.");
    // A cross-site form can't set this header without a CORS preflight, which we never allow.
    if (req.get_header_value("X-Flour") != "1") return send_error(res, 400, "Missing request header.");

    const uint64_t gid = std::stoull(req.matches[1]);
    if (!can_manage(*s, gid)) return send_error(res, 403, "You don't manage that server.");

    std::string key;
    int64_t value = 0;
    try {
        const dpp::json body = dpp::json::parse(req.body);
        key = body.value("key", std::string());
        value = body.value("value", static_cast<int64_t>(0));
    } catch (...) {
        return send_error(res, 400, "Bad request body.");
    }

    const Setting* st = find_setting(key);
    if (!st) return send_error(res, 400, "Unknown setting.");
    if (st->nuke && !s->guilds[gid].admin()) return send_error(res, 403, "Anti-nuke is for the owner and Administrators.");
    if (value < st->min || value > st->max) {
        return send_error(res, 400, std::string(st->label) + " must be between " + std::to_string(st->min) + " and " + std::to_string(st->max) + ".");
    }
    if (!heat_order_ok(*g_app, gid, key, value)) {
        return send_error(res, 400, "Heat levels must stay in order: warm < hot < critical.");
    }

    const bool ok = st->nuke ? g_app->db.set_nuke_value(gid, key, value) : g_app->db.set_config_value(gid, key, value);
    if (!ok) return send_error(res, 500, "Couldn't save that setting.");

    log_event(*g_app, gid, "Settings changed",
              s->username + " set `" + key + "` to `" + std::to_string(value) + "` from the dashboard", color::info);
    res.set_content("{\"ok\":true}", "application/json");
}

void handle_logout(const httplib::Request& req, httplib::Response& res) {
    const std::string cookie = req.get_header_value("Cookie");
    const size_t at = cookie.find("flour_session=");
    if (at != std::string::npos) {
        std::string token = cookie.substr(at + 14);
        token = token.substr(0, token.find(';'));
        std::lock_guard<std::mutex> lock(g_mutex);
        g_sessions.erase(token);
    }
    res.set_header("Set-Cookie", "flour_session=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax");
    res.set_content("{\"ok\":true}", "application/json");
}

// ============================================================ page

const char* kPage = R"HTML(<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Flour</title>
<style>
body{font-family:system-ui,sans-serif;background:#1e1f22;color:#dbdee1;margin:0;padding:24px;max-width:900px}
h1{font-size:22px;margin:0 0 16px}
a,button{color:#fff;background:#5865f2;border:0;border-radius:4px;padding:8px 14px;text-decoration:none;cursor:pointer;font-size:14px}
button.secondary{background:#4e5058}
select,input{background:#2b2d31;color:#dbdee1;border:1px solid #3f4147;border-radius:4px;padding:6px 8px;font-size:14px}
table{width:100%;border-collapse:collapse;margin-top:12px}
td,th{text-align:left;padding:8px;border-bottom:1px solid #3f4147;font-size:14px}
.group{color:#949ba4;font-size:12px;text-transform:uppercase;padding-top:18px}
.msg{margin-top:12px;font-size:13px;min-height:18px}
.ok{color:#23a55a}.err{color:#f23f43}
</style></head><body>
<h1>Flour</h1>
<div id="login" hidden><p>Log in with Discord to manage your servers.</p><a href="/login">Log in with Discord</a></div>
<div id="app" hidden>
  <p>Signed in as <b id="who"></b> &middot; <button class="secondary" id="logout">Log out</button></p>
  <p><label>Server <select id="server"></select></label></p>
  <table><thead><tr><th>Setting</th><th>Value</th><th></th></tr></thead><tbody id="rows"></tbody></table>
  <div class="msg" id="msg"></div>
</div>
<script>
const $ = id => document.getElementById(id);
function say(text, ok){ const m=$('msg'); m.textContent=text; m.className='msg '+(ok?'ok':'err'); }
async function api(path, body){
  const opts = body ? {method:'POST', headers:{'Content-Type':'application/json','X-Flour':'1'}, body:JSON.stringify(body)} : {};
  const r = await fetch(path, Object.assign({credentials:'same-origin'}, opts));
  const j = await r.json().catch(()=>({error:'Unexpected response'}));
  if(!r.ok) throw new Error(j.error || 'Request failed');
  return j;
}
async function loadGuild(){
  const id = $('server').value; if(!id) return;
  const g = await api('/api/guild/'+id);
  const tbody = $('rows'); tbody.textContent='';
  let lastGroup = '';
  for (const s of g.settings){
    if (s.group !== lastGroup){
      const tr=document.createElement('tr'); const td=document.createElement('td');
      td.colSpan=3; td.className='group'; td.textContent=s.group; tr.appendChild(td); tbody.appendChild(tr); lastGroup=s.group;
    }
    const tr=document.createElement('tr');
    const label=document.createElement('td'); label.textContent=s.label;
    const val=document.createElement('td');
    const input=document.createElement('input'); input.type='number'; input.min=s.min; input.max=s.max; input.value=s.value; input.dataset.key=s.key; input.style.width='110px';
    val.appendChild(input);
    const act=document.createElement('td'); const btn=document.createElement('button'); btn.textContent='Save';
    btn.onclick = async () => {
      try { await api('/api/guild/'+id+'/set', {key:s.key, value:Number(input.value)}); say('Saved '+s.label+'.', true); }
      catch(e){ say(e.message, false); }
    };
    act.appendChild(btn); tr.append(label,val,act); tbody.appendChild(tr);
  }
}
async function init(){
  try {
    const me = await api('/api/me');
    $('who').textContent = me.username; $('app').hidden = false;
    const sel = $('server'); sel.textContent='';
    for (const s of me.servers){ const o=document.createElement('option'); o.value=s.id; o.textContent=s.name; sel.appendChild(o); }
    if (!me.servers.length) say('No servers yet. Invite Flour to one and manage it on Discord.', false);
    sel.onchange = () => loadGuild().catch(e => say(e.message, false));
    await loadGuild();
  } catch(e){ $('login').hidden = false; }
}
$('logout').onclick = async () => { await api('/logout', {}).catch(()=>{}); location.reload(); };
init();
</script></body></html>
)HTML";

}  // namespace

void start_dashboard(App& app, const DashboardConfig& cfg) {
    if (!cfg.enabled) return;
    if (cfg.client_id.empty() || cfg.client_secret.empty() || cfg.redirect_uri.empty()) {
        app.bot.log(dpp::ll_error, "dashboard is enabled but client_id, client_secret or redirect_uri is missing");
        return;
    }
    g_app = &app;
    g_cfg = cfg;

    auto* svr = new httplib::Server();  // lives for the life of the process
    svr->Get("/", [](const httplib::Request&, httplib::Response& res) {
        res.set_content(kPage, "text/html; charset=utf-8");
    });
    svr->Get("/login", handle_login);
    svr->Get("/callback", handle_callback);
    svr->Get("/api/me", handle_me);
    svr->Get(R"(/api/guild/(\d+))", handle_get_guild);
    svr->Post(R"(/api/guild/(\d+)/set)", handle_set);
    svr->Post("/logout", handle_logout);

    if (!svr->bind_to_port(cfg.host, cfg.port)) {
        app.bot.log(dpp::ll_error, "dashboard could not bind to " + cfg.host + ":" + std::to_string(cfg.port));
        return;
    }
    std::thread([svr]() { svr->listen_after_bind(); }).detach();
    app.bot.log(dpp::ll_info, "dashboard listening on http://" + cfg.host + ":" + std::to_string(cfg.port) +
                                  " (put tailscale serve in front of it)");
}

}  // namespace flour
