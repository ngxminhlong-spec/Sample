#pragma once
#include <cstdint>
#include <optional>
#include <string>

namespace flour {

// "10m", "2h", "7d", "1w", "1h30m" -> seconds. nullopt if malformed or zero.
std::optional<int64_t> parse_duration(const std::string& text);

// 3725 -> "1h 2m 5s"
std::string format_duration(int64_t seconds);

// Discord timestamp markup, e.g. <t:1700000000:R>
std::string discord_time(int64_t unix_ts, char style = 'R');

std::string truncate(const std::string& text, size_t max_len);
std::string to_lower(std::string text);

namespace color {
constexpr uint32_t ok = 0x57F287;
constexpr uint32_t info = 0x5865F2;
constexpr uint32_t warn = 0xFEE75C;
constexpr uint32_t danger = 0xED4245;
constexpr uint32_t neutral = 0x99AAB5;
}

}  // namespace flour
