#pragma once
#include <string>
#include <vector>

#include "database.hpp"

// Text checks used by auto-mod. No Discord types in here, so they can be tested on their own.
namespace flour {

bool contains_invite(const std::string& content);
// `lowered` is `content` in lower case, passed in so a long filter list only lowercases once.
bool matches_filter(const std::string& content, const std::string& lowered, const FilterRow& filter);
// True if at least `percent` of the letters are capitals and there are at least `min_letters` of them.
bool is_shouting(const std::string& content, int percent, int min_letters);
int count_emoji(const std::string& content);
// True if the message links to a host that isn't one of `allowed` (or a subdomain of one).
bool has_unapproved_link(const std::string& content, const std::vector<std::string>& allowed);
// Hash of the message ignoring case and whitespace. 0 means "too short to count as a duplicate".
size_t duplicate_hash(const std::string& content);

}  // namespace flour
