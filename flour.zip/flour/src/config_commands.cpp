#include <regex>

#include "app.hpp"
#include "util.hpp"

namespace flour {

namespace {

using Event = dpp::slashcommand_t;

struct Setting {
    const char* key;
    const char* label;
    int64_t min;
    int64_t max;
};

const Setting kSettings[] = {
    {"min_account_age", "Kick accounts younger than N days (0 = off)", 0, 365},
    {"warn_timeout_at", "Timeout at N active warnings (0 = off)", 0, 20},
    {"warn_timeout_mins", "Length of the warning timeout, in minutes", 1, 40320},
    {"warn_ban_at", "Ban at N active warnings (0 = off)", 0, 50},
    {"heat_enabled", "Anti-raid heat system (1 = on, 0 = off)", 0, 1},
    {"heat_warm", "Heat: warm level", 1, 1000},
    {"heat_hot", "Heat: hot level (quarantine new accounts)", 1, 1000},
    {"heat_critical", "Heat: critical level (lockdown)", 1, 1000},
    {"heat_decay", "Heat: points lost per minute", 0, 1000},
};

const Setting* find_setting(const std::string& key) {
    for (const Setting& s : kSettings) {
        if (key == s.key) return &s;
    }
    return nullptr;
}

dpp::message ephemeral(const std::string& text) {
    return dpp::message(text).set_flags(dpp::m_ephemeral);
}

std::string limit_or_off(int v) { return v > 0 ? std::to_string(v) : "off"; }

void config_show(App& app, const Event& e) {
    const GuildConfig c = app.db.get_config(e.command.guild_id);

    dpp::embed emb;
    emb.set_color(color::info);
    emb.set_title("Flour settings");
    emb.add_field("Mod log",
                  c.modlog_channel ? "<#" + std::to_string(c.modlog_channel) + ">" : "Not set. Use `/config modlog`.",
                  false);
    emb.add_field("Auto-mod", automod_summary(c) + "\nDetails: `/automod show`", false);
    emb.add_field("Heat (anti-raid)",
                  c.heat_enabled ? "warm " + std::to_string(c.heat_warm) + " / hot " + std::to_string(c.heat_hot) +
                                       " / critical " + std::to_string(c.heat_critical) + ", cools " +
                                       std::to_string(c.heat_decay) + "/min"
                                 : "off",
                  true);
    emb.add_field("Min account age", c.min_account_age > 0 ? std::to_string(c.min_account_age) + " day(s)" : "off", true);
    emb.add_field("Warning ladder",
                  "Timeout at " + limit_or_off(c.warn_timeout_at) +
                      (c.warn_timeout_at > 0 ? " (" + format_duration(c.warn_timeout_mins * 60LL) + ")" : "") +
                      "\nBan at " + limit_or_off(c.warn_ban_at),
                  false);
    emb.set_footer(dpp::embed_footer().set_text("Moderators (Manage Messages or Administrator) are exempt from auto-mod"));

    dpp::message m;
    m.add_embed(emb);
    m.set_flags(dpp::m_ephemeral);
    e.reply(m);
}

void config_modlog(App& app, const Event& e) {
    const uint64_t gid = e.command.guild_id;
    const dpp::snowflake channel = opt_id(e, "channel");
    const uint64_t mod = e.command.usr.id;

    e.thinking(true);
    app.bot.message_create(
        dpp::message(channel, "Flour will post moderation cases here."),
        [&app, e, gid, channel, mod](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) {
                e.edit_response(ephemeral("I can't send messages in that channel. Give me **View Channel**, "
                                          "**Send Messages** and **Embed Links** there, then try again."));
                return;
            }
            app.db.set_modlog_channel(gid, channel);
            log_event(app, gid, "Settings changed",
                      "<@" + std::to_string(mod) + "> set the mod log to <#" +
                          std::to_string(static_cast<uint64_t>(channel)) + ">",
                      color::info);
            e.edit_response(ephemeral("Mod log set to <#" + std::to_string(static_cast<uint64_t>(channel)) + ">."));
        });
}

void config_set(App& app, const Event& e) {
    const std::string key = opt_str(e, "setting");
    const int64_t value = opt_int(e, "value");

    const Setting* s = find_setting(key);
    if (!s) return reply_error(e, "Unknown setting.");
    if (value < s->min || value > s->max) {
        return reply_error(e, std::string("`") + s->key + "` must be between " + std::to_string(s->min) +
                                  " and " + std::to_string(s->max) + ".");
    }

    // The heat levels have to stay in order: warm < hot < critical.
    if (key == "heat_warm" || key == "heat_hot" || key == "heat_critical") {
        GuildConfig c = app.db.get_config(e.command.guild_id);
        if (key == "heat_warm") c.heat_warm = static_cast<int>(value);
        if (key == "heat_hot") c.heat_hot = static_cast<int>(value);
        if (key == "heat_critical") c.heat_critical = static_cast<int>(value);
        if (!(c.heat_warm < c.heat_hot && c.heat_hot < c.heat_critical)) {
            return reply_error(e, "Heat levels must stay in order: warm < hot < critical (currently " +
                                      std::to_string(c.heat_warm) + " / " + std::to_string(c.heat_hot) + " / " +
                                      std::to_string(c.heat_critical) + " with that change).");
        }
    }

    if (!app.db.set_config_value(e.command.guild_id, key, value)) return reply_error(e, "Couldn't save that setting.");

    log_event(app, e.command.guild_id, "Settings changed",
              "<@" + std::to_string(static_cast<uint64_t>(e.command.usr.id)) + "> set `" + key + "` to `" +
                  std::to_string(value) + "`",
              color::info);
    e.reply(ephemeral("`" + key + "` is now `" + std::to_string(value) + "`."));
}

void filter_add(App& app, const Event& e) {
    const std::string pattern = opt_str(e, "pattern");
    const bool is_regex = opt_bool(e, "regex", false);

    if (pattern.empty() || pattern.size() > 200) return reply_error(e, "Patterns must be 1-200 characters long.");
    if (is_regex) {
        try {
            std::regex test(pattern, std::regex::ECMAScript | std::regex::icase);
        } catch (const std::regex_error& ex) {
            return reply_error(e, std::string("That isn't a valid regular expression: ") + ex.what());
        }
    }

    const int64_t id = app.db.add_filter(e.command.guild_id, pattern, is_regex);
    std::string text = "Added filter #" + std::to_string(id) + ".";
    if (app.db.get_config(e.command.guild_id).word_action == automod_off) {
        text += " The word filter is currently off. Turn it on with `/automod rule name:words action:warn`.";
    }
    e.reply(ephemeral(text));
}

void filter_remove(App& app, const Event& e) {
    const int64_t id = opt_int(e, "id");
    if (!app.db.remove_filter(e.command.guild_id, id)) {
        return reply_error(e, "There's no filter #" + std::to_string(id) + " here.");
    }
    e.reply(ephemeral("Removed filter #" + std::to_string(id) + "."));
}

void filter_list(App& app, const Event& e) {
    std::string body;
    for (const FilterRow& f : app.db.list_filters(e.command.guild_id)) {
        body += "**#" + std::to_string(f.id) + "** " + (f.is_regex ? "regex " : "text ") + "`" +
                truncate(f.pattern, 80) + "`\n";
    }
    if (body.empty()) body = "No filters yet. Add one with `/filter add`.";

    dpp::embed emb;
    emb.set_color(color::info);
    emb.set_title("Word filters");
    emb.set_description(truncate(body, 4000));

    dpp::message m;
    m.add_embed(emb);
    m.set_flags(dpp::m_ephemeral);
    e.reply(m);
}

}  // namespace

std::vector<dpp::slashcommand> build_config_commands(dpp::snowflake bot_id) {
    std::vector<dpp::slashcommand> cmds;

    dpp::command_option setting(dpp::co_string, "setting", "What to change", true);
    for (const Setting& s : kSettings) setting.add_choice(dpp::command_option_choice(s.label, std::string(s.key)));

    cmds.push_back(make_command("config", "Configure Flour for this server", bot_id, dpp::p_manage_guild)
        .add_option(dpp::command_option(dpp::co_sub_command, "show", "Show the current settings"))
        .add_option(dpp::command_option(dpp::co_sub_command, "modlog", "Choose the mod log channel")
            .add_option(dpp::command_option(dpp::co_channel, "channel", "Where cases are posted", true)
                .add_channel_type(dpp::CHANNEL_TEXT)))
        .add_option(dpp::command_option(dpp::co_sub_command, "set", "Change an auto-mod or warning setting")
            .add_option(setting)
            .add_option(dpp::command_option(dpp::co_integer, "value", "The new value", true).set_min_value(0))));

    cmds.push_back(make_command("filter", "Manage the word filter", bot_id, dpp::p_manage_guild)
        .add_option(dpp::command_option(dpp::co_sub_command, "add", "Add a filtered word or pattern")
            .add_option(dpp::command_option(dpp::co_string, "pattern", "Text to block", true))
            .add_option(dpp::command_option(dpp::co_boolean, "regex", "Treat the pattern as a regular expression", false)))
        .add_option(dpp::command_option(dpp::co_sub_command, "remove", "Remove a filter")
            .add_option(dpp::command_option(dpp::co_integer, "id", "Filter id from /filter list", true).set_min_value(1)))
        .add_option(dpp::command_option(dpp::co_sub_command, "list", "List all filters")));

    return cmds;
}

bool handle_config_command(App& app, const Event& e) {
    const std::string name = e.command.get_command_name();
    if (name != "config" && name != "filter") return false;

    const std::string sub = subcommand_name(e);
    if (name == "config") {
        if (sub == "show") config_show(app, e);
        else if (sub == "modlog") config_modlog(app, e);
        else if (sub == "set") config_set(app, e);
    } else {
        if (sub == "add") filter_add(app, e);
        else if (sub == "remove") filter_remove(app, e);
        else if (sub == "list") filter_list(app, e);
    }
    return true;
}

}  // namespace flour
