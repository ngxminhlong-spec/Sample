#pragma once
#include <cstdint>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <vector>

struct sqlite3;

namespace flour {

// Auto-mod rule actions: 0 = off, 1 = delete only, 2 = delete and warn, 3 = delete and timeout.
enum AutomodAction { automod_off = 0, automod_delete = 1, automod_warn = 2, automod_timeout = 3 };

struct GuildConfig {
    uint64_t guild_id = 0;
    uint64_t modlog_channel = 0;

    int spam_action = automod_off;
    int dup_action = automod_off;
    int mention_action = automod_off;
    int invite_action = automod_off;
    int link_action = automod_off;
    int word_action = automod_off;
    int caps_action = automod_off;
    int emoji_action = automod_off;

    int spam_limit = 6;          // more than this many messages...
    int spam_window = 5;         // ...in this many seconds
    int dup_limit = 3;           // this many identical messages...
    int dup_window = 30;         // ...in this many seconds
    int mention_limit = 5;       // mentions per message
    int caps_percent = 70;       // share of capital letters
    int caps_min_len = 12;       // ignore messages with fewer letters than this
    int emoji_limit = 10;        // emoji per message
    int automod_timeout_mins = 10;

    int min_account_age = 0;     // days, 0 = off

    bool heat_enabled = false;
    int heat_warm = 30;          // heat levels, on a 0-100+ scale
    int heat_hot = 60;
    int heat_critical = 90;
    int heat_decay = 30;         // heat lost per minute

    int warn_timeout_at = 3;     // active warnings that trigger a timeout, 0 = off
    int warn_timeout_mins = 60;
    int warn_ban_at = 5;         // active warnings that trigger a ban, 0 = off
};

struct CaseRow {
    int64_t id = 0;
    int64_t case_num = 0;
    uint64_t guild_id = 0;
    uint64_t user_id = 0;
    uint64_t mod_id = 0;
    std::string action;
    std::string reason;
    int64_t created_at = 0;
    int64_t expires_at = 0;  // 0 = never
    bool active = true;
};

struct FilterRow {
    int64_t id = 0;
    std::string pattern;
    bool is_regex = false;
};

struct TicketConfig {
    uint64_t guild_id = 0;
    uint64_t category_id = 0;        // category new ticket channels are created under
    uint64_t staff_role_id = 0;
    uint64_t transcript_channel = 0; // falls back to the mod log channel
    uint64_t appeals_channel = 0;    // 0 = ban appeals are off
};

struct TicketRow {
    int64_t id = 0;
    int64_t ticket_num = 0;
    uint64_t guild_id = 0;
    uint64_t channel_id = 0;
    uint64_t opener_id = 0;
    uint64_t claimed_by = 0;
    std::string subject;
    bool open = true;
    int64_t created_at = 0;
};

struct AppealRow {
    int64_t id = 0;
    uint64_t guild_id = 0;
    uint64_t user_id = 0;
    std::string text;
    std::string status;  // pending, approved, denied or failed
    uint64_t channel_id = 0;
    uint64_t message_id = 0;
    int64_t created_at = 0;
};

// Per-server lists the message handler needs on every message. Cached and shared.
struct AutomodLists {
    std::vector<uint64_t> exempt_roles;
    std::vector<uint64_t> exempt_channels;
    std::vector<std::string> allowed_domains;
    std::vector<FilterRow> filters;
};

struct LogConfig {
    uint64_t channel_id = 0;  // 0 = logging off
    int events = 31;          // bitmask of LogEvent
};

// Anti-nuke: action 1 = strip removable roles, 2 = ban.
struct NukeConfig {
    bool enabled = false;
    int action = 2;
    int bans_limit = 3;
    int kicks_limit = 3;
    int channels_limit = 3;
    int roles_limit = 3;
    int admin_roles_limit = 1;   // Administrator granted to a role or member
    int webhooks_limit = 3;      // webhooks created or deleted
    int window_secs = 20;
};

// Undo storage. Blobs are minified JSON.
struct ArchiveRow {
    uint64_t id = 0;
    uint64_t parent = 0;
    std::string data;
};

struct Tombstone {
    int64_t id = 0;
    uint64_t guild_id = 0;
    std::string kind;     // "role" or "channel"
    uint64_t obj_id = 0;
    std::string data;
    uint64_t executor = 0;
    int64_t created_at = 0;
};

struct TempAction {
    int64_t id = 0;
    uint64_t guild_id = 0;
    uint64_t user_id = 0;
    int64_t run_at = 0;
};

// One connection guarded by a mutex. DPP calls us from several threads.
class Database {
public:
    explicit Database(const std::string& path);
    ~Database();
    Database(const Database&) = delete;
    Database& operator=(const Database&) = delete;

    // Guild settings
    GuildConfig get_config(uint64_t guild_id);
    void set_modlog_channel(uint64_t guild_id, uint64_t channel_id);
    // `column` must be one of the names from config_columns(); returns false otherwise.
    bool set_config_value(uint64_t guild_id, const std::string& column, int64_t value);

    // Cases (append-only; see the triggers in the schema)
    CaseRow add_case(uint64_t guild_id, uint64_t user_id, uint64_t mod_id,
                     const std::string& action, const std::string& reason,
                     int64_t expires_at = 0, bool active = true);
    std::optional<CaseRow> get_case(uint64_t guild_id, int64_t case_num);
    std::vector<CaseRow> user_cases(uint64_t guild_id, uint64_t user_id, int limit, int offset);
    int count_cases(uint64_t guild_id, uint64_t user_id);
    int count_active_warns(uint64_t guild_id, uint64_t user_id);
    bool deactivate_case(uint64_t guild_id, int64_t case_num);

    // Word filters
    int64_t add_filter(uint64_t guild_id, const std::string& pattern, bool is_regex);
    bool remove_filter(uint64_t guild_id, int64_t filter_id);
    std::vector<FilterRow> list_filters(uint64_t guild_id);

    // Auto-mod exemptions and link allowlist. `kind` is "role" or "channel".
    std::shared_ptr<const AutomodLists> get_automod_lists(uint64_t guild_id);
    bool add_exempt(uint64_t guild_id, const std::string& kind, uint64_t target_id);
    bool remove_exempt(uint64_t guild_id, const std::string& kind, uint64_t target_id);
    bool add_domain(uint64_t guild_id, const std::string& domain);
    bool remove_domain(uint64_t guild_id, const std::string& domain);

    // Scheduled unbans
    void schedule_unban(uint64_t guild_id, uint64_t user_id, int64_t run_at);
    void cancel_unban(uint64_t guild_id, uint64_t user_id);
    std::vector<TempAction> due_unbans(int64_t now);
    void delete_temp_action(int64_t id);

    // Tickets
    TicketConfig get_ticket_config(uint64_t guild_id);
    // `column` must be category_id, staff_role_id, transcript_channel or appeals_channel.
    bool set_ticket_config(uint64_t guild_id, const std::string& column, uint64_t value);
    // Reserves the next ticket number. Call set_ticket_channel once the channel exists,
    // or delete_ticket if creating it failed.
    TicketRow create_ticket(uint64_t guild_id, uint64_t opener_id, const std::string& subject);
    void set_ticket_channel(int64_t ticket_id, uint64_t channel_id);
    void delete_ticket(int64_t ticket_id);
    std::optional<TicketRow> get_ticket_by_channel(uint64_t channel_id);
    int count_open_tickets(uint64_t guild_id, uint64_t user_id);
    void close_ticket(int64_t ticket_id);
    void set_ticket_claimed(int64_t ticket_id, uint64_t user_id);

    // Ban appeals
    int64_t add_appeal(uint64_t guild_id, uint64_t user_id, const std::string& text);
    void set_appeal_message(int64_t appeal_id, uint64_t channel_id, uint64_t message_id);
    std::optional<AppealRow> get_appeal(int64_t appeal_id);
    // Moves a pending appeal to `status`. False if it was already decided.
    bool decide_appeal(int64_t appeal_id, const std::string& status, uint64_t decided_by);
    bool has_pending_appeal(uint64_t guild_id, uint64_t user_id);
    int64_t last_denied_at(uint64_t guild_id, uint64_t user_id);

    // Event logging. `events` is a LogEvent bitmask.
    LogConfig get_log_config(uint64_t guild_id);
    void set_log_channel(uint64_t guild_id, uint64_t channel_id);
    void set_log_events(uint64_t guild_id, int events);

    // Role IDs change when a role is restored. This records the mapping and updates Flour's own
    // references (staff role, auto-mod exemptions) to the new ID.
    void role_remap(uint64_t guild_id, uint64_t old_id, uint64_t new_id);
    std::vector<std::pair<uint64_t, uint64_t>> role_remaps(uint64_t guild_id, int limit);  // (old, new), newest first

    // Anti-nuke
    NukeConfig get_nuke_config(uint64_t guild_id);
    // `column` must be one of the nuke columns; returns false otherwise.
    bool set_nuke_value(uint64_t guild_id, const std::string& column, int64_t value);
    bool add_nuke_trusted(uint64_t guild_id, uint64_t user_id);
    bool remove_nuke_trusted(uint64_t guild_id, uint64_t user_id);
    std::vector<uint64_t> nuke_trusted(uint64_t guild_id);

    // Undo archive: member roles per server, and deleted roles and channels.
    void archive_put(uint64_t guild_id, const std::string& kind, uint64_t id, uint64_t parent, const std::string& data);
    std::optional<std::string> archive_get(uint64_t guild_id, const std::string& kind, uint64_t id);
    void archive_delete(uint64_t guild_id, const std::string& kind, uint64_t id);
    std::vector<ArchiveRow> archive_members(uint64_t guild_id);
    std::vector<ArchiveRow> archive_rows(uint64_t guild_id, const std::string& kind);

    // Deleted roles and channels. Claimed rows are marked so two restores can't pick the same one.
    int64_t tombstone_add(uint64_t guild_id, const std::string& kind, uint64_t obj_id, const std::string& data);
    void tombstone_set_executor(uint64_t guild_id, uint64_t obj_id, uint64_t executor);
    std::vector<Tombstone> tombstones_claim(uint64_t guild_id, uint64_t executor);
    void tombstone_delete(int64_t id);
    void tombstones_purge(int64_t older_than);

    static const std::vector<std::string>& config_columns();

private:
    void exec(const char* sql);
    std::vector<FilterRow> read_filters(uint64_t guild_id);  // caller holds the mutex
    // Returns true if the column had to be added.
    bool ensure_column(const std::string& table, const std::string& column, const std::string& definition);
    sqlite3* db_ = nullptr;
    std::mutex mutex_;
    std::map<uint64_t, GuildConfig> config_cache_;
    std::map<uint64_t, std::shared_ptr<const AutomodLists>> lists_cache_;
    std::map<uint64_t, LogConfig> log_cache_;
    std::map<uint64_t, NukeConfig> nuke_cache_;
};

}  // namespace flour
