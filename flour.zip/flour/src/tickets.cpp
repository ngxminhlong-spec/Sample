#include <algorithm>
#include <ctime>
#include <memory>
#include <optional>

#include "app.hpp"
#include "util.hpp"

namespace flour {

namespace {

constexpr int kMaxOpenTickets = 1;
constexpr int64_t kAppealCooldown = 7 * 24 * 3600;
constexpr size_t kTranscriptLimit = 500;

constexpr uint64_t kMemberBits = dpp::p_view_channel | dpp::p_send_messages | dpp::p_read_message_history |
                                 dpp::p_attach_files | dpp::p_embed_links;

using SlashEvent = dpp::slashcommand_t;

dpp::message ephemeral(const std::string& text) {
    return dpp::message(text).set_flags(dpp::m_ephemeral);
}

std::string mention(uint64_t id) { return "<@" + std::to_string(id) + ">"; }
int64_t now_s() { return static_cast<int64_t>(time(nullptr)); }

std::string guild_name(uint64_t guild_id) {
    if (dpp::guild* g = dpp::find_guild(guild_id)) return g->name;
    return "the server";
}

dpp::component make_button(const std::string& label, const std::string& id, dpp::component_style style) {
    return dpp::component().set_label(label).set_type(dpp::cot_button).set_style(style).set_id(id);
}

dpp::message with_buttons(dpp::message m, const std::vector<dpp::component>& buttons) {
    dpp::component row;
    for (const auto& b : buttons) row.add_component(b);
    m.add_component(row);
    return m;
}

std::string ticket_channel_name(int64_t num) {
    std::string n = std::to_string(num);
    if (n.size() < 4) n = std::string(4 - n.size(), '0') + n;
    return "ticket-" + n;
}

std::optional<uint64_t> parse_tail(const std::string& id, const std::string& prefix) {
    if (id.rfind(prefix, 0) != 0) return std::nullopt;
    try {
        return std::stoull(id.substr(prefix.size()));
    } catch (...) {
        return std::nullopt;
    }
}

std::string form_value(const dpp::form_submit_t& e, size_t row) {
    if (row >= e.components.size() || e.components[row].components.empty()) return "";
    const auto& v = e.components[row].components[0].value;
    return std::holds_alternative<std::string>(v) ? std::get<std::string>(v) : "";
}

// Resolves the clicking/typing member's server permissions from the interaction.
dpp::permission member_permissions(const dpp::interaction& cmd) {
    dpp::guild* g = dpp::find_guild(cmd.guild_id);
    if (!g) return dpp::permission(0);
    dpp::guild_member m = cmd.member;
    m.user_id = cmd.usr.id;
    return g->base_permissions(m);
}

bool is_ticket_staff(const TicketConfig& tc, const dpp::interaction& cmd) {
    if (member_permissions(cmd).can(dpp::p_administrator)) return true;
    if (tc.staff_role_id == 0) return false;
    for (const dpp::snowflake& role : cmd.member.get_roles()) {
        if (role == dpp::snowflake(tc.staff_role_id)) return true;
    }
    return false;
}

std::string api_error(const dpp::confirmation_callback_t& cb) {
    const std::string m = cb.get_error().message;
    return m.empty() ? "Discord rejected the request." : m;
}

// ================================================================== transcripts

std::string stamp(time_t t) {
    std::tm tm{};
#ifdef _WIN32
    gmtime_s(&tm, &t);
#else
    gmtime_r(&t, &tm);
#endif
    char buf[32];
    std::strftime(buf, sizeof buf, "%Y-%m-%d %H:%M:%S", &tm);
    return buf;
}

std::string build_transcript(const TicketRow& t, std::vector<dpp::message> messages) {
    std::sort(messages.begin(), messages.end(),
              [](const dpp::message& a, const dpp::message& b) { return a.id < b.id; });

    std::string out = "Ticket #" + std::to_string(t.ticket_num) + " in " + guild_name(t.guild_id) + "\n";
    out += "Subject: " + t.subject + "\n";
    out += "Opened by: " + std::to_string(t.opener_id) + " at " + stamp(static_cast<time_t>(t.created_at)) + " UTC\n";
    out += "Messages: " + std::to_string(messages.size()) + "\n";
    out += "------------------------------------------------------------\n";

    for (const dpp::message& m : messages) {
        out += "[" + stamp(m.sent) + "] " + m.author.username + " (" + std::to_string(static_cast<uint64_t>(m.author.id)) + "): ";
        std::string body = m.content;
        size_t pos = 0;
        while ((pos = body.find('\n', pos)) != std::string::npos) {
            body.insert(pos + 1, "    ");
            pos += 5;
        }
        out += body + "\n";
        for (const auto& a : m.attachments) out += "    [attachment] " + a.url + "\n";
        for (const auto& em : m.embeds) {
            if (!em.title.empty()) out += "    [embed] " + em.title + "\n";
        }
    }
    return out;
}

using HistoryDone = std::function<void(std::vector<dpp::message>)>;

void fetch_history(App& app, dpp::snowflake channel, dpp::snowflake before,
                   std::shared_ptr<std::vector<dpp::message>> acc, HistoryDone done) {
    app.bot.messages_get(channel, 0, before, 0, 100,
        [&app, channel, acc, done](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) {
                done(*acc);
                return;
            }
            const auto page = std::get<dpp::message_map>(cb.value);
            if (page.empty()) {
                done(*acc);
                return;
            }
            dpp::snowflake oldest = page.begin()->first;
            for (const auto& entry : page) {
                if (entry.first < oldest) oldest = entry.first;
                acc->push_back(entry.second);
            }
            if (page.size() < 100 || acc->size() >= kTranscriptLimit) {
                done(*acc);
                return;
            }
            fetch_history(app, channel, oldest, acc, done);
        });
}

// Saves the transcript, tells the opener, logs it, then deletes the channel.
void close_ticket(App& app, const TicketRow& t, uint64_t closer, const std::string& reason) {
    app.db.close_ticket(t.id);

    auto acc = std::make_shared<std::vector<dpp::message>>();
    fetch_history(app, t.channel_id, 0, acc,
        [&app, t, closer, reason](std::vector<dpp::message> messages) {
            const std::string text = build_transcript(t, std::move(messages));
            const std::string file_name = ticket_channel_name(t.ticket_num) + ".txt";
            const std::string summary = "Transcript for ticket #" + std::to_string(t.ticket_num) +
                                        " (opened by " + mention(t.opener_id) + ", closed by " + mention(closer) + ")";

            const TicketConfig tc = app.db.get_ticket_config(t.guild_id);
            const uint64_t dest = tc.transcript_channel ? tc.transcript_channel
                                                        : app.db.get_config(t.guild_id).modlog_channel;
            if (dest != 0) {
                dpp::message m(dest, summary);
                m.add_file(file_name, text, "text/plain");
                app.bot.message_create(m);
            }

            dpp::message dm("Your ticket in **" + guild_name(t.guild_id) + "** was closed. Here is a copy of the conversation.");
            dm.add_file(file_name, text, "text/plain");
            app.bot.direct_message_create(t.opener_id, dm, [](const dpp::confirmation_callback_t&) {});

            std::string log = "Ticket #" + std::to_string(t.ticket_num) + " (" + truncate(t.subject, 100) + ") closed by " +
                              mention(closer);
            if (!reason.empty()) log += "\nReason: " + reason;
            if (t.claimed_by != 0) log += "\nClaimed by: " + mention(t.claimed_by);
            log_event(app, t.guild_id, "Ticket closed", log, color::neutral);

            // Give people a moment to see the closing notice, then remove the channel.
            const uint64_t channel = t.channel_id;
            app.bot.start_timer([&app, channel](dpp::timer handle) {
                app.bot.stop_timer(handle);
                app.bot.channel_delete(channel);
            }, 5);
        });
}

// ================================================================== tickets

dpp::message panel_message(dpp::snowflake channel) {
    dpp::embed e;
    e.set_color(color::info);
    e.set_title("Need help?");
    e.set_description("Press the button below to open a private ticket with the staff team.");

    dpp::message m(channel, "");
    m.add_embed(e);
    return with_buttons(m, {make_button("Open a ticket", "ticket:open", dpp::cos_primary)});
}

void show_ticket_modal(const dpp::interaction_create_t& e) {
    dpp::interaction_modal_response modal("ticket:submit", "Open a ticket");
    modal.add_component(dpp::component()
                            .set_label("Subject")
                            .set_id("subject")
                            .set_type(dpp::cot_text)
                            .set_placeholder("A few words on what this is about")
                            .set_min_length(3)
                            .set_max_length(100)
                            .set_text_style(dpp::text_short));
    modal.add_row();
    modal.add_component(dpp::component()
                            .set_label("Details")
                            .set_id("details")
                            .set_type(dpp::cot_text)
                            .set_placeholder("Tell us what's going on")
                            .set_min_length(10)
                            .set_max_length(1000)
                            .set_text_style(dpp::text_paragraph));
    e.dialog(modal);
}

void create_ticket(App& app, const dpp::form_submit_t& e) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t user = e.command.usr.id;
    const TicketConfig tc = app.db.get_ticket_config(gid);

    if (tc.category_id == 0) {
        e.reply(ephemeral("Tickets aren't set up in this server yet."));
        return;
    }
    if (app.db.count_open_tickets(gid, user) >= kMaxOpenTickets) {
        e.reply(ephemeral("You already have an open ticket. Please use that one."));
        return;
    }

    const std::string subject = truncate(form_value(e, 0), 100);
    const std::string details = truncate(form_value(e, 1), 1000);

    e.thinking(true);
    const TicketRow t = app.db.create_ticket(gid, user, subject);

    dpp::channel ch;
    ch.set_name(ticket_channel_name(t.ticket_num))
        .set_guild_id(gid)
        .set_parent_id(tc.category_id)
        .set_type(dpp::CHANNEL_TEXT)
        .set_topic(truncate(subject, 100));
    ch.add_permission_overwrite(gid, dpp::ot_role, 0, dpp::p_view_channel);
    ch.add_permission_overwrite(user, dpp::ot_member, kMemberBits, 0);
    if (tc.staff_role_id != 0) {
        ch.add_permission_overwrite(tc.staff_role_id, dpp::ot_role, kMemberBits | dpp::p_manage_messages, 0);
    }
    ch.add_permission_overwrite(app.bot.me.id, dpp::ot_member, kMemberBits | dpp::p_manage_channels, 0);

    app.bot.channel_create(ch,
        [&app, e, t, tc, user, subject, details](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) {
                app.db.delete_ticket(t.id);
                e.edit_response(ephemeral("Couldn't create your ticket channel: " + api_error(cb)));
                return;
            }
            const dpp::channel created = std::get<dpp::channel>(cb.value);
            app.db.set_ticket_channel(t.id, created.id);

            dpp::embed emb;
            emb.set_color(color::info);
            emb.set_title("Ticket #" + std::to_string(t.ticket_num));
            emb.add_field("Subject", subject, false);
            emb.add_field("Details", details, false);
            emb.add_field("Opened by", mention(user), true);

            std::string ping = mention(user);
            if (tc.staff_role_id != 0) ping += " <@&" + std::to_string(tc.staff_role_id) + ">";

            dpp::message opening(created.id, ping);
            opening.add_embed(emb);
            opening = with_buttons(opening, {make_button("Close", "ticket:close", dpp::cos_danger),
                                             make_button("Claim", "ticket:claim", dpp::cos_secondary)});
            app.bot.message_create(opening);

            e.edit_response(ephemeral("Your ticket is ready: <#" + std::to_string(static_cast<uint64_t>(created.id)) + ">"));
        });
}

void on_ticket_button(App& app, const dpp::button_click_t& e) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t user = e.command.usr.id;
    const std::string& id = e.custom_id;
    const TicketConfig tc = app.db.get_ticket_config(gid);

    if (id == "ticket:open") {
        if (tc.category_id == 0) {
            e.reply(ephemeral("Tickets aren't set up in this server yet."));
        } else if (app.db.count_open_tickets(gid, user) >= kMaxOpenTickets) {
            e.reply(ephemeral("You already have an open ticket. Please use that one."));
        } else {
            show_ticket_modal(e);
        }
        return;
    }

    auto ticket = app.db.get_ticket_by_channel(e.command.channel_id);
    if (!ticket || !ticket->open) {
        e.reply(ephemeral("This isn't an open ticket."));
        return;
    }
    const bool staff = is_ticket_staff(tc, e.command);
    const bool opener = ticket->opener_id == user;

    if (id == "ticket:close") {
        if (!staff && !opener) {
            e.reply(ephemeral("Only staff or the person who opened the ticket can close it."));
            return;
        }
        dpp::message confirm("Close this ticket? A transcript will be saved and the channel deleted.");
        confirm.set_flags(dpp::m_ephemeral);
        e.reply(with_buttons(confirm, {make_button("Yes, close it", "ticket:close_yes", dpp::cos_danger)}));
    } else if (id == "ticket:close_yes") {
        if (!staff && !opener) {
            e.reply(ephemeral("Only staff or the person who opened the ticket can close it."));
            return;
        }
        e.reply(dpp::message("Closing this ticket. Saving the transcript..."));
        close_ticket(app, *ticket, user, "");
    } else if (id == "ticket:claim") {
        if (!staff) {
            e.reply(ephemeral("Only staff can claim tickets."));
        } else if (ticket->claimed_by != 0 && ticket->claimed_by != user) {
            e.reply(ephemeral("Already claimed by " + mention(ticket->claimed_by) + "."));
        } else if (ticket->claimed_by == user) {
            e.reply(ephemeral("You've already claimed this ticket."));
        } else {
            app.db.set_ticket_claimed(ticket->id, user);
            e.reply(dpp::message(mention(user) + " claimed this ticket."));
        }
    }
}

// ================================================================== ban appeals

void open_appeal_modal(App& app, const dpp::button_click_t& e, uint64_t gid) {
    const uint64_t user = e.command.usr.id;
    if (app.db.get_ticket_config(gid).appeals_channel == 0) {
        e.reply(ephemeral("That server isn't taking ban appeals right now."));
        return;
    }
    if (app.db.has_pending_appeal(gid, user)) {
        e.reply(ephemeral("You already have an appeal waiting for review. You'll get a DM when it's decided."));
        return;
    }
    const int64_t denied = app.db.last_denied_at(gid, user);
    if (denied != 0 && now_s() < denied + kAppealCooldown) {
        e.reply(ephemeral("Your last appeal was denied. You can appeal again " +
                          discord_time(denied + kAppealCooldown, 'R') + "."));
        return;
    }

    dpp::interaction_modal_response modal("appeal:submit:" + std::to_string(gid), "Ban appeal");
    modal.add_component(dpp::component()
                            .set_label("Why should your ban be lifted?")
                            .set_id("appeal_text")
                            .set_type(dpp::cot_text)
                            .set_placeholder("Be honest and specific. Staff will read this.")
                            .set_min_length(20)
                            .set_max_length(1000)
                            .set_text_style(dpp::text_paragraph));
    e.dialog(modal);
}

void submit_appeal(App& app, const dpp::form_submit_t& e, uint64_t gid) {
    const uint64_t user = e.command.usr.id;
    const TicketConfig tc = app.db.get_ticket_config(gid);
    if (tc.appeals_channel == 0) {
        e.reply(ephemeral("That server isn't taking ban appeals right now."));
        return;
    }
    const std::string text = truncate(form_value(e, 0), 1000);

    e.thinking(false);
    app.bot.guild_get_ban(gid, user,
        [&app, e, gid, user, tc, text](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) {
                e.edit_response(ephemeral("I can't find an active ban for you in that server, so there's nothing to appeal."));
                return;
            }
            if (app.db.has_pending_appeal(gid, user)) {
                e.edit_response(ephemeral("You already have an appeal waiting for review."));
                return;
            }
            const dpp::ban ban = std::get<dpp::ban>(cb.value);
            const int64_t appeal_id = app.db.add_appeal(gid, user, text);

            dpp::embed emb;
            emb.set_color(color::info);
            emb.set_title("Ban appeal #" + std::to_string(appeal_id));
            emb.add_field("User", mention(user) + "\n`" + std::to_string(user) + "`", true);
            emb.add_field("Cases on record", std::to_string(app.db.count_cases(gid, user)), true);
            emb.add_field("Ban reason", ban.reason.empty() ? "No reason recorded" : truncate(ban.reason, 500), false);
            emb.add_field("Their appeal", text, false);
            emb.set_timestamp(now_s());

            dpp::message m(tc.appeals_channel, "");
            m.add_embed(emb);
            m = with_buttons(m, {make_button("Approve", "appeal:approve:" + std::to_string(appeal_id), dpp::cos_success),
                                 make_button("Deny", "appeal:deny:" + std::to_string(appeal_id), dpp::cos_danger)});

            app.bot.message_create(m,
                [&app, e, appeal_id, channel = tc.appeals_channel](const dpp::confirmation_callback_t& mcb) {
                    if (mcb.is_error()) {
                        app.db.decide_appeal(appeal_id, "failed", 0);
                        e.edit_response(ephemeral("I couldn't deliver your appeal to the staff team. Please try again later."));
                        return;
                    }
                    const dpp::message sent = std::get<dpp::message>(mcb.value);
                    app.db.set_appeal_message(appeal_id, channel, sent.id);
                    e.edit_response(ephemeral("Your appeal was sent. You'll get a DM when staff have made a decision."));
                });
        });
}

void decide_appeal_button(App& app, const dpp::button_click_t& e, int64_t appeal_id, bool approve) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t mod = e.command.usr.id;

    const dpp::permission perms = member_permissions(e.command);
    if (!perms.can(dpp::p_administrator) && !perms.can(dpp::p_ban_members)) {
        e.reply(ephemeral("You need the Ban Members permission to decide appeals."));
        return;
    }
    auto appeal = app.db.get_appeal(appeal_id);
    if (!appeal || appeal->guild_id != gid) {
        e.reply(ephemeral("I can't find that appeal."));
        return;
    }
    if (appeal->status != "pending") {
        e.reply(ephemeral("That appeal has already been decided."));
        return;
    }
    if (!app.db.decide_appeal(appeal_id, approve ? "approved" : "denied", mod)) {
        e.reply(ephemeral("Someone else just decided that appeal."));
        return;
    }

    e.reply(dpp::ir_deferred_update_message, "");

    const uint64_t user = appeal->user_id;
    auto finish = [&app, e, gid, mod, user, approve](const std::string& note) {
        dpp::message m = e.command.msg;
        m.components.clear();
        if (!m.embeds.empty()) {
            m.embeds[0].set_color(approve ? color::ok : color::danger);
            m.embeds[0].add_field(approve ? "Approved" : "Denied", "By " + mention(mod) + (note.empty() ? "" : "\n" + note), false);
        }
        e.edit_original_response(m);

        if (approve) {
            dm_then(app, user, "Good news: your ban appeal for **" + guild_name(gid) + "** was approved. You can rejoin the server.", []() {});
        } else {
            dm_then(app, user,
                    "Your ban appeal for **" + guild_name(gid) + "** was denied. You can appeal again " +
                        discord_time(now_s() + kAppealCooldown, 'R') + ".",
                    []() {});
        }
    };

    if (approve) {
        app.bot.guild_ban_delete(gid, user,
            [&app, gid, mod, user, finish](const dpp::confirmation_callback_t& cb) {
                // 10026 = Unknown Ban: they were already unbanned some other way, which is fine.
                if (cb.is_error() && cb.get_error().code != 10026) {
                    log_event(app, gid, "Appeal approved but unban failed",
                              "Could not unban " + mention(user) + ": " + api_error(cb) + "\nUse `/unban` manually.",
                              color::danger);
                    finish("The unban failed, so please use /unban manually: " + api_error(cb));
                    return;
                }
                app.db.cancel_unban(gid, user);
                record_case(app, gid, user, mod, "unban", "Ban appeal approved");
                finish("");
            });
    } else {
        record_case(app, gid, user, mod, "appeal_denied", "Ban appeal denied");
        finish("");
    }
}

// ================================================================== slash commands

void cmd_ticketconfig_set(App& app, const SlashEvent& e) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t category = opt_id(e, "category");
    const uint64_t role = opt_id(e, "staff_role");
    const uint64_t transcripts = opt_id(e, "transcripts");

    app.db.set_ticket_config(gid, "category_id", category);
    app.db.set_ticket_config(gid, "staff_role_id", role);
    if (transcripts != 0) app.db.set_ticket_config(gid, "transcript_channel", transcripts);

    std::string text = "Tickets will open under <#" + std::to_string(category) + "> and <@&" + std::to_string(role) +
                       "> can see them.";
    if (transcripts == 0 && app.db.get_config(gid).modlog_channel == 0) {
        text += "\nNo transcript channel is set and there's no mod log, so transcripts will only be DMed to the opener.";
    }
    text += "\nPost the button with `/ticketconfig panel`.";
    e.reply(ephemeral(text));
}

void cmd_ticketconfig_panel(App& app, const SlashEvent& e) {
    if (app.db.get_ticket_config(e.command.guild_id).category_id == 0) {
        return reply_error(e, "Run `/ticketconfig set` first so I know where tickets go.");
    }
    dpp::snowflake channel = opt_id(e, "channel");
    if (!channel) channel = e.command.channel_id;

    e.thinking(true);
    app.bot.message_create(panel_message(channel), [e](const dpp::confirmation_callback_t& cb) {
        if (cb.is_error()) {
            e.edit_response(ephemeral("I couldn't post there: " + api_error(cb)));
            return;
        }
        e.edit_response(ephemeral("Ticket panel posted."));
    });
}

void cmd_ticketconfig_appeals(App& app, const SlashEvent& e) {
    const uint64_t gid = e.command.guild_id;
    const dpp::snowflake channel = opt_id(e, "channel");

    if (!channel) {
        app.db.set_ticket_config(gid, "appeals_channel", 0);
        e.reply(ephemeral("Ban appeals are off. Banned users will no longer get an appeal button."));
        return;
    }
    e.thinking(true);
    app.bot.message_create(dpp::message(channel, "Ban appeals will be posted here for staff to approve or deny."),
        [&app, e, gid, channel](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) {
                e.edit_response(ephemeral("I can't send messages in that channel. Give me **View Channel**, "
                                          "**Send Messages** and **Embed Links** there, then try again."));
                return;
            }
            app.db.set_ticket_config(gid, "appeals_channel", channel);
            e.edit_response(ephemeral("Ban appeals are on. Users I ban from now on get an appeal button in their DM."));
        });
}

void cmd_ticketconfig_show(App& app, const SlashEvent& e) {
    const TicketConfig tc = app.db.get_ticket_config(e.command.guild_id);
    auto chan = [](uint64_t id) { return id ? "<#" + std::to_string(id) + ">" : std::string("not set"); };

    dpp::embed emb;
    emb.set_color(color::info);
    emb.set_title("Tickets and appeals");
    emb.add_field("Ticket category", chan(tc.category_id), true);
    emb.add_field("Staff role", tc.staff_role_id ? "<@&" + std::to_string(tc.staff_role_id) + ">" : "not set", true);
    emb.add_field("Transcripts", tc.transcript_channel ? chan(tc.transcript_channel) : "mod log channel", true);
    emb.add_field("Ban appeals", tc.appeals_channel ? chan(tc.appeals_channel) : "off", true);

    dpp::message m;
    m.add_embed(emb);
    m.set_flags(dpp::m_ephemeral);
    e.reply(m);
}

void cmd_ticket(App& app, const SlashEvent& e) {
    const std::string sub = subcommand_name(e);
    const uint64_t user = e.command.usr.id;
    const TicketConfig tc = app.db.get_ticket_config(e.command.guild_id);

    auto ticket = app.db.get_ticket_by_channel(e.command.channel_id);
    if (!ticket || !ticket->open) return reply_error(e, "Use this command inside an open ticket.");

    const bool staff = is_ticket_staff(tc, e.command);
    const bool opener = ticket->opener_id == user;

    if (sub == "close") {
        if (!staff && !opener) return reply_error(e, "Only staff or the person who opened the ticket can close it.");
        e.reply(dpp::message("Closing this ticket. Saving the transcript..."));
        close_ticket(app, *ticket, user, opt_str(e, "reason"));
        return;
    }

    if (!staff) return reply_error(e, "Only staff can do that.");
    const dpp::snowflake target = opt_id(e, "user");

    if (sub == "add") {
        e.thinking(false);
        app.bot.channel_edit_permissions(e.command.channel_id, target, kMemberBits, 0, true,
            [e, target](const dpp::confirmation_callback_t& cb) {
                if (cb.is_error()) {
                    e.edit_response(ephemeral("Couldn't add them: " + api_error(cb)));
                    return;
                }
                e.edit_response(dpp::message(mention(target) + " was added to the ticket."));
            });
    } else if (sub == "remove") {
        if (target == dpp::snowflake(ticket->opener_id)) return reply_error(e, "You can't remove the person who opened the ticket.");
        e.thinking(false);
        app.bot.channel_edit_permissions(e.command.channel_id, target, 0, dpp::p_view_channel, true,
            [e, target](const dpp::confirmation_callback_t& cb) {
                if (cb.is_error()) {
                    e.edit_response(ephemeral("Couldn't remove them: " + api_error(cb)));
                    return;
                }
                e.edit_response(dpp::message(mention(target) + " was removed from the ticket."));
            });
    }
}

}  // namespace

// ================================================================== public entry points

std::vector<dpp::slashcommand> build_ticket_commands(dpp::snowflake bot_id) {
    std::vector<dpp::slashcommand> cmds;

    // Visible to everyone: ticket owners need /ticket close. The handlers check who is allowed.
    dpp::slashcommand ticket("ticket", "Work with the ticket you're in", bot_id);
    ticket.set_interaction_contexts({dpp::itc_guild});
    ticket.add_option(dpp::command_option(dpp::co_sub_command, "close", "Close this ticket and save a transcript")
                          .add_option(dpp::command_option(dpp::co_string, "reason", "Why it's being closed", false)))
        .add_option(dpp::command_option(dpp::co_sub_command, "add", "Add someone to this ticket (staff)")
                        .add_option(dpp::command_option(dpp::co_user, "user", "Who to add", true)))
        .add_option(dpp::command_option(dpp::co_sub_command, "remove", "Remove someone from this ticket (staff)")
                        .add_option(dpp::command_option(dpp::co_user, "user", "Who to remove", true)));
    cmds.push_back(ticket);

    cmds.push_back(make_command("ticketconfig", "Set up tickets and ban appeals", bot_id, dpp::p_manage_guild)
        .add_option(dpp::command_option(dpp::co_sub_command, "set", "Choose where tickets open and who handles them")
            .add_option(dpp::command_option(dpp::co_channel, "category", "Category new tickets are created in", true)
                            .add_channel_type(dpp::CHANNEL_CATEGORY))
            .add_option(dpp::command_option(dpp::co_role, "staff_role", "Role that can see and manage tickets", true))
            .add_option(dpp::command_option(dpp::co_channel, "transcripts", "Where transcripts are posted (defaults to the mod log)", false)
                            .add_channel_type(dpp::CHANNEL_TEXT)))
        .add_option(dpp::command_option(dpp::co_sub_command, "panel", "Post the Open a ticket button")
            .add_option(dpp::command_option(dpp::co_channel, "channel", "Defaults to this channel", false)
                            .add_channel_type(dpp::CHANNEL_TEXT)))
        .add_option(dpp::command_option(dpp::co_sub_command, "appeals", "Turn ban appeals on by choosing a channel, or off by leaving it empty")
            .add_option(dpp::command_option(dpp::co_channel, "channel", "Where appeals are posted for staff", false)
                            .add_channel_type(dpp::CHANNEL_TEXT)))
        .add_option(dpp::command_option(dpp::co_sub_command, "show", "Show the current ticket settings")));

    return cmds;
}

bool handle_ticket_command(App& app, const dpp::slashcommand_t& e) {
    const std::string name = e.command.get_command_name();
    if (name == "ticket") {
        cmd_ticket(app, e);
        return true;
    }
    if (name == "ticketconfig") {
        const std::string sub = subcommand_name(e);
        if (sub == "set") cmd_ticketconfig_set(app, e);
        else if (sub == "panel") cmd_ticketconfig_panel(app, e);
        else if (sub == "appeals") cmd_ticketconfig_appeals(app, e);
        else if (sub == "show") cmd_ticketconfig_show(app, e);
        return true;
    }
    return false;
}

void handle_button(App& app, const dpp::button_click_t& e) {
    try {
        const std::string& id = e.custom_id;
        if (auto gid = parse_tail(id, "appeal:open:")) {
            open_appeal_modal(app, e, *gid);
        } else if (auto approve = parse_tail(id, "appeal:approve:")) {
            decide_appeal_button(app, e, static_cast<int64_t>(*approve), true);
        } else if (auto deny = parse_tail(id, "appeal:deny:")) {
            decide_appeal_button(app, e, static_cast<int64_t>(*deny), false);
        } else if (id.rfind("ticket:", 0) == 0 && e.command.guild_id != 0) {
            on_ticket_button(app, e);
        }
    } catch (const std::exception& ex) {
        app.bot.log(dpp::ll_error, std::string("button handler failed: ") + ex.what());
    }
}

void handle_form(App& app, const dpp::form_submit_t& e) {
    try {
        if (e.custom_id == "ticket:submit" && e.command.guild_id != 0) {
            create_ticket(app, e);
        } else if (auto gid = parse_tail(e.custom_id, "appeal:submit:")) {
            submit_appeal(app, e, *gid);
        }
    } catch (const std::exception& ex) {
        app.bot.log(dpp::ll_error, std::string("form handler failed: ") + ex.what());
    }
}

void ticket_on_channel_delete(App& app, uint64_t channel_id) {
    // A channel deleted by hand shouldn't leave its owner unable to open a new ticket.
    auto ticket = app.db.get_ticket_by_channel(channel_id);
    if (ticket && ticket->open) app.db.close_ticket(ticket->id);
}

}  // namespace flour
