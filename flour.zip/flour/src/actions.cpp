#include "app.hpp"
#include "util.hpp"

namespace flour {

namespace {

std::string guild_name(uint64_t guild_id) {
    if (dpp::guild* g = dpp::find_guild(guild_id)) return g->name;
    return "the server";
}

void report_failure(App& app, uint64_t guild_id, const std::string& what,
                    const dpp::confirmation_callback_t& cb) {
    log_event(app, guild_id, "Automated action failed",
              what + "\n" + cb.get_error().message, color::danger);
}

}  // namespace

void dm_then(App& app, uint64_t user_id, const std::string& text, std::function<void()> next,
             uint64_t appeal_guild) {
    dpp::message msg(text);
    if (appeal_guild != 0 && app.db.get_ticket_config(appeal_guild).appeals_channel != 0) {
        msg.add_component(dpp::component().add_component(
            dpp::component()
                .set_label("Appeal this ban")
                .set_type(dpp::cot_button)
                .set_style(dpp::cos_primary)
                .set_id("appeal:open:" + std::to_string(appeal_guild))));
    }
    app.bot.direct_message_create(user_id, msg, [next](const dpp::confirmation_callback_t&) { next(); });
}

void action_timeout(App& app, uint64_t guild_id, uint64_t user_id, uint64_t mod_id,
                    int64_t seconds, const std::string& reason) {
    const int64_t until = static_cast<int64_t>(time(nullptr)) + seconds;
    app.bot.guild_member_timeout(guild_id, user_id, static_cast<time_t>(until),
        [&app, guild_id, user_id, mod_id, until, reason](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) {
                report_failure(app, guild_id, "Could not time out <@" + std::to_string(user_id) + ">.", cb);
                return;
            }
            record_case(app, guild_id, user_id, mod_id, "timeout", reason, until);
        });
}

void action_ban(App& app, uint64_t guild_id, uint64_t user_id, uint64_t mod_id,
                const std::string& reason) {
    const std::string msg = "You were banned from **" + guild_name(guild_id) + "**.\nReason: " + reason;
    dm_then(app, user_id, msg, [&app, guild_id, user_id, mod_id, reason]() {
        app.bot.guild_ban_add(guild_id, user_id, 0,
            [&app, guild_id, user_id, mod_id, reason](const dpp::confirmation_callback_t& cb) {
                if (cb.is_error()) {
                    report_failure(app, guild_id, "Could not ban <@" + std::to_string(user_id) + ">.", cb);
                    return;
                }
                record_case(app, guild_id, user_id, mod_id, "ban", reason);
            });
    }, guild_id);
}

void action_kick(App& app, uint64_t guild_id, uint64_t user_id, uint64_t mod_id,
                 const std::string& reason, bool send_dm) {
    auto do_kick = [&app, guild_id, user_id, mod_id, reason]() {
        app.bot.guild_member_kick(guild_id, user_id,
            [&app, guild_id, user_id, mod_id, reason](const dpp::confirmation_callback_t& cb) {
                if (cb.is_error()) {
                    report_failure(app, guild_id, "Could not kick <@" + std::to_string(user_id) + ">.", cb);
                    return;
                }
                record_case(app, guild_id, user_id, mod_id, "kick", reason);
            });
    };
    if (!send_dm) {
        do_kick();
        return;
    }
    const std::string msg = "You were removed from **" + guild_name(guild_id) + "**.\nReason: " + reason;
    dm_then(app, user_id, msg, do_kick);
}

std::string action_warn(App& app, uint64_t guild_id, uint64_t user_id, uint64_t mod_id,
                        const std::string& reason, int* active_warns_out,
                        int64_t* case_num_out) {
    CaseRow warn_case = record_case(app, guild_id, user_id, mod_id, "warn", reason);
    if (case_num_out) *case_num_out = warn_case.case_num;

    const GuildConfig cfg = app.db.get_config(guild_id);
    const int warns = app.db.count_active_warns(guild_id, user_id);
    if (active_warns_out) *active_warns_out = warns;

    const uint64_t bot_id = app.bot.me.id;

    if (cfg.warn_ban_at > 0 && warns >= cfg.warn_ban_at) {
        action_ban(app, guild_id, user_id, bot_id,
                   "Reached " + std::to_string(warns) + " active warnings");
        return "Banned automatically (reached " + std::to_string(warns) + " active warnings).";
    }
    if (cfg.warn_timeout_at > 0 && warns == cfg.warn_timeout_at) {
        const int64_t secs = static_cast<int64_t>(cfg.warn_timeout_mins) * 60;
        action_timeout(app, guild_id, user_id, bot_id, secs,
                       "Reached " + std::to_string(warns) + " active warnings");
        return "Timed out automatically for " + format_duration(secs) + " (reached " +
               std::to_string(warns) + " active warnings).";
    }
    return "";
}

}  // namespace flour
