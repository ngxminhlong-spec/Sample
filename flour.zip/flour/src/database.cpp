#include "database.hpp"

#include <sqlite3.h>

#include <algorithm>
#include <ctime>
#include <stdexcept>

namespace flour {

namespace {

// Thin RAII wrapper so every early return still finalizes the statement.
class Stmt {
public:
    Stmt(sqlite3* db, const char* sql) : db_(db) {
        if (sqlite3_prepare_v2(db, sql, -1, &stmt_, nullptr) != SQLITE_OK) {
            throw std::runtime_error(std::string("sqlite prepare failed: ") + sqlite3_errmsg(db));
        }
    }
    ~Stmt() { sqlite3_finalize(stmt_); }
    Stmt(const Stmt&) = delete;
    Stmt& operator=(const Stmt&) = delete;

    Stmt& bind(int idx, int64_t v) { sqlite3_bind_int64(stmt_, idx, v); return *this; }
    Stmt& bind(int idx, uint64_t v) { sqlite3_bind_int64(stmt_, idx, static_cast<int64_t>(v)); return *this; }
    Stmt& bind(int idx, int v) { sqlite3_bind_int64(stmt_, idx, v); return *this; }
    Stmt& bind(int idx, const std::string& v) {
        sqlite3_bind_text(stmt_, idx, v.c_str(), static_cast<int>(v.size()), SQLITE_TRANSIENT);
        return *this;
    }

    // true while a row is available
    bool step() {
        int rc = sqlite3_step(stmt_);
        if (rc == SQLITE_ROW) return true;
        if (rc == SQLITE_DONE) return false;
        throw std::runtime_error(std::string("sqlite step failed: ") + sqlite3_errmsg(db_));
    }

    int64_t i64(int col) const { return sqlite3_column_int64(stmt_, col); }
    uint64_t u64(int col) const { return static_cast<uint64_t>(sqlite3_column_int64(stmt_, col)); }
    std::string text(int col) const {
        const unsigned char* t = sqlite3_column_text(stmt_, col);
        return t ? reinterpret_cast<const char*>(t) : "";
    }

private:
    sqlite3* db_;
    sqlite3_stmt* stmt_ = nullptr;
};

const char* kSchema = R"sql(
CREATE TABLE IF NOT EXISTS guild_config (
    guild_id             INTEGER PRIMARY KEY,
    modlog_channel       INTEGER NOT NULL DEFAULT 0,
    spam_action          INTEGER NOT NULL DEFAULT 0,
    dup_action           INTEGER NOT NULL DEFAULT 0,
    mention_action       INTEGER NOT NULL DEFAULT 0,
    invite_action        INTEGER NOT NULL DEFAULT 0,
    link_action          INTEGER NOT NULL DEFAULT 0,
    word_action          INTEGER NOT NULL DEFAULT 0,
    caps_action          INTEGER NOT NULL DEFAULT 0,
    emoji_action         INTEGER NOT NULL DEFAULT 0,
    spam_limit           INTEGER NOT NULL DEFAULT 6,
    spam_window          INTEGER NOT NULL DEFAULT 5,
    dup_limit            INTEGER NOT NULL DEFAULT 3,
    dup_window           INTEGER NOT NULL DEFAULT 30,
    mention_limit        INTEGER NOT NULL DEFAULT 5,
    caps_percent         INTEGER NOT NULL DEFAULT 70,
    caps_min_len         INTEGER NOT NULL DEFAULT 12,
    emoji_limit          INTEGER NOT NULL DEFAULT 10,
    automod_timeout_mins INTEGER NOT NULL DEFAULT 10,
    min_account_age      INTEGER NOT NULL DEFAULT 0,
    warn_timeout_at      INTEGER NOT NULL DEFAULT 3,
    warn_timeout_mins    INTEGER NOT NULL DEFAULT 60,
    warn_ban_at          INTEGER NOT NULL DEFAULT 5,
    heat_enabled         INTEGER NOT NULL DEFAULT 0,
    heat_warm            INTEGER NOT NULL DEFAULT 30,
    heat_hot             INTEGER NOT NULL DEFAULT 60,
    heat_critical        INTEGER NOT NULL DEFAULT 90,
    heat_decay           INTEGER NOT NULL DEFAULT 30
);

CREATE TABLE IF NOT EXISTS automod_exempt (
    guild_id  INTEGER NOT NULL,
    kind      TEXT    NOT NULL,
    target_id INTEGER NOT NULL,
    PRIMARY KEY (guild_id, kind, target_id)
);

CREATE TABLE IF NOT EXISTS allowed_domains (
    guild_id INTEGER NOT NULL,
    domain   TEXT    NOT NULL,
    PRIMARY KEY (guild_id, domain)
);

CREATE TABLE IF NOT EXISTS cases (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id   INTEGER NOT NULL,
    case_num   INTEGER NOT NULL,
    user_id    INTEGER NOT NULL,
    mod_id     INTEGER NOT NULL,
    action     TEXT    NOT NULL,
    reason     TEXT    NOT NULL,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL DEFAULT 0,
    active     INTEGER NOT NULL DEFAULT 1,
    UNIQUE (guild_id, case_num)
);
CREATE INDEX IF NOT EXISTS idx_cases_user ON cases (guild_id, user_id);

-- Audit trail: cases can never be deleted, and only `active` and `expires_at` may change.
CREATE TRIGGER IF NOT EXISTS cases_no_delete BEFORE DELETE ON cases
BEGIN
    SELECT RAISE(ABORT, 'cases are append-only');
END;
CREATE TRIGGER IF NOT EXISTS cases_immutable BEFORE UPDATE ON cases
WHEN NEW.id != OLD.id OR NEW.guild_id != OLD.guild_id OR NEW.case_num != OLD.case_num
  OR NEW.user_id != OLD.user_id OR NEW.mod_id != OLD.mod_id OR NEW.action != OLD.action
  OR NEW.reason != OLD.reason OR NEW.created_at != OLD.created_at
BEGIN
    SELECT RAISE(ABORT, 'cases are append-only');
END;

CREATE TABLE IF NOT EXISTS filters (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL,
    pattern  TEXT    NOT NULL,
    is_regex INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_filters_guild ON filters (guild_id);

CREATE TABLE IF NOT EXISTS ticket_config (
    guild_id           INTEGER PRIMARY KEY,
    category_id        INTEGER NOT NULL DEFAULT 0,
    staff_role_id      INTEGER NOT NULL DEFAULT 0,
    transcript_channel INTEGER NOT NULL DEFAULT 0,
    appeals_channel    INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS tickets (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id    INTEGER NOT NULL,
    ticket_num  INTEGER NOT NULL,
    channel_id  INTEGER NOT NULL DEFAULT 0,
    opener_id   INTEGER NOT NULL,
    subject     TEXT    NOT NULL,
    open        INTEGER NOT NULL DEFAULT 1,
    claimed_by  INTEGER NOT NULL DEFAULT 0,
    created_at  INTEGER NOT NULL,
    closed_at   INTEGER NOT NULL DEFAULT 0,
    UNIQUE (guild_id, ticket_num)
);
CREATE INDEX IF NOT EXISTS idx_tickets_channel ON tickets (channel_id);

CREATE TABLE IF NOT EXISTS appeals (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id   INTEGER NOT NULL,
    user_id    INTEGER NOT NULL,
    text       TEXT    NOT NULL,
    status     TEXT    NOT NULL DEFAULT 'pending',
    channel_id INTEGER NOT NULL DEFAULT 0,
    message_id INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    decided_by INTEGER NOT NULL DEFAULT 0,
    decided_at INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_appeals_user ON appeals (guild_id, user_id);

CREATE TABLE IF NOT EXISTS log_config (
    guild_id   INTEGER PRIMARY KEY,
    channel_id INTEGER NOT NULL DEFAULT 0,
    events     INTEGER NOT NULL DEFAULT 31
);

CREATE TABLE IF NOT EXISTS nuke_config (
    guild_id          INTEGER PRIMARY KEY,
    enabled           INTEGER NOT NULL DEFAULT 0,
    action            INTEGER NOT NULL DEFAULT 2,
    bans_limit        INTEGER NOT NULL DEFAULT 3,
    kicks_limit       INTEGER NOT NULL DEFAULT 3,
    channels_limit    INTEGER NOT NULL DEFAULT 3,
    roles_limit       INTEGER NOT NULL DEFAULT 3,
    admin_roles_limit INTEGER NOT NULL DEFAULT 1,
    webhooks_limit    INTEGER NOT NULL DEFAULT 3,
    window_secs       INTEGER NOT NULL DEFAULT 20
);

CREATE TABLE IF NOT EXISTS role_remaps (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL,
    old_id   INTEGER NOT NULL,
    new_id   INTEGER NOT NULL,
    at       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS nuke_trusted (
    guild_id INTEGER NOT NULL,
    user_id  INTEGER NOT NULL,
    PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS archive (
    guild_id INTEGER NOT NULL,
    kind     TEXT    NOT NULL,
    id       INTEGER NOT NULL,
    parent   INTEGER NOT NULL DEFAULT 0,
    data     TEXT    NOT NULL,
    PRIMARY KEY (guild_id, kind, id)
);
CREATE INDEX IF NOT EXISTS idx_archive_parent ON archive (guild_id, kind, parent);

CREATE TABLE IF NOT EXISTS tombstones (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id   INTEGER NOT NULL,
    kind       TEXT    NOT NULL,
    obj_id     INTEGER NOT NULL,
    data       TEXT    NOT NULL,
    executor   INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    state      INTEGER NOT NULL DEFAULT 0   -- 0 waiting, 1 claimed by a restore
);
CREATE INDEX IF NOT EXISTS idx_tombstones_exec ON tombstones (guild_id, executor, state);

CREATE TABLE IF NOT EXISTS temp_actions (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL,
    user_id  INTEGER NOT NULL,
    run_at   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_temp_run ON temp_actions (run_at);
)sql";

CaseRow read_case(const Stmt& s) {
    CaseRow c;
    c.id = s.i64(0);
    c.guild_id = s.u64(1);
    c.case_num = s.i64(2);
    c.user_id = s.u64(3);
    c.mod_id = s.u64(4);
    c.action = s.text(5);
    c.reason = s.text(6);
    c.created_at = s.i64(7);
    c.expires_at = s.i64(8);
    c.active = s.i64(9) != 0;
    return c;
}

const char* kCaseColumns =
    "id, guild_id, case_num, user_id, mod_id, action, reason, created_at, expires_at, active";

}  // namespace

const std::vector<std::string>& Database::config_columns() {
    static const std::vector<std::string> cols = {
        "spam_action", "dup_action", "mention_action", "invite_action", "link_action",
        "word_action", "caps_action", "emoji_action",
        "spam_limit", "spam_window", "dup_limit", "dup_window", "mention_limit",
        "caps_percent", "caps_min_len", "emoji_limit", "automod_timeout_mins",
        "min_account_age", "warn_timeout_at", "warn_timeout_mins", "warn_ban_at",
        "heat_enabled", "heat_warm", "heat_hot", "heat_critical", "heat_decay"};
    return cols;
}

Database::Database(const std::string& path) {
    if (sqlite3_open(path.c_str(), &db_) != SQLITE_OK) {
        std::string err = sqlite3_errmsg(db_);
        sqlite3_close(db_);
        throw std::runtime_error("cannot open database '" + path + "': " + err);
    }
    sqlite3_busy_timeout(db_, 5000);
    exec("PRAGMA journal_mode=WAL;");
    exec("PRAGMA synchronous=NORMAL;");
    exec(kSchema);

    // Databases from earlier versions get new columns added in place. The auto-mod actions
    // replace the old on/off switches, so existing servers keep whatever they had enabled.
    ensure_column("guild_config", "heat_enabled", "INTEGER NOT NULL DEFAULT 0");
    ensure_column("guild_config", "heat_warm", "INTEGER NOT NULL DEFAULT 30");
    ensure_column("guild_config", "heat_hot", "INTEGER NOT NULL DEFAULT 60");
    ensure_column("guild_config", "heat_critical", "INTEGER NOT NULL DEFAULT 90");
    ensure_column("guild_config", "heat_decay", "INTEGER NOT NULL DEFAULT 30");

    if (ensure_column("guild_config", "spam_action", "INTEGER NOT NULL DEFAULT 0"))
        exec("UPDATE guild_config SET spam_action = CASE WHEN spam_limit > 0 THEN 2 ELSE 0 END");
    if (ensure_column("guild_config", "mention_action", "INTEGER NOT NULL DEFAULT 0"))
        exec("UPDATE guild_config SET mention_action = CASE WHEN mention_limit > 0 THEN 2 ELSE 0 END");
    if (ensure_column("guild_config", "invite_action", "INTEGER NOT NULL DEFAULT 0"))
        exec("UPDATE guild_config SET invite_action = CASE WHEN block_invites != 0 THEN 2 ELSE 0 END");
    if (ensure_column("guild_config", "word_action", "INTEGER NOT NULL DEFAULT 0"))
        exec("UPDATE guild_config SET word_action = CASE WHEN word_filter != 0 THEN 2 ELSE 0 END");

    ensure_column("guild_config", "dup_action", "INTEGER NOT NULL DEFAULT 0");
    ensure_column("guild_config", "link_action", "INTEGER NOT NULL DEFAULT 0");
    ensure_column("guild_config", "caps_action", "INTEGER NOT NULL DEFAULT 0");
    ensure_column("guild_config", "emoji_action", "INTEGER NOT NULL DEFAULT 0");
    ensure_column("guild_config", "dup_limit", "INTEGER NOT NULL DEFAULT 3");
    ensure_column("guild_config", "dup_window", "INTEGER NOT NULL DEFAULT 30");
    ensure_column("guild_config", "caps_percent", "INTEGER NOT NULL DEFAULT 70");
    ensure_column("guild_config", "caps_min_len", "INTEGER NOT NULL DEFAULT 12");
    ensure_column("guild_config", "emoji_limit", "INTEGER NOT NULL DEFAULT 10");
    ensure_column("guild_config", "automod_timeout_mins", "INTEGER NOT NULL DEFAULT 10");
    ensure_column("nuke_config", "webhooks_limit", "INTEGER NOT NULL DEFAULT 3");
}

bool Database::ensure_column(const std::string& table, const std::string& column,
                             const std::string& definition) {
    bool found = false;
    {
        std::string pragma = "PRAGMA table_info(" + table + ")";
        Stmt s(db_, pragma.c_str());
        while (s.step()) {
            if (s.text(1) == column) found = true;
        }
    }
    if (found) return false;
    std::string sql = "ALTER TABLE " + table + " ADD COLUMN " + column + " " + definition;
    exec(sql.c_str());
    return true;
}

Database::~Database() { sqlite3_close(db_); }

void Database::exec(const char* sql) {
    char* err = nullptr;
    if (sqlite3_exec(db_, sql, nullptr, nullptr, &err) != SQLITE_OK) {
        std::string msg = err ? err : "unknown error";
        sqlite3_free(err);
        throw std::runtime_error("sqlite exec failed: " + msg);
    }
}

GuildConfig Database::get_config(uint64_t guild_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto cached = config_cache_.find(guild_id);
    if (cached != config_cache_.end()) return cached->second;

    Stmt s(db_,
           "SELECT modlog_channel, spam_action, dup_action, mention_action, invite_action, link_action, "
           "word_action, caps_action, emoji_action, spam_limit, spam_window, dup_limit, dup_window, "
           "mention_limit, caps_percent, caps_min_len, emoji_limit, automod_timeout_mins, "
           "min_account_age, warn_timeout_at, warn_timeout_mins, warn_ban_at, "
           "heat_enabled, heat_warm, heat_hot, heat_critical, heat_decay "
           "FROM guild_config WHERE guild_id = ?");
    s.bind(1, guild_id);

    GuildConfig c;
    c.guild_id = guild_id;
    if (s.step()) {
        int i = 0;
        auto next = [&]() { return static_cast<int>(s.i64(i++)); };
        c.modlog_channel = s.u64(i++);
        c.spam_action = next();
        c.dup_action = next();
        c.mention_action = next();
        c.invite_action = next();
        c.link_action = next();
        c.word_action = next();
        c.caps_action = next();
        c.emoji_action = next();
        c.spam_limit = next();
        c.spam_window = next();
        c.dup_limit = next();
        c.dup_window = next();
        c.mention_limit = next();
        c.caps_percent = next();
        c.caps_min_len = next();
        c.emoji_limit = next();
        c.automod_timeout_mins = next();
        c.min_account_age = next();
        c.warn_timeout_at = next();
        c.warn_timeout_mins = next();
        c.warn_ban_at = next();
        c.heat_enabled = next() != 0;
        c.heat_warm = next();
        c.heat_hot = next();
        c.heat_critical = next();
        c.heat_decay = next();
    }
    config_cache_[guild_id] = c;
    return c;
}

void Database::set_modlog_channel(uint64_t guild_id, uint64_t channel_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    config_cache_.erase(guild_id);
    Stmt(db_, "INSERT OR IGNORE INTO guild_config (guild_id) VALUES (?)").bind(1, guild_id).step();
    Stmt(db_, "UPDATE guild_config SET modlog_channel = ? WHERE guild_id = ?")
        .bind(1, channel_id).bind(2, guild_id).step();
}

bool Database::set_config_value(uint64_t guild_id, const std::string& column, int64_t value) {
    const auto& cols = config_columns();
    if (std::find(cols.begin(), cols.end(), column) == cols.end()) return false;

    std::lock_guard<std::mutex> lock(mutex_);
    config_cache_.erase(guild_id);
    Stmt(db_, "INSERT OR IGNORE INTO guild_config (guild_id) VALUES (?)").bind(1, guild_id).step();
    // `column` is checked against the whitelist above, so building the SQL here is safe.
    std::string sql = "UPDATE guild_config SET " + column + " = ? WHERE guild_id = ?";
    Stmt(db_, sql.c_str()).bind(1, value).bind(2, guild_id).step();
    return true;
}

CaseRow Database::add_case(uint64_t guild_id, uint64_t user_id, uint64_t mod_id,
                           const std::string& action, const std::string& reason,
                           int64_t expires_at, bool active) {
    std::lock_guard<std::mutex> lock(mutex_);

    int64_t next = 1;
    {
        Stmt s(db_, "SELECT COALESCE(MAX(case_num), 0) + 1 FROM cases WHERE guild_id = ?");
        s.bind(1, guild_id);
        if (s.step()) next = s.i64(0);
    }

    const int64_t now = static_cast<int64_t>(std::time(nullptr));
    Stmt(db_,
         "INSERT INTO cases (guild_id, case_num, user_id, mod_id, action, reason, created_at, "
         "expires_at, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")
        .bind(1, guild_id).bind(2, next).bind(3, user_id).bind(4, mod_id)
        .bind(5, action).bind(6, reason).bind(7, now).bind(8, expires_at)
        .bind(9, active ? 1 : 0).step();

    CaseRow c;
    c.id = sqlite3_last_insert_rowid(db_);
    c.case_num = next;
    c.guild_id = guild_id;
    c.user_id = user_id;
    c.mod_id = mod_id;
    c.action = action;
    c.reason = reason;
    c.created_at = now;
    c.expires_at = expires_at;
    c.active = active;
    return c;
}

std::optional<CaseRow> Database::get_case(uint64_t guild_id, int64_t case_num) {
    std::lock_guard<std::mutex> lock(mutex_);
    std::string sql = std::string("SELECT ") + kCaseColumns +
                      " FROM cases WHERE guild_id = ? AND case_num = ?";
    Stmt s(db_, sql.c_str());
    s.bind(1, guild_id).bind(2, case_num);
    if (s.step()) return read_case(s);
    return std::nullopt;
}

std::vector<CaseRow> Database::user_cases(uint64_t guild_id, uint64_t user_id, int limit, int offset) {
    std::lock_guard<std::mutex> lock(mutex_);
    std::string sql = std::string("SELECT ") + kCaseColumns +
                      " FROM cases WHERE guild_id = ? AND user_id = ? "
                      "ORDER BY case_num DESC LIMIT ? OFFSET ?";
    Stmt s(db_, sql.c_str());
    s.bind(1, guild_id).bind(2, user_id).bind(3, limit).bind(4, offset);

    std::vector<CaseRow> rows;
    while (s.step()) rows.push_back(read_case(s));
    return rows;
}

int Database::count_cases(uint64_t guild_id, uint64_t user_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt s(db_, "SELECT COUNT(*) FROM cases WHERE guild_id = ? AND user_id = ?");
    s.bind(1, guild_id).bind(2, user_id);
    return s.step() ? static_cast<int>(s.i64(0)) : 0;
}

int Database::count_active_warns(uint64_t guild_id, uint64_t user_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt s(db_,
           "SELECT COUNT(*) FROM cases WHERE guild_id = ? AND user_id = ? "
           "AND action = 'warn' AND active = 1");
    s.bind(1, guild_id).bind(2, user_id);
    return s.step() ? static_cast<int>(s.i64(0)) : 0;
}

bool Database::deactivate_case(uint64_t guild_id, int64_t case_num) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt s(db_, "UPDATE cases SET active = 0 WHERE guild_id = ? AND case_num = ? AND active = 1");
    s.bind(1, guild_id).bind(2, case_num).step();
    return sqlite3_changes(db_) > 0;
}

int64_t Database::add_filter(uint64_t guild_id, const std::string& pattern, bool is_regex) {
    std::lock_guard<std::mutex> lock(mutex_);
    lists_cache_.erase(guild_id);
    Stmt(db_, "INSERT INTO filters (guild_id, pattern, is_regex) VALUES (?, ?, ?)")
        .bind(1, guild_id).bind(2, pattern).bind(3, is_regex ? 1 : 0).step();
    return sqlite3_last_insert_rowid(db_);
}

bool Database::remove_filter(uint64_t guild_id, int64_t filter_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    lists_cache_.erase(guild_id);
    Stmt(db_, "DELETE FROM filters WHERE guild_id = ? AND id = ?")
        .bind(1, guild_id).bind(2, filter_id).step();
    return sqlite3_changes(db_) > 0;
}

std::vector<FilterRow> Database::list_filters(uint64_t guild_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    return read_filters(guild_id);
}

std::vector<FilterRow> Database::read_filters(uint64_t guild_id) {
    Stmt s(db_, "SELECT id, pattern, is_regex FROM filters WHERE guild_id = ? ORDER BY id");
    s.bind(1, guild_id);

    std::vector<FilterRow> rows;
    while (s.step()) {
        FilterRow f;
        f.id = s.i64(0);
        f.pattern = s.text(1);
        f.is_regex = s.i64(2) != 0;
        rows.push_back(std::move(f));
    }
    return rows;
}

void Database::schedule_unban(uint64_t guild_id, uint64_t user_id, int64_t run_at) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt(db_, "DELETE FROM temp_actions WHERE guild_id = ? AND user_id = ?")
        .bind(1, guild_id).bind(2, user_id).step();
    Stmt(db_, "INSERT INTO temp_actions (guild_id, user_id, run_at) VALUES (?, ?, ?)")
        .bind(1, guild_id).bind(2, user_id).bind(3, run_at).step();
}

void Database::cancel_unban(uint64_t guild_id, uint64_t user_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt(db_, "DELETE FROM temp_actions WHERE guild_id = ? AND user_id = ?")
        .bind(1, guild_id).bind(2, user_id).step();
}

std::vector<TempAction> Database::due_unbans(int64_t now) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt s(db_, "SELECT id, guild_id, user_id, run_at FROM temp_actions WHERE run_at <= ?");
    s.bind(1, now);

    std::vector<TempAction> rows;
    while (s.step()) {
        TempAction a;
        a.id = s.i64(0);
        a.guild_id = s.u64(1);
        a.user_id = s.u64(2);
        a.run_at = s.i64(3);
        rows.push_back(a);
    }
    return rows;
}

void Database::delete_temp_action(int64_t id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt(db_, "DELETE FROM temp_actions WHERE id = ?").bind(1, id).step();
}

TicketConfig Database::get_ticket_config(uint64_t guild_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt s(db_,
           "SELECT category_id, staff_role_id, transcript_channel, appeals_channel "
           "FROM ticket_config WHERE guild_id = ?");
    s.bind(1, guild_id);

    TicketConfig c;
    c.guild_id = guild_id;
    if (s.step()) {
        c.category_id = s.u64(0);
        c.staff_role_id = s.u64(1);
        c.transcript_channel = s.u64(2);
        c.appeals_channel = s.u64(3);
    }
    return c;
}

bool Database::set_ticket_config(uint64_t guild_id, const std::string& column, uint64_t value) {
    static const char* allowed[] = {"category_id", "staff_role_id", "transcript_channel", "appeals_channel"};
    if (std::find(std::begin(allowed), std::end(allowed), column) == std::end(allowed)) return false;

    std::lock_guard<std::mutex> lock(mutex_);
    Stmt(db_, "INSERT OR IGNORE INTO ticket_config (guild_id) VALUES (?)").bind(1, guild_id).step();
    // `column` is checked against the fixed list above.
    std::string sql = "UPDATE ticket_config SET " + column + " = ? WHERE guild_id = ?";
    Stmt(db_, sql.c_str()).bind(1, value).bind(2, guild_id).step();
    return true;
}

TicketRow Database::create_ticket(uint64_t guild_id, uint64_t opener_id, const std::string& subject) {
    std::lock_guard<std::mutex> lock(mutex_);

    int64_t next = 1;
    {
        Stmt s(db_, "SELECT COALESCE(MAX(ticket_num), 0) + 1 FROM tickets WHERE guild_id = ?");
        s.bind(1, guild_id);
        if (s.step()) next = s.i64(0);
    }
    const int64_t now = static_cast<int64_t>(std::time(nullptr));
    Stmt(db_, "INSERT INTO tickets (guild_id, ticket_num, opener_id, subject, created_at) VALUES (?, ?, ?, ?, ?)")
        .bind(1, guild_id).bind(2, next).bind(3, opener_id).bind(4, subject).bind(5, now).step();

    TicketRow t;
    t.id = sqlite3_last_insert_rowid(db_);
    t.ticket_num = next;
    t.guild_id = guild_id;
    t.opener_id = opener_id;
    t.subject = subject;
    t.created_at = now;
    return t;
}

void Database::set_ticket_channel(int64_t ticket_id, uint64_t channel_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt(db_, "UPDATE tickets SET channel_id = ? WHERE id = ?").bind(1, channel_id).bind(2, ticket_id).step();
}

void Database::delete_ticket(int64_t ticket_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt(db_, "DELETE FROM tickets WHERE id = ?").bind(1, ticket_id).step();
}

std::optional<TicketRow> Database::get_ticket_by_channel(uint64_t channel_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt s(db_,
           "SELECT id, ticket_num, guild_id, channel_id, opener_id, claimed_by, subject, open, created_at "
           "FROM tickets WHERE channel_id = ?");
    s.bind(1, channel_id);
    if (!s.step()) return std::nullopt;

    TicketRow t;
    t.id = s.i64(0);
    t.ticket_num = s.i64(1);
    t.guild_id = s.u64(2);
    t.channel_id = s.u64(3);
    t.opener_id = s.u64(4);
    t.claimed_by = s.u64(5);
    t.subject = s.text(6);
    t.open = s.i64(7) != 0;
    t.created_at = s.i64(8);
    return t;
}

int Database::count_open_tickets(uint64_t guild_id, uint64_t user_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt s(db_, "SELECT COUNT(*) FROM tickets WHERE guild_id = ? AND opener_id = ? AND open = 1");
    s.bind(1, guild_id).bind(2, user_id);
    return s.step() ? static_cast<int>(s.i64(0)) : 0;
}

void Database::close_ticket(int64_t ticket_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    const int64_t now = static_cast<int64_t>(std::time(nullptr));
    Stmt(db_, "UPDATE tickets SET open = 0, closed_at = ? WHERE id = ?").bind(1, now).bind(2, ticket_id).step();
}

void Database::set_ticket_claimed(int64_t ticket_id, uint64_t user_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt(db_, "UPDATE tickets SET claimed_by = ? WHERE id = ?").bind(1, user_id).bind(2, ticket_id).step();
}

int64_t Database::add_appeal(uint64_t guild_id, uint64_t user_id, const std::string& text) {
    std::lock_guard<std::mutex> lock(mutex_);
    const int64_t now = static_cast<int64_t>(std::time(nullptr));
    Stmt(db_, "INSERT INTO appeals (guild_id, user_id, text, created_at) VALUES (?, ?, ?, ?)")
        .bind(1, guild_id).bind(2, user_id).bind(3, text).bind(4, now).step();
    return sqlite3_last_insert_rowid(db_);
}

void Database::set_appeal_message(int64_t appeal_id, uint64_t channel_id, uint64_t message_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt(db_, "UPDATE appeals SET channel_id = ?, message_id = ? WHERE id = ?")
        .bind(1, channel_id).bind(2, message_id).bind(3, appeal_id).step();
}

std::optional<AppealRow> Database::get_appeal(int64_t appeal_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt s(db_,
           "SELECT id, guild_id, user_id, text, status, channel_id, message_id, created_at "
           "FROM appeals WHERE id = ?");
    s.bind(1, appeal_id);
    if (!s.step()) return std::nullopt;

    AppealRow a;
    a.id = s.i64(0);
    a.guild_id = s.u64(1);
    a.user_id = s.u64(2);
    a.text = s.text(3);
    a.status = s.text(4);
    a.channel_id = s.u64(5);
    a.message_id = s.u64(6);
    a.created_at = s.i64(7);
    return a;
}

bool Database::decide_appeal(int64_t appeal_id, const std::string& status, uint64_t decided_by) {
    std::lock_guard<std::mutex> lock(mutex_);
    const int64_t now = static_cast<int64_t>(std::time(nullptr));
    Stmt(db_, "UPDATE appeals SET status = ?, decided_by = ?, decided_at = ? WHERE id = ? AND status = 'pending'")
        .bind(1, status).bind(2, decided_by).bind(3, now).bind(4, appeal_id).step();
    return sqlite3_changes(db_) > 0;
}

bool Database::has_pending_appeal(uint64_t guild_id, uint64_t user_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt s(db_, "SELECT COUNT(*) FROM appeals WHERE guild_id = ? AND user_id = ? AND status = 'pending'");
    s.bind(1, guild_id).bind(2, user_id);
    return s.step() && s.i64(0) > 0;
}

int64_t Database::last_denied_at(uint64_t guild_id, uint64_t user_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt s(db_,
           "SELECT COALESCE(MAX(decided_at), 0) FROM appeals "
           "WHERE guild_id = ? AND user_id = ? AND status = 'denied'");
    s.bind(1, guild_id).bind(2, user_id);
    return s.step() ? s.i64(0) : 0;
}

std::shared_ptr<const AutomodLists> Database::get_automod_lists(uint64_t guild_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto cached = lists_cache_.find(guild_id);
    if (cached != lists_cache_.end()) return cached->second;

    auto lists = std::make_shared<AutomodLists>();
    {
        Stmt s(db_, "SELECT kind, target_id FROM automod_exempt WHERE guild_id = ?");
        s.bind(1, guild_id);
        while (s.step()) {
            if (s.text(0) == "role") lists->exempt_roles.push_back(s.u64(1));
            else if (s.text(0) == "channel") lists->exempt_channels.push_back(s.u64(1));
        }
    }
    {
        Stmt s(db_, "SELECT domain FROM allowed_domains WHERE guild_id = ? ORDER BY domain");
        s.bind(1, guild_id);
        while (s.step()) lists->allowed_domains.push_back(s.text(0));
    }
    lists->filters = read_filters(guild_id);

    lists_cache_[guild_id] = lists;
    return lists;
}

bool Database::add_exempt(uint64_t guild_id, const std::string& kind, uint64_t target_id) {
    if (kind != "role" && kind != "channel") return false;
    std::lock_guard<std::mutex> lock(mutex_);
    lists_cache_.erase(guild_id);
    Stmt(db_, "INSERT OR IGNORE INTO automod_exempt (guild_id, kind, target_id) VALUES (?, ?, ?)")
        .bind(1, guild_id).bind(2, kind).bind(3, target_id).step();
    return sqlite3_changes(db_) > 0;
}

bool Database::remove_exempt(uint64_t guild_id, const std::string& kind, uint64_t target_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    lists_cache_.erase(guild_id);
    Stmt(db_, "DELETE FROM automod_exempt WHERE guild_id = ? AND kind = ? AND target_id = ?")
        .bind(1, guild_id).bind(2, kind).bind(3, target_id).step();
    return sqlite3_changes(db_) > 0;
}

bool Database::add_domain(uint64_t guild_id, const std::string& domain) {
    std::lock_guard<std::mutex> lock(mutex_);
    lists_cache_.erase(guild_id);
    Stmt(db_, "INSERT OR IGNORE INTO allowed_domains (guild_id, domain) VALUES (?, ?)")
        .bind(1, guild_id).bind(2, domain).step();
    return sqlite3_changes(db_) > 0;
}

bool Database::remove_domain(uint64_t guild_id, const std::string& domain) {
    std::lock_guard<std::mutex> lock(mutex_);
    lists_cache_.erase(guild_id);
    Stmt(db_, "DELETE FROM allowed_domains WHERE guild_id = ? AND domain = ?")
        .bind(1, guild_id).bind(2, domain).step();
    return sqlite3_changes(db_) > 0;
}

LogConfig Database::get_log_config(uint64_t guild_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto cached = log_cache_.find(guild_id);
    if (cached != log_cache_.end()) return cached->second;

    LogConfig c;
    Stmt s(db_, "SELECT channel_id, events FROM log_config WHERE guild_id = ?");
    s.bind(1, guild_id);
    if (s.step()) {
        c.channel_id = s.u64(0);
        c.events = static_cast<int>(s.i64(1));
    }
    log_cache_[guild_id] = c;
    return c;
}

void Database::set_log_channel(uint64_t guild_id, uint64_t channel_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    log_cache_.erase(guild_id);
    Stmt(db_, "INSERT OR IGNORE INTO log_config (guild_id) VALUES (?)").bind(1, guild_id).step();
    Stmt(db_, "UPDATE log_config SET channel_id = ? WHERE guild_id = ?")
        .bind(1, channel_id).bind(2, guild_id).step();
}

void Database::set_log_events(uint64_t guild_id, int events) {
    std::lock_guard<std::mutex> lock(mutex_);
    log_cache_.erase(guild_id);
    Stmt(db_, "INSERT OR IGNORE INTO log_config (guild_id) VALUES (?)").bind(1, guild_id).step();
    Stmt(db_, "UPDATE log_config SET events = ? WHERE guild_id = ?")
        .bind(1, events).bind(2, guild_id).step();
}

NukeConfig Database::get_nuke_config(uint64_t guild_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto cached = nuke_cache_.find(guild_id);
    if (cached != nuke_cache_.end()) return cached->second;

    NukeConfig c;
    Stmt s(db_,
           "SELECT enabled, action, bans_limit, kicks_limit, channels_limit, roles_limit, "
           "admin_roles_limit, window_secs, webhooks_limit FROM nuke_config WHERE guild_id = ?");
    s.bind(1, guild_id);
    if (s.step()) {
        c.enabled = s.i64(0) != 0;
        c.action = static_cast<int>(s.i64(1));
        c.bans_limit = static_cast<int>(s.i64(2));
        c.kicks_limit = static_cast<int>(s.i64(3));
        c.channels_limit = static_cast<int>(s.i64(4));
        c.roles_limit = static_cast<int>(s.i64(5));
        c.admin_roles_limit = static_cast<int>(s.i64(6));
        c.window_secs = static_cast<int>(s.i64(7));
        c.webhooks_limit = static_cast<int>(s.i64(8));
    }
    nuke_cache_[guild_id] = c;
    return c;
}

bool Database::set_nuke_value(uint64_t guild_id, const std::string& column, int64_t value) {
    static const char* allowed[] = {"enabled", "action", "bans_limit", "kicks_limit", "channels_limit",
                                    "roles_limit", "admin_roles_limit", "webhooks_limit", "window_secs"};
    if (std::find(std::begin(allowed), std::end(allowed), column) == std::end(allowed)) return false;

    std::lock_guard<std::mutex> lock(mutex_);
    nuke_cache_.erase(guild_id);
    Stmt(db_, "INSERT OR IGNORE INTO nuke_config (guild_id) VALUES (?)").bind(1, guild_id).step();
    // `column` is checked against the fixed list above.
    std::string sql = "UPDATE nuke_config SET " + column + " = ? WHERE guild_id = ?";
    Stmt(db_, sql.c_str()).bind(1, value).bind(2, guild_id).step();
    return true;
}

bool Database::add_nuke_trusted(uint64_t guild_id, uint64_t user_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt(db_, "INSERT OR IGNORE INTO nuke_trusted (guild_id, user_id) VALUES (?, ?)")
        .bind(1, guild_id).bind(2, user_id).step();
    return sqlite3_changes(db_) > 0;
}

bool Database::remove_nuke_trusted(uint64_t guild_id, uint64_t user_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt(db_, "DELETE FROM nuke_trusted WHERE guild_id = ? AND user_id = ?")
        .bind(1, guild_id).bind(2, user_id).step();
    return sqlite3_changes(db_) > 0;
}

std::vector<uint64_t> Database::nuke_trusted(uint64_t guild_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt s(db_, "SELECT user_id FROM nuke_trusted WHERE guild_id = ? ORDER BY user_id");
    s.bind(1, guild_id);
    std::vector<uint64_t> out;
    while (s.step()) out.push_back(s.u64(0));
    return out;
}

void Database::archive_put(uint64_t guild_id, const std::string& kind, uint64_t id, uint64_t parent,
                           const std::string& data) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt(db_, "INSERT OR REPLACE INTO archive (guild_id, kind, id, parent, data) VALUES (?, ?, ?, ?, ?)")
        .bind(1, guild_id).bind(2, kind).bind(3, id).bind(4, parent).bind(5, data).step();
}

std::optional<std::string> Database::archive_get(uint64_t guild_id, const std::string& kind, uint64_t id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt s(db_, "SELECT data FROM archive WHERE guild_id = ? AND kind = ? AND id = ?");
    s.bind(1, guild_id).bind(2, kind).bind(3, id);
    if (!s.step()) return std::nullopt;
    return s.text(0);
}

void Database::archive_delete(uint64_t guild_id, const std::string& kind, uint64_t id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt(db_, "DELETE FROM archive WHERE guild_id = ? AND kind = ? AND id = ?")
        .bind(1, guild_id).bind(2, kind).bind(3, id).step();
}

std::vector<ArchiveRow> Database::archive_rows(uint64_t guild_id, const std::string& kind) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt s(db_, "SELECT id, parent, data FROM archive WHERE guild_id = ? AND kind = ?");
    s.bind(1, guild_id).bind(2, kind);
    std::vector<ArchiveRow> rows;
    while (s.step()) rows.push_back({s.u64(0), s.u64(1), s.text(2)});
    return rows;
}

std::vector<ArchiveRow> Database::archive_members(uint64_t guild_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt s(db_, "SELECT id, parent, data FROM archive WHERE guild_id = ? AND kind = 'member'");
    s.bind(1, guild_id);
    std::vector<ArchiveRow> rows;
    while (s.step()) rows.push_back({s.u64(0), s.u64(1), s.text(2)});
    return rows;
}

int64_t Database::tombstone_add(uint64_t guild_id, const std::string& kind, uint64_t obj_id, const std::string& data) {
    std::lock_guard<std::mutex> lock(mutex_);
    const int64_t now = static_cast<int64_t>(std::time(nullptr));
    Stmt(db_, "INSERT INTO tombstones (guild_id, kind, obj_id, data, created_at) VALUES (?, ?, ?, ?, ?)")
        .bind(1, guild_id).bind(2, kind).bind(3, obj_id).bind(4, data).bind(5, now).step();
    return sqlite3_last_insert_rowid(db_);
}

void Database::tombstone_set_executor(uint64_t guild_id, uint64_t obj_id, uint64_t executor) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt(db_, "UPDATE tombstones SET executor = ? WHERE guild_id = ? AND obj_id = ? AND executor = 0 AND state = 0")
        .bind(1, executor).bind(2, guild_id).bind(3, obj_id).step();
}

std::vector<Tombstone> Database::tombstones_claim(uint64_t guild_id, uint64_t executor) {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<Tombstone> rows;
    {
        Stmt s(db_, "SELECT id, guild_id, kind, obj_id, data, executor, created_at FROM tombstones "
                    "WHERE guild_id = ? AND executor = ? AND state = 0 ORDER BY id");
        s.bind(1, guild_id).bind(2, executor);
        while (s.step()) {
            Tombstone t;
            t.id = s.i64(0);
            t.guild_id = s.u64(1);
            t.kind = s.text(2);
            t.obj_id = s.u64(3);
            t.data = s.text(4);
            t.executor = s.u64(5);
            t.created_at = s.i64(6);
            rows.push_back(std::move(t));
        }
    }
    for (const Tombstone& t : rows) {
        Stmt(db_, "UPDATE tombstones SET state = 1 WHERE id = ?").bind(1, t.id).step();
    }
    return rows;
}

void Database::tombstone_delete(int64_t id) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt(db_, "DELETE FROM tombstones WHERE id = ?").bind(1, id).step();
}

void Database::tombstones_purge(int64_t older_than) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt(db_, "DELETE FROM tombstones WHERE created_at < ?").bind(1, older_than).step();
}

void Database::role_remap(uint64_t guild_id, uint64_t old_id, uint64_t new_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    const int64_t now = static_cast<int64_t>(std::time(nullptr));
    Stmt(db_, "INSERT INTO role_remaps (guild_id, old_id, new_id, at) VALUES (?, ?, ?, ?)")
        .bind(1, guild_id).bind(2, old_id).bind(3, new_id).bind(4, now).step();
    Stmt(db_, "UPDATE ticket_config SET staff_role_id = ? WHERE guild_id = ? AND staff_role_id = ?")
        .bind(1, new_id).bind(2, guild_id).bind(3, old_id).step();
    Stmt(db_, "UPDATE OR IGNORE automod_exempt SET target_id = ? WHERE guild_id = ? AND kind = 'role' AND target_id = ?")
        .bind(1, new_id).bind(2, guild_id).bind(3, old_id).step();
    // If the new ID was already exempt, the update was ignored and the old row is left over.
    Stmt(db_, "DELETE FROM automod_exempt WHERE guild_id = ? AND kind = 'role' AND target_id = ?")
        .bind(1, guild_id).bind(2, old_id).step();
    lists_cache_.erase(guild_id);
}

std::vector<std::pair<uint64_t, uint64_t>> Database::role_remaps(uint64_t guild_id, int limit) {
    std::lock_guard<std::mutex> lock(mutex_);
    Stmt s(db_, "SELECT old_id, new_id FROM role_remaps WHERE guild_id = ? ORDER BY id DESC LIMIT ?");
    s.bind(1, guild_id).bind(2, limit);
    std::vector<std::pair<uint64_t, uint64_t>> rows;
    while (s.step()) rows.emplace_back(s.u64(0), s.u64(1));
    return rows;
}

}  // namespace flour
