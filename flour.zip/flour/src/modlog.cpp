#include <algorithm>

#include "app.hpp"
#include "util.hpp"

namespace flour {

namespace {

uint32_t color_for(const std::string& action) {
    if (action == "ban" || action == "kick") return color::danger;
    if (action == "timeout" || action == "warn") return color::warn;
    if (action == "unban" || action == "untimeout" || action == "unwarn") return color::ok;
    return color::neutral;
}

std::string pretty(std::string action) {
    std::transform(action.begin(), action.end(), action.begin(),
                   [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
    return action;
}

}  // namespace

dpp::embed case_embed(const CaseRow& c) {
    dpp::embed e;
    e.set_color(color_for(c.action));
    e.set_title("Case #" + std::to_string(c.case_num) + " | " + pretty(c.action));
    e.add_field("User", "<@" + std::to_string(c.user_id) + ">\n`" + std::to_string(c.user_id) + "`", true);
    e.add_field("Moderator", "<@" + std::to_string(c.mod_id) + ">", true);
    if (c.expires_at > 0) {
        e.add_field("Expires", discord_time(c.expires_at, 'R'), true);
    }
    e.add_field("Reason", c.reason.empty() ? "No reason given" : truncate(c.reason, 1000), false);
    e.set_timestamp(c.created_at);
    return e;
}

CaseRow record_case(App& app, uint64_t guild_id, uint64_t user_id, uint64_t mod_id,
                    const std::string& action, const std::string& reason,
                    int64_t expires_at, bool active) {
    CaseRow row = app.db.add_case(guild_id, user_id, mod_id, action, reason, expires_at, active);

    GuildConfig cfg = app.db.get_config(guild_id);
    if (cfg.modlog_channel != 0) {
        app.bot.message_create(dpp::message(cfg.modlog_channel, case_embed(row)));
    }
    return row;
}

void log_event(App& app, uint64_t guild_id, const std::string& title,
               const std::string& description, uint32_t color) {
    GuildConfig cfg = app.db.get_config(guild_id);
    if (cfg.modlog_channel == 0) return;

    dpp::embed e;
    e.set_color(color);
    e.set_title(title);
    e.set_description(truncate(description, 4000));
    e.set_timestamp(time(nullptr));
    app.bot.message_create(dpp::message(cfg.modlog_channel, e));
}

}  // namespace flour
