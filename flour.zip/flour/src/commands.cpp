#include <algorithm>
#include <climits>

#include "app.hpp"
#include "util.hpp"

namespace flour {

namespace {

constexpr int64_t kMaxTimeoutSeconds = 28 * 24 * 3600;

using Event = dpp::slashcommand_t;

dpp::message ephemeral(const std::string& text) {
    return dpp::message(text).set_flags(dpp::m_ephemeral);
}

dpp::message embed_message(const dpp::embed& e) {
    dpp::message m;
    m.add_embed(e);
    return m;
}

std::string mention(uint64_t id) { return "<@" + std::to_string(id) + ">"; }
int64_t now_s() { return static_cast<int64_t>(time(nullptr)); }

std::string guild_name(uint64_t guild_id) {
    if (dpp::guild* g = dpp::find_guild(guild_id)) return g->name;
    return "the server";
}

int top_role_position(const dpp::guild& g, const dpp::guild_member& m) {
    if (g.owner_id == m.user_id) return INT_MAX;
    int best = 0;
    for (const dpp::snowflake& role_id : m.get_roles()) {
        if (const dpp::role* r = dpp::find_role(role_id)) best = std::max<int>(best, r->position);
    }
    return best;
}

// Returns an explanation if the invoker may not act on `target`, or "" if it's fine.
std::string check_target(App& app, const Event& e, dpp::snowflake target) {
    if (target == e.command.usr.id) return "You can't do that to yourself.";
    if (target == app.bot.me.id) return "I'm not going to do that to myself.";

    dpp::guild* g = dpp::find_guild(e.command.guild_id);
    if (!g) return "";
    if (target == g->owner_id) return "You can't moderate the server owner.";

    // Hierarchy only applies if the target is a member of the server.
    auto it = e.command.resolved.members.find(target);
    if (it == e.command.resolved.members.end()) return "";

    dpp::guild_member invoker = e.command.member;
    invoker.user_id = e.command.usr.id;
    if (top_role_position(*g, invoker) <= top_role_position(*g, it->second)) {
        return "You can't moderate someone whose top role is equal to or higher than yours.";
    }
    return "";
}

std::string api_error(const dpp::confirmation_callback_t& cb) {
    const std::string m = cb.get_error().message;
    return m.empty() ? "Discord rejected the request." : m;
}

dpp::embed result_embed(const std::string& title, const std::string& description, uint32_t color) {
    dpp::embed e;
    e.set_color(color);
    e.set_title(title);
    e.set_description(description);
    return e;
}

std::string reason_or_default(const Event& e) {
    std::string r = opt_str(e, "reason", "No reason given");
    return r.empty() ? "No reason given" : truncate(r, 500);
}

// ---------------------------------------------------------------- ban / unban

void cmd_ban(App& app, const Event& e) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t user = opt_id(e, "user");
    const uint64_t mod = e.command.usr.id;
    const std::string reason = reason_or_default(e);
    const int64_t delete_days = std::clamp<int64_t>(opt_int(e, "delete_days", 0), 0, 7);

    int64_t expires = 0;
    const std::string duration = opt_str(e, "duration");
    if (!duration.empty()) {
        auto secs = parse_duration(duration);
        if (!secs) return reply_error(e, "I couldn't read that duration. Try something like `7d` or `12h`.");
        expires = now_s() + *secs;
    }
    if (auto err = check_target(app, e, user); !err.empty()) return reply_error(e, err);

    e.thinking(false);

    std::string dm = "You were banned from **" + guild_name(gid) + "**.";
    if (expires) dm += " The ban lasts until " + discord_time(expires, 'F') + ".";
    dm += "\nReason: " + reason;

    dm_then(app, user, dm, [&app, e, gid, user, mod, reason, delete_days, expires]() {
        app.bot.guild_ban_add(gid, user, static_cast<uint32_t>(delete_days * 86400),
            [&app, e, gid, user, mod, reason, expires](const dpp::confirmation_callback_t& cb) {
                if (cb.is_error()) {
                    e.edit_response(ephemeral("Couldn't ban that user: " + api_error(cb)));
                    return;
                }
                CaseRow c = record_case(app, gid, user, mod, "ban", reason, expires);
                if (expires) app.db.schedule_unban(gid, user, expires);
                e.edit_response(embed_message(case_embed(c)));
            });
    }, gid);
}

void cmd_unban(App& app, const Event& e) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t user = opt_id(e, "user");
    const uint64_t mod = e.command.usr.id;
    const std::string reason = reason_or_default(e);

    e.thinking(false);
    app.bot.guild_ban_delete(gid, user,
        [&app, e, gid, user, mod, reason](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) {
                e.edit_response(ephemeral("Couldn't unban that user (are they actually banned?): " + api_error(cb)));
                return;
            }
            app.db.cancel_unban(gid, user);
            CaseRow c = record_case(app, gid, user, mod, "unban", reason);
            e.edit_response(embed_message(case_embed(c)));
        });
}

// ---------------------------------------------------------------- kick

void cmd_kick(App& app, const Event& e) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t user = opt_id(e, "user");
    const uint64_t mod = e.command.usr.id;
    const std::string reason = reason_or_default(e);
    if (auto err = check_target(app, e, user); !err.empty()) return reply_error(e, err);

    e.thinking(false);
    const std::string dm = "You were kicked from **" + guild_name(gid) + "**.\nReason: " + reason;
    dm_then(app, user, dm, [&app, e, gid, user, mod, reason]() {
        app.bot.guild_member_kick(gid, user,
            [&app, e, gid, user, mod, reason](const dpp::confirmation_callback_t& cb) {
                if (cb.is_error()) {
                    e.edit_response(ephemeral("Couldn't kick that user: " + api_error(cb)));
                    return;
                }
                CaseRow c = record_case(app, gid, user, mod, "kick", reason);
                e.edit_response(embed_message(case_embed(c)));
            });
    });
}

// ---------------------------------------------------------------- timeout

void cmd_timeout(App& app, const Event& e) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t user = opt_id(e, "user");
    const uint64_t mod = e.command.usr.id;
    const std::string reason = reason_or_default(e);

    auto secs = parse_duration(opt_str(e, "duration"));
    if (!secs) return reply_error(e, "I couldn't read that duration. Try `10m`, `2h` or `1d12h`.");
    if (*secs > kMaxTimeoutSeconds) return reply_error(e, "Discord caps timeouts at 28 days.");
    if (auto err = check_target(app, e, user); !err.empty()) return reply_error(e, err);

    const int64_t until = now_s() + *secs;
    e.thinking(false);
    app.bot.guild_member_timeout(gid, user, static_cast<time_t>(until),
        [&app, e, gid, user, mod, reason, until](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) {
                e.edit_response(ephemeral("Couldn't time out that user (are they in the server?): " + api_error(cb)));
                return;
            }
            CaseRow c = record_case(app, gid, user, mod, "timeout", reason, until);
            dm_then(app, user, "You were timed out in **" + guild_name(gid) + "** until " +
                                   discord_time(until, 'F') + ".\nReason: " + reason, []() {});
            e.edit_response(embed_message(case_embed(c)));
        });
}

void cmd_untimeout(App& app, const Event& e) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t user = opt_id(e, "user");
    const uint64_t mod = e.command.usr.id;
    const std::string reason = reason_or_default(e);

    e.thinking(false);
    app.bot.guild_member_timeout_remove(gid, user,
        [&app, e, gid, user, mod, reason](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) {
                e.edit_response(ephemeral("Couldn't remove that timeout: " + api_error(cb)));
                return;
            }
            CaseRow c = record_case(app, gid, user, mod, "untimeout", reason);
            e.edit_response(embed_message(case_embed(c)));
        });
}

// ---------------------------------------------------------------- warn / unwarn

void cmd_warn(App& app, const Event& e) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t user = opt_id(e, "user");
    const uint64_t mod = e.command.usr.id;
    const std::string reason = reason_or_default(e);
    if (auto err = check_target(app, e, user); !err.empty()) return reply_error(e, err);

    e.thinking(false);

    int warns = 0;
    int64_t case_num = 0;
    const std::string escalation = action_warn(app, gid, user, mod, reason, &warns, &case_num);

    dm_then(app, user, "You were warned in **" + guild_name(gid) + "**.\nReason: " + reason, []() {});

    std::string text = mention(user) + " now has **" + std::to_string(warns) + "** active warning(s).";
    if (!escalation.empty()) text += "\n" + escalation;

    dpp::embed emb = result_embed("Case #" + std::to_string(case_num) + " | WARN", text, color::warn);
    emb.add_field("Reason", reason, false);
    emb.add_field("Moderator", mention(mod), true);
    e.edit_response(embed_message(emb));
}

void cmd_unwarn(App& app, const Event& e) {
    const uint64_t gid = e.command.guild_id;
    const int64_t num = opt_int(e, "case");
    const uint64_t mod = e.command.usr.id;
    const std::string reason = reason_or_default(e);

    auto target = app.db.get_case(gid, num);
    if (!target) return reply_error(e, "There's no case #" + std::to_string(num) + " in this server.");
    if (target->action != "warn") return reply_error(e, "Case #" + std::to_string(num) + " isn't a warning.");
    if (!app.db.deactivate_case(gid, num)) return reply_error(e, "That warning has already been removed.");

    CaseRow c = record_case(app, gid, target->user_id, mod, "unwarn",
                            "Removed warning #" + std::to_string(num) + ": " + reason);
    e.reply(embed_message(case_embed(c)));
}

// ---------------------------------------------------------------- history / case

void cmd_history(App& app, const Event& e) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t user = opt_id(e, "user");
    constexpr int kPerPage = 8;

    const int total = app.db.count_cases(gid, user);
    const int pages = std::max(1, (total + kPerPage - 1) / kPerPage);
    const int page = static_cast<int>(std::clamp<int64_t>(opt_int(e, "page", 1), 1, pages));

    std::string body;
    for (const CaseRow& c : app.db.user_cases(gid, user, kPerPage, (page - 1) * kPerPage)) {
        std::string action = c.action;
        std::transform(action.begin(), action.end(), action.begin(),
                       [](unsigned char ch) { return static_cast<char>(std::toupper(ch)); });
        body += "**#" + std::to_string(c.case_num) + "** `" + action + "`";
        if (c.action == "warn" && !c.active) body += " (removed)";
        body += " " + discord_time(c.created_at, 'R') + "\n" + truncate(c.reason, 120) + "\n\n";
    }
    if (body.empty()) body = "No cases on record.";

    dpp::embed emb = result_embed("History for " + mention(user), body, color::info);
    emb.set_footer(dpp::embed_footer().set_text(
        std::to_string(total) + " case(s) | " + std::to_string(app.db.count_active_warns(gid, user)) +
        " active warning(s) | page " + std::to_string(page) + "/" + std::to_string(pages)));
    e.reply(embed_message(emb));
}

void cmd_case(App& app, const Event& e) {
    const int64_t num = opt_int(e, "number");
    auto c = app.db.get_case(e.command.guild_id, num);
    if (!c) return reply_error(e, "There's no case #" + std::to_string(num) + " in this server.");

    dpp::embed emb = case_embed(*c);
    if (c->action == "warn") emb.add_field("Status", c->active ? "Active" : "Removed", true);
    e.reply(embed_message(emb));
}

// ---------------------------------------------------------------- purge

void cmd_purge(App& app, const Event& e) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t channel = e.command.channel_id;
    const uint64_t mod = e.command.usr.id;
    const int64_t amount = std::clamp<int64_t>(opt_int(e, "amount", 10), 1, 100);
    const uint64_t only_user = opt_id(e, "user");

    // The "thinking" placeholder is ephemeral, so it can't be swept up by the purge itself.
    e.thinking(true);

    const uint64_t fetch = only_user ? 100 : static_cast<uint64_t>(amount);
    app.bot.messages_get(channel, 0, 0, 0, fetch,
        [&app, e, gid, channel, mod, amount, only_user](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) {
                e.edit_response(ephemeral("Couldn't read the channel history: " + api_error(cb)));
                return;
            }
            const auto fetched = std::get<dpp::message_map>(cb.value);
            const double cutoff = static_cast<double>(now_s()) - 14.0 * 86400.0 + 120.0;

            std::vector<dpp::snowflake> ids;
            for (const auto& entry : fetched) {
                const dpp::message& m = entry.second;
                if (only_user && m.author.id != only_user) continue;
                if (m.pinned) continue;
                if (m.id.get_creation_time() < cutoff) continue;  // bulk delete rejects old messages
                ids.push_back(m.id);
            }
            std::sort(ids.begin(), ids.end(), std::greater<dpp::snowflake>());
            if (ids.size() > static_cast<size_t>(amount)) ids.resize(static_cast<size_t>(amount));

            if (ids.empty()) {
                e.edit_response(ephemeral("Nothing to delete. Messages older than 14 days and pinned messages are skipped."));
                return;
            }

            const size_t count = ids.size();
            auto done = [&app, e, gid, channel, mod, count, only_user](const dpp::confirmation_callback_t& dcb) {
                if (dcb.is_error()) {
                    e.edit_response(ephemeral("Couldn't delete those messages: " + api_error(dcb)));
                    return;
                }
                std::string what = mention(mod) + " deleted " + std::to_string(count) + " message(s) in <#" +
                                   std::to_string(channel) + ">";
                if (only_user) what += " from " + mention(only_user);
                log_event(app, gid, "Messages purged", what, color::neutral);
                e.edit_response(ephemeral("Deleted " + std::to_string(count) + " message(s)."));
            };
            if (count == 1) {
                app.bot.message_delete(ids[0], channel, done);
            } else {
                app.bot.message_delete_bulk(ids, channel, done);
            }
        });
}

// ---------------------------------------------------------------- slowmode / lock

dpp::snowflake channel_option_or_current(const Event& e) {
    dpp::snowflake ch = opt_id(e, "channel");
    return ch ? ch : dpp::snowflake(e.command.channel_id);
}

void cmd_slowmode(App& app, const Event& e) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t mod = e.command.usr.id;
    const int64_t secs = std::clamp<int64_t>(opt_int(e, "seconds"), 0, 21600);
    const dpp::snowflake channel_id = channel_option_or_current(e);

    e.thinking(true);
    app.bot.channel_get(channel_id,
        [&app, e, gid, mod, secs, channel_id](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) {
                e.edit_response(ephemeral("Couldn't find that channel: " + api_error(cb)));
                return;
            }
            dpp::channel ch = std::get<dpp::channel>(cb.value);
            ch.set_rate_limit_per_user(static_cast<uint16_t>(secs));
            app.bot.channel_edit(ch, [&app, e, gid, mod, secs, channel_id](const dpp::confirmation_callback_t& ecb) {
                if (ecb.is_error()) {
                    e.edit_response(ephemeral("Couldn't change the slowmode: " + api_error(ecb)));
                    return;
                }
                const std::string chan = "<#" + std::to_string(static_cast<uint64_t>(channel_id)) + ">";
                const std::string state = secs == 0 ? "off" : format_duration(secs);
                log_event(app, gid, "Slowmode changed", mention(mod) + " set slowmode in " + chan + " to " + state,
                          color::neutral);
                e.edit_response(ephemeral("Slowmode in " + chan + " is now " + state + "."));
            });
        });
}

constexpr uint64_t kLockBits = dpp::p_send_messages | dpp::p_add_reactions |
                               dpp::p_create_public_threads | dpp::p_create_private_threads |
                               dpp::p_send_messages_in_threads;

void set_lock(App& app, const Event& e, bool lock) {
    const uint64_t gid = e.command.guild_id;
    const uint64_t mod = e.command.usr.id;
    const dpp::snowflake channel_id = channel_option_or_current(e);
    const std::string reason = reason_or_default(e);

    e.thinking(true);
    app.bot.channel_get(channel_id,
        [&app, e, gid, mod, lock, channel_id, reason](const dpp::confirmation_callback_t& cb) {
            if (cb.is_error()) {
                e.edit_response(ephemeral("Couldn't find that channel: " + api_error(cb)));
                return;
            }
            const dpp::channel ch = std::get<dpp::channel>(cb.value);

            // @everyone's role id is the guild id. Keep whatever overwrite is already there.
            uint64_t allow = 0, deny = 0;
            for (const auto& ow : ch.permission_overwrites) {
                if (ow.id == dpp::snowflake(gid) && ow.type == dpp::ot_role) {
                    allow = ow.allow;
                    deny = ow.deny;
                }
            }
            if (lock) {
                allow &= ~kLockBits;
                deny |= kLockBits;
            } else {
                deny &= ~kLockBits;
            }

            app.bot.channel_edit_permissions(ch.id, dpp::snowflake(gid), allow, deny, false,
                [&app, e, gid, mod, lock, channel_id, reason](const dpp::confirmation_callback_t& pcb) {
                    if (pcb.is_error()) {
                        e.edit_response(ephemeral("Couldn't change the permissions: " + api_error(pcb)));
                        return;
                    }
                    const std::string chan = "<#" + std::to_string(static_cast<uint64_t>(channel_id)) + ">";
                    log_event(app, gid, lock ? "Channel locked" : "Channel unlocked",
                              mention(mod) + (lock ? " locked " : " unlocked ") + chan + "\nReason: " + reason,
                              lock ? color::warn : color::ok);
                    e.edit_response(ephemeral(chan + (lock ? " is now locked." : " is now unlocked.")));
                });
        });
}

// ---------------------------------------------------------------- heat

void cmd_heat(App& app, const Event& e) {
    const uint64_t gid = e.command.guild_id;
    const std::string sub = subcommand_name(e);
    const GuildConfig cfg = app.db.get_config(gid);

    if (sub == "reset") {
        const HeatReading before = heat_peek(app, gid);
        heat_reset(app, gid);
        log_event(app, gid, "Heat reset",
                  mention(e.command.usr.id) + " reset the heat from " +
                      std::to_string(static_cast<int>(before.heat + 0.5)) + " to 0.",
                  color::ok);
        e.reply(ephemeral("Heat reset. Restrictions are lifted."));
        return;
    }

    if (!cfg.heat_enabled) {
        e.reply(ephemeral("The heat system is off. Turn it on with `/config set setting:heat_enabled value:1`."));
        return;
    }

    const HeatReading r = heat_peek(app, gid);
    dpp::embed emb;
    emb.set_title("Server heat");
    emb.set_color(r.level == heat_critical ? color::danger : r.level == heat_hot ? 0xE67E22
                  : r.level == heat_warm ? color::warn : color::ok);
    emb.set_description("`" + heat_bar(r.heat, cfg.heat_critical) + "` **" +
                        std::to_string(static_cast<int>(r.heat + 0.5)) + "** / " +
                        std::to_string(cfg.heat_critical) + "\nLevel: **" + heat_level_name(r.level) + "**");
    emb.add_field("Warm at", std::to_string(cfg.heat_warm), true);
    emb.add_field("Hot at", std::to_string(cfg.heat_hot), true);
    emb.add_field("Critical at", std::to_string(cfg.heat_critical), true);
    emb.add_field("Cooling", std::to_string(cfg.heat_decay) + " per minute", true);

    dpp::message m;
    m.add_embed(emb);
    m.set_flags(dpp::m_ephemeral);
    e.reply(m);
}

}  // namespace

// ============================================================================ shared helpers

void reply_error(const Event& event, const std::string& text) { event.reply(ephemeral(text)); }

dpp::command_value find_option_value(const Event& event, const std::string& name) {
    const dpp::command_interaction ci = event.command.get_command_interaction();
    std::vector<const std::vector<dpp::command_data_option>*> stack{&ci.options};
    while (!stack.empty()) {
        const auto* opts = stack.back();
        stack.pop_back();
        for (const auto& o : *opts) {
            if (o.name == name) return o.value;
            if (o.type == dpp::co_sub_command || o.type == dpp::co_sub_command_group) {
                stack.push_back(&o.options);
            }
        }
    }
    return {};
}

std::string opt_str(const Event& event, const std::string& name, const std::string& def) {
    auto v = find_option_value(event, name);
    if (std::holds_alternative<std::string>(v)) return std::get<std::string>(v);
    return def;
}

int64_t opt_int(const Event& event, const std::string& name, int64_t def) {
    auto v = find_option_value(event, name);
    if (std::holds_alternative<int64_t>(v)) return std::get<int64_t>(v);
    return def;
}

bool opt_bool(const Event& event, const std::string& name, bool def) {
    auto v = find_option_value(event, name);
    if (std::holds_alternative<bool>(v)) return std::get<bool>(v);
    return def;
}

dpp::snowflake opt_id(const Event& event, const std::string& name) {
    auto v = find_option_value(event, name);
    if (std::holds_alternative<dpp::snowflake>(v)) return std::get<dpp::snowflake>(v);
    return dpp::snowflake(0);
}

std::string subcommand_name(const Event& event) {
    const dpp::command_interaction ci = event.command.get_command_interaction();
    if (!ci.options.empty() && ci.options[0].type == dpp::co_sub_command) return ci.options[0].name;
    return "";
}

dpp::slashcommand make_command(const std::string& name, const std::string& description,
                               dpp::snowflake bot_id, uint64_t default_permissions) {
    dpp::slashcommand cmd(name, description, bot_id);
    cmd.set_default_permissions(default_permissions);
    cmd.set_interaction_contexts({dpp::itc_guild});
    return cmd;
}

// ============================================================================ registration

namespace {

dpp::command_option user_opt(const std::string& desc = "The member") {
    return dpp::command_option(dpp::co_user, "user", desc, true);
}
dpp::command_option reason_opt() {
    return dpp::command_option(dpp::co_string, "reason", "Why (shown in the mod log)", false);
}

}  // namespace

std::vector<dpp::slashcommand> build_commands(dpp::snowflake bot_id) {
    std::vector<dpp::slashcommand> cmds;

    cmds.push_back(make_command("ban", "Ban a user, optionally for a limited time", bot_id, dpp::p_ban_members)
        .add_option(user_opt("The user to ban"))
        .add_option(reason_opt())
        .add_option(dpp::command_option(dpp::co_string, "duration", "e.g. 7d or 12h. Leave empty for a permanent ban", false))
        .add_option(dpp::command_option(dpp::co_integer, "delete_days", "Days of their messages to delete (0-7)", false)
                        .set_min_value(0).set_max_value(7)));

    cmds.push_back(make_command("unban", "Unban a user", bot_id, dpp::p_ban_members)
        .add_option(user_opt("The user to unban"))
        .add_option(reason_opt()));

    cmds.push_back(make_command("kick", "Kick a member", bot_id, dpp::p_kick_members)
        .add_option(user_opt())
        .add_option(reason_opt()));

    cmds.push_back(make_command("timeout", "Time a member out", bot_id, dpp::p_moderate_members)
        .add_option(user_opt())
        .add_option(dpp::command_option(dpp::co_string, "duration", "e.g. 10m, 2h, 1d12h (max 28d)", true))
        .add_option(reason_opt()));

    cmds.push_back(make_command("untimeout", "Remove a member's timeout", bot_id, dpp::p_moderate_members)
        .add_option(user_opt())
        .add_option(reason_opt()));

    cmds.push_back(make_command("warn", "Warn a member", bot_id, dpp::p_moderate_members)
        .add_option(user_opt())
        .add_option(dpp::command_option(dpp::co_string, "reason", "Why they are being warned", true)));

    cmds.push_back(make_command("unwarn", "Remove a warning (the case stays on record)", bot_id, dpp::p_moderate_members)
        .add_option(dpp::command_option(dpp::co_integer, "case", "Case number of the warning", true).set_min_value(1))
        .add_option(reason_opt()));

    cmds.push_back(make_command("history", "Show a user's moderation history", bot_id, dpp::p_moderate_members)
        .add_option(user_opt("The user to look up"))
        .add_option(dpp::command_option(dpp::co_integer, "page", "Page number", false).set_min_value(1)));

    cmds.push_back(make_command("case", "Look up a case by number", bot_id, dpp::p_moderate_members)
        .add_option(dpp::command_option(dpp::co_integer, "number", "Case number", true).set_min_value(1)));

    cmds.push_back(make_command("purge", "Bulk delete recent messages", bot_id, dpp::p_manage_messages)
        .add_option(dpp::command_option(dpp::co_integer, "amount", "How many messages (1-100)", true)
                        .set_min_value(1).set_max_value(100))
        .add_option(dpp::command_option(dpp::co_user, "user", "Only delete messages from this user", false)));

    cmds.push_back(make_command("slowmode", "Set a channel's slowmode", bot_id, dpp::p_manage_channels)
        .add_option(dpp::command_option(dpp::co_integer, "seconds", "Seconds between messages (0 turns it off)", true)
                        .set_min_value(0).set_max_value(21600))
        .add_option(dpp::command_option(dpp::co_channel, "channel", "Defaults to this channel", false)));

    cmds.push_back(make_command("lock", "Stop @everyone from sending messages in a channel", bot_id, dpp::p_manage_channels)
        .add_option(dpp::command_option(dpp::co_channel, "channel", "Defaults to this channel", false))
        .add_option(reason_opt()));

    cmds.push_back(make_command("unlock", "Let @everyone send messages in a channel again", bot_id, dpp::p_manage_channels)
        .add_option(dpp::command_option(dpp::co_channel, "channel", "Defaults to this channel", false))
        .add_option(reason_opt()));

    cmds.push_back(make_command("heat", "Anti-raid heat meter", bot_id, dpp::p_manage_guild)
        .add_option(dpp::command_option(dpp::co_sub_command, "status", "Show the current heat level"))
        .add_option(dpp::command_option(dpp::co_sub_command, "reset", "Cool everything down and lift restrictions")));

    for (auto& c : build_config_commands(bot_id)) cmds.push_back(std::move(c));
    for (auto& c : build_automod_commands(bot_id)) cmds.push_back(std::move(c));
    for (auto& c : build_logging_commands(bot_id)) cmds.push_back(std::move(c));
    for (auto& c : build_antinuke_commands(bot_id)) cmds.push_back(std::move(c));
    for (auto& c : build_ticket_commands(bot_id)) cmds.push_back(std::move(c));
    return cmds;
}

void handle_slashcommand(App& app, const Event& e) {
    if (e.command.guild_id == 0) {
        reply_error(e, "Flour only works inside servers.");
        return;
    }

    try {
        if (handle_config_command(app, e)) return;
        if (handle_automod_command(app, e)) return;
        if (handle_logging_command(app, e)) return;
        if (handle_antinuke_command(app, e)) return;
        if (handle_ticket_command(app, e)) return;

        const std::string name = e.command.get_command_name();
        if (name == "ban") cmd_ban(app, e);
        else if (name == "unban") cmd_unban(app, e);
        else if (name == "kick") cmd_kick(app, e);
        else if (name == "timeout") cmd_timeout(app, e);
        else if (name == "untimeout") cmd_untimeout(app, e);
        else if (name == "warn") cmd_warn(app, e);
        else if (name == "unwarn") cmd_unwarn(app, e);
        else if (name == "history") cmd_history(app, e);
        else if (name == "case") cmd_case(app, e);
        else if (name == "purge") cmd_purge(app, e);
        else if (name == "slowmode") cmd_slowmode(app, e);
        else if (name == "lock") set_lock(app, e, true);
        else if (name == "unlock") set_lock(app, e, false);
        else if (name == "heat") cmd_heat(app, e);
    } catch (const std::exception& ex) {
        app.bot.log(dpp::ll_error, std::string("command failed: ") + ex.what());
    }
}

}  // namespace flour
