#include <cstdlib>
#include <fstream>
#include <iostream>

#include "app.hpp"

namespace {

flour::Config load_config(const std::string& path) {
    flour::Config cfg;

    std::ifstream in(path);
    if (in) {
        try {
            const dpp::json j = dpp::json::parse(in);
            cfg.token = j.value("token", "");
            cfg.database_path = j.value("database", cfg.database_path);
            cfg.dev_guild_id = j.value("dev_guild_id", static_cast<uint64_t>(0));
            if (j.contains("dashboard") && j["dashboard"].is_object()) {
                const dpp::json& d = j["dashboard"];
                cfg.dashboard.enabled = d.value("enabled", false);
                cfg.dashboard.host = d.value("host", cfg.dashboard.host);
                cfg.dashboard.port = d.value("port", cfg.dashboard.port);
                cfg.dashboard.client_id = d.value("client_id", std::string());
                cfg.dashboard.client_secret = d.value("client_secret", std::string());
                cfg.dashboard.redirect_uri = d.value("redirect_uri", std::string());
            }
        } catch (const std::exception& ex) {
            throw std::runtime_error("could not parse " + path + ": " + ex.what());
        }
    }

    // The environment wins, which is handy for containers and systemd units.
    if (const char* token = std::getenv("FLOUR_TOKEN")) cfg.token = token;
    if (const char* db = std::getenv("FLOUR_DATABASE")) cfg.database_path = db;

    if (cfg.token.empty() || cfg.token == "YOUR_BOT_TOKEN") {
        throw std::runtime_error("no bot token. Put it in " + path + " or set FLOUR_TOKEN.");
    }
    return cfg;
}

}  // namespace

int main(int argc, char** argv) {
    try {
        const std::string config_path = argc > 1 ? argv[1] : "config.json";
        flour::Config config = load_config(config_path);
        flour::Database db(config.database_path);

        // Message content and member events are privileged intents. Both must be switched on
        // for the bot in the Discord developer portal. Voice states power the voice logs.
        dpp::cluster bot(config.token,
                         dpp::i_default_intents | dpp::i_message_content | dpp::i_guild_members |
                         dpp::i_guild_voice_states | dpp::i_guild_bans);
        flour::App app{bot, db, config};
        flour::start_dashboard(app, config.dashboard);

        bot.on_log(dpp::utility::cout_logger());

        bot.on_slashcommand([&app](const dpp::slashcommand_t& event) {
            flour::handle_slashcommand(app, event);
        });
        bot.on_message_create([&app](const dpp::message_create_t& event) {
            flour::logging_on_message(app, event);
            flour::automod_on_message(app, event);
        });
        bot.on_message_update([&app](const dpp::message_update_t& event) {
            flour::logging_on_message_update(app, event);
        });
        bot.on_message_delete([&app](const dpp::message_delete_t& event) {
            flour::logging_on_message_delete(app, event);
        });
        bot.on_message_delete_bulk([&app](const dpp::message_delete_bulk_t& event) {
            flour::logging_on_message_delete_bulk(app, event);
        });
        bot.on_guild_member_add([&app](const dpp::guild_member_add_t& event) {
            flour::logging_on_member_add(app, event);
            flour::archive_on_member(app, static_cast<uint64_t>(event.added.guild_id), event.added);
            flour::automod_on_member_join(app, event);
        });
        bot.on_guild_member_remove([&app](const dpp::guild_member_remove_t& event) {
            flour::logging_on_member_remove(app, event);
            flour::archive_on_member_remove(app, static_cast<uint64_t>(event.guild_id),
                                            static_cast<uint64_t>(event.removed.id));
            flour::antinuke_on_kick(app, event);
        });
        bot.on_guild_ban_add([&app](const dpp::guild_ban_add_t& event) {
            flour::antinuke_on_ban(app, event);
        });
        bot.on_guild_role_create([&app](const dpp::guild_role_create_t& event) {
            flour::antinuke_on_role_create(app, event);
        });
        bot.on_guild_role_delete([&app](const dpp::guild_role_delete_t& event) {
            flour::antinuke_on_role_delete(app, event);
        });
        bot.on_guild_member_update([&app](const dpp::guild_member_update_t& event) {
            flour::logging_on_member_update(app, event);
            flour::archive_on_member(app, static_cast<uint64_t>(event.updating_guild.id), event.updated);
            flour::antinuke_on_member_update(app, event);
        });
        bot.on_channel_create([&app](const dpp::channel_create_t& event) {
            flour::archive_on_channel(app, static_cast<uint64_t>(event.created.guild_id), event.created);
        });
        bot.on_channel_update([&app](const dpp::channel_update_t& event) {
            flour::archive_on_channel(app, static_cast<uint64_t>(event.updated.guild_id), event.updated);
        });
        bot.on_guild_role_update([&app](const dpp::guild_role_update_t& event) {
            flour::antinuke_on_role_update(app, event);
        });
        bot.on_webhooks_update([&app](const dpp::webhooks_update_t& event) {
            flour::antinuke_on_webhooks(app, event);
        });
        bot.on_voice_state_update([&app](const dpp::voice_state_update_t& event) {
            flour::logging_on_voice_state(app, event);
        });

        bot.on_button_click([&app](const dpp::button_click_t& event) {
            flour::handle_button(app, event);
        });
        bot.on_form_submit([&app](const dpp::form_submit_t& event) {
            flour::handle_form(app, event);
        });
        bot.on_channel_delete([&app](const dpp::channel_delete_t& event) {
            flour::ticket_on_channel_delete(app, event.deleted.id);
            flour::archive_on_channel_delete(app, static_cast<uint64_t>(event.deleting_guild.id),
                                             static_cast<uint64_t>(event.deleted.id));
            flour::antinuke_on_channel_delete(app, event);
        });

        bot.on_ready([&app](const dpp::ready_t&) {
            if (dpp::run_once<struct register_flour_commands>()) {
                auto commands = flour::build_commands(app.bot.me.id);
                if (app.config.dev_guild_id != 0) {
                    app.bot.guild_bulk_command_create(commands, app.config.dev_guild_id);
                } else {
                    app.bot.global_bulk_command_create(commands);
                }
                flour::archive_seed(app);
                flour::start_scheduler(app);
            }
            app.bot.set_presence(dpp::presence(dpp::ps_online, dpp::at_watching, "over the server"));
        });

        bot.start(dpp::st_wait);
    } catch (const std::exception& ex) {
        std::cerr << "flour: " << ex.what() << "\n";
        return 1;
    }
    return 0;
}
