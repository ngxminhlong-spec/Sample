#include "util.hpp"

#include <algorithm>
#include <cctype>

namespace flour {

std::optional<int64_t> parse_duration(const std::string& text) {
    int64_t total = 0;
    size_t i = 0;
    bool any = false;

    while (i < text.size()) {
        if (std::isspace(static_cast<unsigned char>(text[i]))) { ++i; continue; }
        if (!std::isdigit(static_cast<unsigned char>(text[i]))) return std::nullopt;

        int64_t value = 0;
        while (i < text.size() && std::isdigit(static_cast<unsigned char>(text[i]))) {
            value = value * 10 + (text[i] - '0');
            if (value > 100000000) return std::nullopt;  // keeps the sums below overflow
            ++i;
        }
        if (i >= text.size()) return std::nullopt;

        int64_t unit = 0;
        switch (std::tolower(static_cast<unsigned char>(text[i]))) {
            case 's': unit = 1; break;
            case 'm': unit = 60; break;
            case 'h': unit = 3600; break;
            case 'd': unit = 86400; break;
            case 'w': unit = 604800; break;
            default: return std::nullopt;
        }
        ++i;
        total += value * unit;
        any = true;
    }
    if (!any || total <= 0) return std::nullopt;
    return total;
}

std::string format_duration(int64_t seconds) {
    if (seconds <= 0) return "0s";
    const int64_t d = seconds / 86400;
    const int64_t h = (seconds % 86400) / 3600;
    const int64_t m = (seconds % 3600) / 60;
    const int64_t s = seconds % 60;

    std::string out;
    auto add = [&](int64_t v, const char* suffix) {
        if (v == 0) return;
        if (!out.empty()) out += ' ';
        out += std::to_string(v) + suffix;
    };
    add(d, "d");
    add(h, "h");
    add(m, "m");
    add(s, "s");
    return out;
}

std::string discord_time(int64_t unix_ts, char style) {
    return "<t:" + std::to_string(unix_ts) + ":" + style + ">";
}

std::string truncate(const std::string& text, size_t max_len) {
    if (text.size() <= max_len) return text;
    if (max_len <= 3) return text.substr(0, max_len);
    return text.substr(0, max_len - 3) + "...";
}

std::string to_lower(std::string text) {
    std::transform(text.begin(), text.end(), text.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return text;
}

}  // namespace flour
