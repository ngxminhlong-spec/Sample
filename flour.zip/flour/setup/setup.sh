#!/usr/bin/env bash
# Flour one-shot setup for a fresh Ubuntu VPS.
#
#   1. installs what Flour needs to build
#   2. installs Tailscale and logs this machine in
#   3. builds Flour, asks for your token, and writes the config
#   4. runs Flour as a systemd service that restarts on crash and survives reboots
#   5. publishes the dashboard on your tailnet over HTTPS
#
# Run it from inside the unzipped flour folder:
#   sudo bash setup/setup.sh
#
# Safe to run again: it updates the code, rebuilds, and keeps your config.

set -euo pipefail

INSTALL_DIR=/opt/flour
SERVICE_USER=flour
DASH_PORT=8080
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

say()  { printf '\n\033[1;34m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m!!\033[0m  %s\n' "$*"; }
die()  { printf '\033[1;31mxx\033[0m  %s\n' "$*" >&2; exit 1; }
ask()  { local reply; read -rp "$1 " reply; printf '%s' "$reply"; }

# ------------------------------------------------------------------ checks
[[ $EUID -eq 0 ]] || die "Run this with sudo: sudo bash setup/setup.sh"
[[ -f "$SRC_DIR/CMakeLists.txt" ]] || die "Run this from inside the unzipped flour folder."
if [[ -r /etc/os-release ]]; then
    . /etc/os-release
    [[ "${ID:-}" == ubuntu || "${ID:-}" == debian ]] || warn "Built for Ubuntu/Debian. Continuing anyway."
fi
[[ "$(uname -m)" == x86_64 || "$(uname -m)" == aarch64 ]] || warn "Untested CPU type: $(uname -m)"

# ------------------------------------------------------------------ packages
say "Installing build tools and libraries (this takes a few minutes)"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y build-essential cmake git curl ca-certificates rsync \
    libssl-dev zlib1g-dev libsqlite3-dev python3

# ------------------------------------------------------------------ tailscale
say "Setting up Tailscale"
if ! command -v tailscale >/dev/null 2>&1; then
    curl -fsSL https://tailscale.com/install.sh | sh
fi
systemctl enable --now tailscaled

if ! tailscale status >/dev/null 2>&1; then
    echo "Tailscale needs you to log in. It will print a link. Open it on your phone or laptop."
    tailscale up
fi

DNS_NAME="$(tailscale status --json | python3 -c 'import json,sys; print(json.load(sys.stdin)["Self"]["DNSName"].rstrip("."))')"
[[ -n "$DNS_NAME" ]] || die "Couldn't read this machine's Tailscale name. Run 'tailscale status' and check it."
echo "This machine on your tailnet: $DNS_NAME"

# ------------------------------------------------------------------ code
say "Copying Flour to $INSTALL_DIR"
id -u "$SERVICE_USER" >/dev/null 2>&1 || useradd --system --home-dir "$INSTALL_DIR" --shell /usr/sbin/nologin "$SERVICE_USER"
mkdir -p "$INSTALL_DIR"
rsync -a --delete --exclude build --exclude config.json --exclude '*.db*' "$SRC_DIR/" "$INSTALL_DIR/source/"

# ------------------------------------------------------------------ config
CONFIG="$INSTALL_DIR/config.json"
KEEP=""
if [[ -f "$CONFIG" ]]; then
    KEEP="$(ask 'A config already exists. Keep it? [Y/n]')"
fi

if [[ -z "$KEEP" || "$KEEP" =~ ^[Yy] ]] && [[ -f "$CONFIG" ]]; then
    echo "Keeping the existing config."
else
    say "Discord setup"
    echo "Paste your bot token. It won't be shown on screen."
    read -rsp "Bot token: " BOT_TOKEN; echo
    [[ -n "$BOT_TOKEN" ]] || die "The token can't be empty."

    echo "Dashboard (the web settings page). You need an OAuth2 client from the Discord developer portal."
    DASH_ON="$(ask 'Enable the dashboard? [Y/n]')"
    DASH_ON="${DASH_ON:-y}"
    OAUTH_ID=""; OAUTH_SECRET=""
    if [[ "$DASH_ON" =~ ^[Yy] ]]; then
        echo "Add this redirect in the developer portal under OAuth2 before continuing:"
        echo "    https://$DNS_NAME/callback"
        OAUTH_ID="$(ask 'OAuth2 client ID:')"
        read -rsp "OAuth2 client secret (hidden): " OAUTH_SECRET; echo
        [[ -n "$OAUTH_ID" && -n "$OAUTH_SECRET" ]] || die "The client ID and secret are both needed for the dashboard."
    fi

    # Subshell: the restrictive umask must not leak into the build that follows.
    (
    umask 077
    FLOUR_TOKEN="$BOT_TOKEN" OAUTH_ID="$OAUTH_ID" OAUTH_SECRET="$OAUTH_SECRET" \
    DASH_ON="$DASH_ON" DNS_NAME="$DNS_NAME" DASH_PORT="$DASH_PORT" CONFIG="$CONFIG" \
    python3 - <<'PY'
import json, os
dash = os.environ["DASH_ON"].lower().startswith("y")
cfg = {
    "token": os.environ["FLOUR_TOKEN"],
    "database": "flour.db",
    "dev_guild_id": 0,
    "dashboard": {
        "enabled": dash,
        "host": "127.0.0.1",
        "port": int(os.environ["DASH_PORT"]),
        "client_id": os.environ["OAUTH_ID"],
        "client_secret": os.environ["OAUTH_SECRET"],
        "redirect_uri": "https://%s/callback" % os.environ["DNS_NAME"],
    },
}
with open(os.environ["CONFIG"], "w") as f:
    json.dump(cfg, f, indent=2)
    f.write("\n")
PY
    )
    echo "Config written."
fi

# ------------------------------------------------------------------ build
say "Building Flour. The first build downloads and compiles D++, so on a small VPS it can take 20-40 minutes."
cmake -S "$INSTALL_DIR/source" -B "$INSTALL_DIR/build" -DCMAKE_BUILD_TYPE=Release
cmake --build "$INSTALL_DIR/build" -j"$(nproc)"
install -m 755 "$INSTALL_DIR/build/flour" "$INSTALL_DIR/flour"

chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
chown root:"$SERVICE_USER" "$CONFIG"
chmod 640 "$CONFIG"

# ------------------------------------------------------------------ service
say "Starting Flour as a service"
cat > /etc/systemd/system/flour.service <<UNIT
[Unit]
Description=Flour Discord moderation bot
After=network-online.target
Wants=network-online.target

[Service]
User=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/flour $CONFIG
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=$INSTALL_DIR
PrivateTmp=true

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable flour
systemctl restart flour

# ------------------------------------------------------------------ dashboard on the tailnet
if python3 -c 'import json,sys; sys.exit(0 if json.load(open(sys.argv[1]))["dashboard"]["enabled"] else 1)' "$CONFIG"; then
    say "Publishing the dashboard on your tailnet"
    if tailscale serve --bg --https=443 "http://127.0.0.1:$DASH_PORT"; then
        DASH_URL="https://$DNS_NAME"
    else
        warn "tailscale serve failed. In the Tailscale admin console, enable HTTPS certificates, then run:"
        warn "    sudo tailscale serve --bg --https=443 http://127.0.0.1:$DASH_PORT"
        DASH_URL="(not published yet, see above)"
    fi
else
    DASH_URL="(dashboard is off)"
fi

# ------------------------------------------------------------------ firewall
if [[ "$(ask 'Turn on the firewall (ufw)? It allows SSH and Tailscale only. [y/N]')" =~ ^[Yy] ]]; then
    apt-get install -y ufw
    ufw default deny incoming
    ufw default allow outgoing
    ufw allow OpenSSH
    ufw allow in on tailscale0
    ufw --force enable
    echo "Firewall on. If you use a non-standard SSH port, allow it before logging out."
fi

# ------------------------------------------------------------------ done
sleep 3
say "Done"
systemctl --no-pager --lines=0 status flour || true
cat <<DONE

  Bot:        running as the 'flour' service
  Dashboard:  $DASH_URL  (open it from a device on your tailnet)

  Useful commands:
    sudo systemctl status flour        check it's running
    sudo journalctl -u flour -f        watch the live log
    sudo systemctl restart flour       restart after changing config.json
    sudo nano $CONFIG                  edit the token or dashboard settings
    sudo bash setup/setup.sh           update Flour (run from the new unzip)

  Invite the bot to your server, then run /config modlog in a channel to start.
DONE
